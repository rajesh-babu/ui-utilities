export { AppComponent } from './app.component';
export { SIDEBAR_TOGGLE_DIRECTIVES } from './shared/sidebar.directive';

// Custom Declarations
import { SideFieldsComponent } from './components/side/fields/side.component';
import { SideSettingsComponent } from './components/side/settings/settings.component';
import { SecModalComponent } from './components/pages/modals/section/modal.comp';

import { DelModalComponent } from './components/pages/modals/delete/delete.comp';
import { FormSaveModalComponent } from './components/pages/modals/form/form-save.comp';

// Custom component
export const MAIN_DECLARATIONS = [
    SideFieldsComponent, SideSettingsComponent, SecModalComponent, DelModalComponent, FormSaveModalComponent
];

// Custom Modules
import { TextFieldModule } from './components/fields/textfield/textfield.module';
import { CheckboxFieldModule } from './components/fields/checkbox/checkboxfield.module';
import { SelectFieldModule } from './components/fields/selectfield/selectfield.module';
import { RadioFieldModule } from './components/fields/radiofield/radiofield.module';
import { DateFieldModule } from './components/fields/datefield/datefield.module';
import { PhoneFieldModule } from './components/fields/phonefield/phonefield.module';
import { ParagraphFieldModule } from './components/fields/paragraphfield/paragraphfield.module';
import { HeaderFieldModule } from './components/fields/headerfield/headerfield.module';
import { ButtonFieldModule } from './components/fields/buttonfield/buttonfield.module';
import { PreviewFormModule } from './components/pages/previewForm/preview-form.module';
import { SettingsPageModule } from './components/pages/settings/settings-page.module';
import { AsideModule } from './components/fields/aside.module';
import { SectionModule } from './components/fields/section/section.module';
import { MulticolModule } from './components/fields/multicolumn/multicol.module';
import { GroupFieldModule } from './components/fields/groupfield/groupfield.module';
import { GridTableFieldModule } from './components/fields/gridtablefield/gridtablefield.module';
import { DividerModule } from './components/fields/divider/divider-field.module';
import { DragandDropModule} from './components/drag-and-drop/drag-drop.module';
import { StageModule } from './components/stage/stage.module';
import { SecContainerModule } from './components/fields/secContainer/secContainer.module';
import { SsnFieldModule } from './components/fields/ssnfield/ssnfield.module';
import { TitleModule } from './components/fields/titlefield/title-field.module';
import { PageFieldModule } from './components/fields/pagefield/pagefield.module';

import { CustomCommonsModule } from './shared/customCommons.module';
import { HttpModule, JsonpModule } from '@angular/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';


export const CUSTOM_MODULES = [ FormsModule, ReactiveFormsModule, CustomCommonsModule,
  TextFieldModule, CheckboxFieldModule, PreviewFormModule, AsideModule, SelectFieldModule, RadioFieldModule,
  SettingsPageModule, DateFieldModule, PhoneFieldModule, ParagraphFieldModule,
  ButtonFieldModule, SectionModule, HeaderFieldModule, HttpModule, JsonpModule, MulticolModule, SecContainerModule,
  DragandDropModule, StageModule, GridTableFieldModule, GroupFieldModule, DividerModule, SsnFieldModule,
  TitleModule, PageFieldModule
];

// Custom Services
import { UtilityService} from './services/UtilityService';
import { Constants} from './services/Constants';
import { NavService} from './services/NavService';
import { FieldControlsService} from './services/FieldControlsService';
import { GlobalService} from './services/GlobalService';
import { CommonsFieldsService} from './services/fields/CommonsFieldsService';
import { FieldsFactoryService } from './services/fields/FieldsFactory.service';
import { HttpService } from './services/HttpService';
export const CUSTOM_SERVICES = [
  UtilityService,  NavService, FieldControlsService, FieldsFactoryService, GlobalService, Constants,CommonsFieldsService,  HttpService
];
