import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { DragulaModule} from 'ng2-dragula';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { MAIN_DECLARATIONS, CUSTOM_MODULES, CUSTOM_SERVICES } from './';
import { AppComponent, SIDEBAR_TOGGLE_DIRECTIVES} from './';
import { FormsModule } from '@angular/forms';
import { ModalModule  } from 'ngx-bootstrap';

@NgModule({
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    DragulaModule,
    FormsModule,
    CUSTOM_MODULES
  ],
  declarations: [
    AppComponent,
    SIDEBAR_TOGGLE_DIRECTIVES,
    MAIN_DECLARATIONS
  ],
  providers: [{
    provide: LocationStrategy,
    useClass: HashLocationStrategy
  },  CUSTOM_SERVICES],
  entryComponents: [ ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
