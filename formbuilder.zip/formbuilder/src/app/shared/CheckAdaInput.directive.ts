import { Directive, ElementRef, HostListener, Renderer } from '@angular/core';

@Directive({
  selector: '[checkADAInput]'
})
export class CheckAdaInputDirective {
  private adaRegex = /(\S+=(\'|\")\S+(\'|\"))$/;
  constructor(private elRef:ElementRef, private renderer:Renderer) {}

  @HostListener('blur', ['$event'])
  onFocusout($event: any) {
    const str = $event.target.value;
    const adaStrs: string[] = str.split(',');
    let count:number = 0;
    if(!str) {
      this.renderer.setElementClass(this.elRef.nativeElement.parentNode, 'has-error', false);
      return;
    }
    adaStrs.forEach((adaStr, index) => {
       if ((this.adaRegex.exec(adaStr)) !== null) {
         count++;
       }
    });
    if(adaStrs.length !== count) {
      this.renderer.setElementClass(this.elRef.nativeElement.parentNode, 'has-error', true);
    } else {
      this.renderer.setElementClass(this.elRef.nativeElement.parentNode, 'has-error', false);
    }
  }

}
