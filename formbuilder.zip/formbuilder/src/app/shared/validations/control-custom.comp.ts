import { Component, Input, OnChanges, SimpleChanges, OnInit, ElementRef, Renderer } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ValidationService } from './validation.service';
import { GlobalService} from '../../services/GlobalService';
@Component({
  selector: 'control-custom',
  template: `<div class="alert alert-danger"  *ngIf="errorMessage">{{errorMessage}}</div>`
})
export class ControlCustomComponent implements OnChanges, OnInit {
  @Input() control: any;
  @Input('inpRef') inpRef:ElementRef;
  @Input() validateArr: Array<any>;
  @Input() isSubmitted:boolean;
  @Input() isUnique:boolean;
  @Input() uniqueType:string;
  errorMessage:string;
  initValue:any;
  constructor(private globalService:GlobalService, private renderer: Renderer) {}
  /*
   * Below  function will be triggered while chaging the values in the field.
   */
  ngOnChanges(changes: SimpleChanges) {
    if(!this.initValue) {
      this.initValue = true;
      return;
    }
    this.errorMessage = null;
    if(changes['control'] || changes['isSubmitted']) {
     this.validateArr.forEach((item, i) => {
       if(!this.errorMessage ) {
         if(item === 'requiredValidator' && !changes['isSubmitted']) {return; };
         this.errorMessage = ValidationService.validateAll(item, this.control, '', '', '', '');
       }
     });
   }
   if(changes['isSubmitted'] ||  this.inpRef['classList'].contains('ng-touched')) {
     if(!this.errorMessage && this.isUnique) {
       this.errorMessage = ValidationService.validateAll(ValidationService.uniqueVal, this.inpRef, this.uniqueType, '', '', '');
     }
   }
   this.addRemoveCls();
  }
  ngOnInit() {
    const that= this;
    this.validateArr.forEach((item, i) => {
       if(!this.errorMessage) {
        const errMsg = ValidationService.validateAll(item, this.control, '', '', '', '');
        // Below check is for dont show the required before savesubmitted
        if(this.globalService.saveSubmitted || errMsg !== ValidationService.getValidatorErrorMessage('customRequired',0)) {
          this.errorMessage = errMsg;
        }
      }
    });
    if(!this.errorMessage && this.isUnique) {
      setTimeout(function(){
       that.errorMessage = ValidationService.validateAll(ValidationService.uniqueVal, that.inpRef, that.uniqueType, '', '', '');
       that.addRemoveCls();
     }, 200);
    }
    this.addRemoveCls();
    // Retain the error messages if user goes diffferent section and come again.
    this.renderer.listen(this.inpRef, "blur", ( event ) => {
      if(this.isUnique) {
        this.errorMessage = ValidationService.validateAll(ValidationService.uniqueVal, this.inpRef, this.uniqueType, '', '', '');
      }

      if(this.globalService.saveSubmitted ||  this.inpRef['classList'].contains('ng-touched')) {
        this.validateArr.forEach((item, i) => {

          if(!this.errorMessage) {
            this.errorMessage = ValidationService.validateAll(item, this.control, '', '', '', '');
          }
        });
      }
      this.addRemoveCls();
    });
  }
 /*
  * This will add or remove the class "ng-invalid" to the corresponding field.
  */
  addRemoveCls() {
    if(this.errorMessage !== '') {
      this.renderer.setElementClass(this.inpRef, 'ng-custom-invalid', true);
    }else {
       this.renderer.setElementClass(this.inpRef, 'ng-custom-invalid', false);
    }
  }
}
