declare var appGlobalData: any;
export class ValidationService {

    // Below names should match with corresponding functions.
    static attributeVal:string = 'attributeValidator';
    static customRequiredVal:string = 'requiredValidator';
    static adaAttributesVal:string = 'adaAttributesValidator';
    static classAttributesVal:string = 'classAttributesValidator';
    static uniqueNameValOnsave:string = 'uniqueNameValidatorOnSave';
    static uniqueIdValOnsave:string = 'uniqueIdValidatorOnSave';
    static uniqueVal:string = 'uniqueValidator';
    static namesArray:Array<any> = [];
    static IdArray:Array<any> = [];
    static selectedPagVal:number = 0;

    static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
        const config = {
            'required': 'This field is Required!',
            'customRequired': 'This field is Required!',
            'invalidCreditCard': 'Is invalid credit card number',
            'invalidEmailAddress': 'Invalid email address!',
            'invalidSecName': 'Invalid Name. No Special characters!',
            'invalidValue': 'Invalid value!',
            'invalidAdaAttributes': 'Invalid value!',
            'duplicate':'Already Exist!',
            'maxlength': `Maximum length is ${validatorValue.requiredLength}`
        };

        return config[validatorName];
    }

    static emailValidator(control) {
        // RFC 2822 compliant regex
        if (control.value.match(/[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/)) {
            return null;
        } else {
            return { 'invalidEmailAddress': true };
        }
    }

    static secNameValidator(control) {

        // Alpha Numeric -  _ empty space are allowed
        if (control.value.match(/^[A-Za-z0-9\s_-]+$/)) {
            return null;
        } else {
            return { 'invalidSecName': true };
        }
    }
    static attributeValidator(control) {
        if(!control.value) {
          return;
        }
        if (control.value.match(/^[a-zA-Z][\w:.-]*$/)) {
            return null;
        } else {
            return { 'invalidValue': true };
        }
    }
    static requiredValidator(control) {
        if (control.value) {
            return null;
        } else {
            return { 'customRequired': true };
        }
    }
    static requiredNameValidator(value) {
        if (value) {
            return null;
        } else {
            return { 'customRequired': true };
        }
    }
    static ssnRequiredValidator(control) {
        const group = control.parent;
        if (group) {
            if(group.controls['numberofFields'].value === '3') {
              if (control.value) {
                  return null;
              } else {
                  return { 'customRequired': true };
              }
            } else {
              return null;
            }
        }
    }
    static adaAttributesValidator(control) {
      if(!control.value) {
        return;
      }
      const adaStrs: string[] = control.value.split(',');
      let count:number = 0;

      adaStrs.forEach((adaStr, index) => {

         if (adaStr.match(/(\S+=(\'|\")\S+(\'|\"))$/)) {
           count++;
         }
      });
      if(adaStrs.length !== count) {
        return { 'invalidAdaAttributes': true };
      }else {
        return null;
      }
    }
    static classAttributesValidator(control) {
      if(!control.value) {
        return;
      }
     const classStrs:string[] = control.value.split(',');
     let count:number = 0;

     classStrs.forEach((classStr, index) => {

        if (classStr.match(/^[a-zA-Z][\w:.-]*$/)) {
          count++;
        }
     });
     if(classStrs.length !== count) {
       return { 'invalidAdaAttributes': true };
     }else {
       return null;
     }
    }

    static uniqueNameValidatorOnSave(control) {
      if(!control.value) {
        return null;
      } else {
        let returnMsg = '';
        for(let i=0; i<ValidationService.namesArray.length;i++) {
          if(ValidationService.namesArray[i].value === control.value) {
            returnMsg = returnMsg + 'Page ' +(ValidationService.namesArray[i].pgno+1)+
            ' - Row ' +(ValidationService.namesArray[i].fno+1) + ' - ' + ValidationService.namesArray[i].fname;
          }
        }
        if(returnMsg) {
          return returnMsg;
        } else {
            ValidationService.namesArray.push({'value':control.value,'pgno':control.pgno,'fno':control.fno,'fname':control.fname});
            return null;
        }
      }
    }

    static uniqueIdValidatorOnSave(control) {
      if(!control.value) {
        return null;
      } else {
        let returnMsg = '';
        for(let i=0; i<ValidationService.IdArray.length;i++) {
          if(ValidationService.IdArray[i].value === control.value) {
            returnMsg = returnMsg + 'Page ' +(ValidationService.IdArray[i].pgno+1)+
            ' - Row ' +(ValidationService.IdArray[i].fno+1) + ' - ' + ValidationService.IdArray[i].fname;
          }
        }
        if(returnMsg) {
          return returnMsg;
        } else {
            ValidationService.IdArray.push({'value':control.value,'pgno':control.pgno,'fno':control.fno,'fname':control.fname});
            return null;
        }
      }
    }

    static checkUnique(field, value, type) {
      let checkCounter = 0;
      if(value === '') {return checkCounter; }
      if(field.numberofFields) { // For SSN, Account Number and Phone fields
        for(let m=0;m<field.numberofFields;m++) {
          if(field[type+(m+1)] === value) {checkCounter++;}
          if(type === 'name') {
            if(field[type+(m+1)+'_override'] === value) {checkCounter++;}
          }
        }
      } else  if(field.componentName === 'Button') { // For Button Field
        for(let k=0;k<field.buttons.length;k++) {
          if(field.buttons[k][type] === value) {checkCounter++;}
          if(type === 'name') {
            if(field.buttons[k][type+'_override'] === value) {checkCounter++;}
          }
        }
      } else if(field.componentName === 'Grid Table') { // For Grid Table
        if(field[type] === value) {checkCounter++;}
        if(type === 'name') {
          if(field[type+'_override'] === value) {checkCounter++;}
        }
        for(let k=0;k<field.columns.length;k++) {
          if(field.columns[k].rowField !== 'label') {
            if(field.columns[k].rowFieldConf[type] === value) {checkCounter++;}
            if(type === 'name') {
              if(field.columns[k].rowFieldConf[type+'_override'] === value) {checkCounter++;}
              if(field.columns[k].rowFieldConf['radioName'] === value) {checkCounter++;}
              if(field.columns[k].rowFieldConf['textName'] === value) {checkCounter++;}
            }
          }
        }
      } else { // For other fields
        if(field[type] === value) {checkCounter++;}
        if(type === 'name') {
          if(field[type+'_override'] === value) {checkCounter++;}
        }
      }
      return checkCounter;
    }

    static uniqueValidator(control, type) {
      let counter = 0;
      for(let i=0;i<appGlobalData.pages.length;i++) {
        for(let j=0;j<appGlobalData.pages[i].length;j++) {
          if(appGlobalData.pages[i][j].componentName === 'Multi Column') {
            for(let k=0;k<Object.keys(appGlobalData.pages[i][j].fieldsObj).length;k++) {
              const colObj = appGlobalData.pages[i][j].fieldsObj['col'+k];
              if(colObj) {
                counter = counter + ValidationService.checkUnique(colObj, control.value.value, control.type);
              }
            }
          } else if(appGlobalData.pages[i][j].componentName === 'Group Field') {
            counter = counter + ValidationService.checkUnique(appGlobalData.pages[i][j], control.value.value, control.type);
            for(let k=0;k<Object.keys(appGlobalData.pages[i][j].groupFields).length;k++) {
              const colObj = appGlobalData.pages[i][j].groupFields[k];
              if(colObj.componentName === 'Multi Column') {
                for(let l=0;l<Object.keys(colObj.fieldsObj).length;l++) {
                  const colObjNew = colObj.fieldsObj['col'+l];
                  if(colObjNew) {
                    counter = counter + ValidationService.checkUnique(colObjNew, control.value.value, control.type);
                  }
                }
              } else {
                counter = counter + ValidationService.checkUnique(colObj, control.value.value, control.type);
              }
            }
          } else if(appGlobalData.pages[i][j].componentName === 'Widget') {
            counter = counter + ValidationService.checkUnique(appGlobalData.pages[i][j], control.value.value, control.type);
            for(let k=0;k<appGlobalData.pages[i][j].pages.length;k++) {
              const secEle = appGlobalData.pages[i][j].pages[k];
              for(let l=0;l<secEle.length;l++) {
                if(secEle[l].componentName !== 'Divider' && secEle[l].componentName !== 'Title') {
                  counter = counter + ValidationService.checkUnique(secEle[l], control.value.value, control.type);
                }
              }
            }
          } else if(appGlobalData.pages[i][j].componentName !== 'Divider' && appGlobalData.pages[i][j].componentName !== 'Title') {
            counter = counter + ValidationService.checkUnique(appGlobalData.pages[i][j], control.value.value, control.type);
          }
        }
      }
      if(counter > 1) {
        return { 'duplicate': true };
      } else {
        return null;
      }
    }

    /*
     * This will be called to trigger the given custom validation function (above)
     */
    static validateAll(valName:string, value:any, type:any, pgno:any, fno:any, fname:any):string {
      const result:any = ValidationService[valName]({value:value,type:type,pgno:pgno,fno:fno,fname:fname});
      if(result) {
        if(typeof result === 'string') {
          return result;
        } else if(typeof result === 'object') {
          for(const errProp in result) {
            if (result.hasOwnProperty(errProp)) {
              return ValidationService.getValidatorErrorMessage(errProp, 0);
            }
          }
        }
      } else {
        return '';
      }
    }
}
