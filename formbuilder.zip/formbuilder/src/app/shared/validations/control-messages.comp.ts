import { Component, Input, OnChanges, SimpleChanges, OnInit, ElementRef, Renderer } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ValidationService } from './validation.service';

@Component({
  selector: 'control-messages',
  template: `<div class="alert alert-danger"  *ngIf="errorMessage !== null || newerrorMessage !== null">{{(errorMessage)?errorMessage:newerrorMessage}}</div>`
})
export class ControlMessagesComponent implements OnInit {
  @Input() control: FormControl;
  @Input() isSubmitted:boolean;
  @Input('inpRef') inpRef:ElementRef;
  @Input() isUnique:boolean;
  @Input() uniqueType:string;
  public newerrorMessage = null;
  constructor(private renderer: Renderer) { }

  get errorMessage() {
    for (const propertyName in this.control.errors) {
      if (this.control.errors.hasOwnProperty(propertyName) ) {

        if(this.isSubmitted || this.control.touched) {
          return ValidationService.getValidatorErrorMessage(propertyName, this.control.errors[propertyName]);
        }
      }
    }
    if(this.isSubmitted && this.isUnique) {
      const that = this;
        that.validateUnique();
    }
    return null;
  }

  ngOnInit() {
    const that = this;
    if(this.isUnique) {
      setTimeout(function(){that.validateUnique(); }, 200);
      this.renderer.listen(this.inpRef, "blur", ( event ) => {
        this.validateUnique();
      });
    }
  }
  validateUnique() {
    this.newerrorMessage = ValidationService.validateAll(ValidationService.uniqueVal, this.inpRef, this.uniqueType, '', '', '');
    if(!this.newerrorMessage) {
      this.newerrorMessage = null;
    }
    this.addRemoveCls();
  }

  /*
   * This will add or remove the class "ng-invalid" to the corresponding field.
   */
   addRemoveCls() {
     if(this.newerrorMessage) {
       this.renderer.setElementClass(this.inpRef, 'ng-custom-invalid', true);
     }else {
       this.renderer.setElementClass(this.inpRef, 'ng-custom-invalid', false);
     }
   }
}
