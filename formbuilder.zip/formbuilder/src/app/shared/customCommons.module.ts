import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FieldControlsComponent} from '../components/fields/commons/fieldControls/fieldControls.component';
import { ControlMessagesComponent } from './validations/control-messages.comp';
import { ControlCustomComponent } from './validations/control-custom.comp';
import { PlHolderDirective } from './plHolder.directives';
import { TinymceEditorDirective } from './tinymceEditor.directives';
import { CheckAdaInputDirective } from './CheckAdaInput.directive';
import { ModalModule  } from 'ngx-bootstrap';
import { FormValidModalComponent } from '../components/pages/modals/validation/form-valid.comp';
import { UpdateRefidModalComponent } from '../components/pages/modals/refid/update-refid.comp';
import { MulticolValidModalComponent } from '../components/pages/modals/validation/multicol-valid.comp';

@NgModule({
  imports:      [ CommonModule, ModalModule ],
  declarations: [ FieldControlsComponent,
    PlHolderDirective,
    TinymceEditorDirective,
    CheckAdaInputDirective,
    ControlMessagesComponent,
    ControlCustomComponent,
    FormValidModalComponent,
    UpdateRefidModalComponent,
    MulticolValidModalComponent ],
  exports:      [ FieldControlsComponent,
    PlHolderDirective,
    TinymceEditorDirective,
    CheckAdaInputDirective,
    ControlMessagesComponent,
    ControlCustomComponent,
    FormValidModalComponent,
    UpdateRefidModalComponent,
    MulticolValidModalComponent ]
})
export class CustomCommonsModule { }
