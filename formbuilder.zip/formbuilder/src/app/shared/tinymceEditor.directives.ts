import {AfterViewInit, ChangeDetectorRef, Directive, EventEmitter,
        forwardRef, Input, OnInit, Output, OnChanges, SimpleChanges,ElementRef} from '@angular/core';
import { NG_VALUE_ACCESSOR, ControlValueAccessor } from '@angular/forms';
declare var tinymce: any;
declare var relativePath: any;

  // This is needed to update the tinymce editor when the model gets changed
  const CUSTOM_VALUE_ACCESSOR = {
      provide:NG_VALUE_ACCESSOR,
      useExisting: forwardRef(() => TinymceEditorDirective),
      multi: true
    };

  @Directive({
    selector: '[tinyEditor]',
    providers: [CUSTOM_VALUE_ACCESSOR]
  })
  export class TinymceEditorDirective implements AfterViewInit, ControlValueAccessor, OnChanges  {
    private val : any = '';
    teditor:any;
    @Input('tinyEditor') tinyEditor:string;
    // selector string: Id of the host element
    @Input() selector: string;

    // Getter and setters for tinymceModel binding
    @Input()
    get tinymceModel(){
      return this.val;
    }

    set tinymceModel(val){
      this.val = val;
    }

    // This is used to update the model on view update
    @Output() tinymceModelChange = new EventEmitter();


    // All the options needed for tinymce editor
    private options = {
      // plugins: [
      //   'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      //   'searchreplace wordcount visualblocks visualchars fullscreen code',
      //   'insertdatetime media nonbreaking save table contextmenu directionality',
      //   'emoticons template paste textcolor colorpicker textpattern imagetools codesample'
      // ],
      // toolbar1: `insertfile undo redo | styleselect | bold italic
      // | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent
      // | link image`,
      // toolbar2: 'print preview media | forecolor backcolor emoticons | codesample',
      // image_advtab: true
       plugins: [
         'table lists link'
       ],
       inline:true,
       skin_url: 'assets/skins/lightgray'
    };

    // ChangeDetectorRef is used to update angular component tree whenver a blur event occurs to trigger all the validations
    constructor(private changeDetectorRef: ChangeDetectorRef, private elRef: ElementRef) {
    }

    // registerOnChange, registerOnTouched, writeValue are methods need to be implemented for the interface ControlValueAccessor
    onChange = (_) => {};
    onTouched = () => {};

    registerOnChange(fn: (_: any) => void): void { this.onChange = fn; }
    registerOnTouched(fn: () => void): void { this.onTouched = fn; }

    // This method is called whenever model gets updated
    writeValue(value: any): void {
        // This check is necessary because, this method gets called before editor
        // gets initialised. Hence undefined/null pointer exceptions gets thrown
        if(tinymce.get(this.selector)) {
          tinymce.get(this.selector).setContent(value, {format : 'raw'});
        }
    }

    // Update the component tree only when blur event happens. Otherwise following bug will occur.
    // Cursor position changes to 0 or the begining of the editor after every event.
    valueChange() {
      this.valueOnChange(false);
    }

    valueOnChange(change:boolean) {
      if(tinymce.activeEditor) {
      this.val = tinymce.activeEditor.getContent();
      this.tinymceModelChange.emit(this.val);
      if(change) {
        this.changeDetectorRef.detectChanges();
      }
    }
    }
    // Cursor position changes to 0 or the begining of the editor if we dont check the below
    ngOnChanges(changes: SimpleChanges) {

      if(tinymce.activeEditor && changes['tinymceModel'] && changes['tinymceModel'].currentValue) {
        if(tinymce.activeEditor.getContent() !== changes['tinymceModel'].currentValue) {
         this.elRef.nativeElement.innerHTML = changes['tinymceModel'].currentValue;
        }
      }

    }

    ngAfterViewInit() {
      const that = this;
      const options : any = this.options;

      if(this.selector) {
        options['selector'] = '#' + this.selector + '.tinyMceEditor';
      } else {
        options['selector'] = '.wysiwyg';
      }
      const org = window.location.origin;
      options['document_base_url'] = (org.indexOf('localhost:4200') !== -1) ? '' : relativePath;

      options['height'] = 100;
      options['schema'] = 'html5';
      options['theme'] = 'modern';

      // write the model value to tinymce editor once gets initialised. And track input and change events
      options['init_instance_callback'] = function (editor) {

        if(that.tinymceModel) {
          that.writeValue(that.tinymceModel);
        }
        editor.on('change', function (e) {
          that.valueChange();
        });
        editor.on('blur', function (e) {
          that.valueOnChange(true);
        });
        editor.on('keyup', function (e) {
          that.valueChange();
        });
        editor.on('PastePostProcess', function (e) {
          that.valueChange();
        });
      };

    //  console.log(options);

      tinymce.init(options);
    }

  }
