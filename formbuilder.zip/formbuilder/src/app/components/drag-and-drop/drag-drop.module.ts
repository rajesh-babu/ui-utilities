import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { DragAndDropComponent} from './drag-drop.component';
import { AsideService} from '../../services/AsideService';
import { CustomCommonsModule } from '../../shared/customCommons.module';
import { DragulaModule} from 'ng2-dragula';
import { HttpService} from '../../services/HttpService';
import { FieldsFactoryService } from '../../services/fields/FieldsFactory.service';
import { GlobalService} from '../../services/GlobalService';
import { CommonsFieldsService} from '../../services/fields/CommonsFieldsService';
import { ModalModule  } from 'ngx-bootstrap';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    DragulaModule,
    ModalModule.forRoot()
  ],
  declarations: [
    DragAndDropComponent
  ],
  exports:[DragAndDropComponent],
  providers: [AsideService, HttpService, FieldsFactoryService, GlobalService, CommonsFieldsService],
  entryComponents: [ DragAndDropComponent ]
})
export class DragandDropModule { }
