import { Component, ComponentFactoryResolver, ViewContainerRef, ViewChild, ComponentRef,
         OnInit, EventEmitter, Input, Output } from '@angular/core';
import { Constants } from '../../services/Constants';
import { UtilityService} from '../../services/UtilityService';
import { GlobalService} from '../../services/GlobalService';
import { FieldsFactoryService } from '../../services/fields/FieldsFactory.service';
import { HttpService} from '../../services/HttpService';
import { FormValidModalComponent } from '../pages/modals/validation/form-valid.comp';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { MulticolValidModalComponent } from '../pages/modals/validation/multicol-valid.comp';

declare var $:any;

@Component({
  selector: 'drag-drop',
  templateUrl: './drag-drop.component.html'
})
export class DragAndDropComponent implements OnInit {
  public deleteGroupPopupMessage:string = '';
  public deleteGroupPopupTitle:string = '';
  public gMindexPos:number;
  public gMgrpIndexPos:number;
  public gMcolIndexPos:number;
  public beforePagePosition:number;
  public afterPagePosition:number;
  public selectedPagePosition:number;

 @ViewChild('widgetContainer', {read: ViewContainerRef}) widgetContainer;
 @Output() onaddpage:EventEmitter<any> = new EventEmitter();
 @ViewChild('formValidModalComp') formValidModalComp: FormValidModalComponent;
 @ViewChild('deleteGroupPopupModal') deleteGroupPopupModal:ModalDirective;
 @ViewChild('deleteGroupModal') deleteGroupModal:ModalDirective;
 @ViewChild('deleteCondGroupModal') deleteCondGroupModal:ModalDirective;
 @ViewChild('newPagePositionModal') newPagePositionModal:ModalDirective;
 @ViewChild('multicolValidModal') multicolValidModal:MulticolValidModalComponent;

 @Input() isShow:boolean;
 public indexPos:number;
 cmpRef: ComponentRef<Component>;
 compPosition:number = 0;
 initDrag:Boolean = false;

 fieldsMapping:any = {};
 dragandDropContainerSelector = '.form-all';

 public constructor( private componentFactoryResolver: ComponentFactoryResolver, private fieldsFactoryService: FieldsFactoryService,
                     private constants:Constants, public utilityService:UtilityService,
                     private httpService:HttpService, public globalService:GlobalService) {}
 /*
  * This will be triggered from stage.comp when duplicating the field
  */
 public duplicateField(obj) {
   this.compPosition = obj['indexPos'] + 1;
   this.removeExistingSelectedCls($(this.dragandDropContainerSelector));
   // ToDo - remove the field property
   this.addComponent(this.fieldsFactoryService.getComponent(obj['field']), 'duplicate', obj['values']);
 }
 /*
  * This will be triggered from stage.comp when duplicating the group field
  */
 public duplicateGrpField(obj) {
   this.widgetContainer.get(obj.values.indexPos)._view.nodes[1].instance['duplicateField'](obj);
 }

 /*
  * This will be triggered from stage.comp when deleting the row
  */
 public deleteRow(obj) {

    (this.widgetContainer.get(obj.indexPos)).destroy();

     // Delete the Global App data
     this.globalService.deleteappData(obj.indexPos);

     // Reorder the index positions for existing component(s)
     const timeoutId = setTimeout(() => {
       this.reorderIndexPos($(this.dragandDropContainerSelector));
     }, 100);
 }

 /*
  * This will be triggered from stage.comp when deleting any of the columns.
  */
 public deleteMultiCol(obj) {
   // Fix for group field multicol in Prod Build
   if(!this.widgetContainer.get(obj.indexPos)._view.nodes[1].instance.hasOwnProperty('groupFieldModel')) {
     this.widgetContainer.get(obj.indexPos)._view.nodes[1].instance['onDelete'](obj);
   }else {
     this.checkInConditions(obj);
   }
 }
 /*
  * This will be triggered from stage.comp when deleting any of the group fields.
  */
 public deleteGroupField(obj) {
   if(obj.hasOwnProperty("msgPopup")) {
     if(obj.fieldType===this.constants.MULTICOL) {
       this.deleteGroupPopupTitle = this.constants.POPUP_MULTICOL_TITLE;
       this.deleteGroupPopupMessage =this.constants.DELETE_POPUP_MESSAGE + " multi column.";
     }
     this.deleteGroupPopupModal.show();
   } else {
     this.checkInConditions(obj);
   }
 }

 /*
  * On clicking the 'Yes' in delete modal, delete form element and hide modal
  */
 onYesDeleteGroupClick($ele, indexes:any):void {
   $ele.hide();
   if(indexes.hasOwnProperty("gMcolIndexPos") && indexes.gMcolIndexPos!==1234) {
     const obj = {indexPos:indexes.gMindexPos,grpIndexPos:indexes.gMgrpIndexPos,colIndexPos:indexes.gMcolIndexPos};
     this.widgetContainer.get(obj.indexPos)._view.nodes[1].instance.widgetGroupField.get(obj.grpIndexPos)._view.nodes[1].instance['onDelete'](obj);
   } else {
     const obj = {indexPos:indexes.gMindexPos,grpIndexPos:indexes.gMgrpIndexPos};
     this.widgetContainer.get(obj['indexPos'])._view.nodes[1].instance['onDelete'](obj);
   }
 }

 /*
  * It will be triggered when internally from deleteGroupField
  */
 checkInConditions(obj:any) {
   const gIndexPos = obj.indexPos;
   const grpIndexPos = obj.grpIndexPos;
   const refId = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][gIndexPos]['refId'];
   if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],refId)) {
     this.deleteCondGroupModal.show();
   } else if((this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][gIndexPos]).hasOwnProperty("groupFields")) {
       const groupFields = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][gIndexPos]['groupFields'];
       let isgroupFieldsinCondition = false;
       for (let i = 0; i < groupFields.length; i++) {
           if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],groupFields[i]['refId'])) {
             isgroupFieldsinCondition=true;
           }
           if(groupFields[i].type===this.constants.MULTICOL && obj.hasOwnProperty("colIndexPos") && groupFields[i].grpRowIndex===obj.grpIndexPos) {
             if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],groupFields[i].fieldsObj['col'+obj.colIndexPos]['refId'])) {
               isgroupFieldsinCondition=true;
             }
           }
           if(groupFields[i].type===this.constants.BUTTON_FIELD && (groupFields[i]).hasOwnProperty("buttons")) {
             const buttonsInGroup = groupFields[i]['buttons'];
             for (let buttons = 0; buttons < buttonsInGroup.length; buttons++) {
               if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],buttonsInGroup[buttons]['buttonRefId'])) {
                 isgroupFieldsinCondition=true;
               }
             }
           }
           if (groupFields[i].type === this.constants.GRIDTABLE_FIELD) {
               for(let k=0; k<groupFields[i].columns.length; k++) {
                 let columnRefId;
                 if(groupFields[i].columns[k].rowFieldConf.name) {
                   columnRefId=groupFields[i].columns[k].rowFieldConf.refIdName;
                 }
                 if(groupFields[i].columns[k].rowFieldConf.radioName) {
                   columnRefId=groupFields[i].columns[k].rowFieldConf.refIdRadioName;
                 }
                 if(groupFields[i].columns[k].rowFieldConf.textName) {
                   columnRefId=groupFields[i].columns[k].rowFieldConf.refIdTextName;
                 }
                 if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],columnRefId)) {
                   isgroupFieldsinCondition = true;
                 }
               }
           }
       }
       if(isgroupFieldsinCondition) {
         this.deleteCondGroupModal.show();
       } else {
         this.gMindexPos = obj.indexPos;
         this.gMgrpIndexPos = obj.grpIndexPos;
         this.gMcolIndexPos = (obj.colIndexPos>-1)?obj.colIndexPos:1234;
         this.deleteGroupModal.show();
       }
     }
   }

 /*
  * This will be triggered when adding new page
  */
 public reLoadFields(selPgIndex:number) {
  this.compPosition = 0;
  this.widgetContainer.clear();
  const _data = this.globalService.appData[selPgIndex];
  for(let i=0; i<_data.length; i++) {
    this.addComponent(this.fieldsFactoryService.getComponent(_data[i].type), 'reloadFields', _data[i]);
  }
 }

  /*
   * It removes the "selected" class to dropped item
   */
  removeExistingSelectedCls(_$formAllEle:any) {
    _$formAllEle.find(this.constants.DROPPEDITEM_CLS).removeClass(this.constants.SELECTED);
  }
  reorderIndexPos(_$formAllEle:any) {
    const thisRef = this;
    _$formAllEle.find(this.constants.DROPPEDITEM_CLS).each(function(i) {

       // Remove class starts with 'comp_'
       $(this).removeClass(function () {
           const className = this.className.match(/comp_\d+/);
           if (className) {
               return className[0];
           }
       });
       $(this).addClass('comp_'+i);

        // For Group container child elements, Remove class starts with 'parentRowIndex_' and add it orderlly
        $(this).find('.'+thisRef.constants.droppedGrpItemCls)
          .removeClass(function () {
            const className = this.className.match(/parentRowIndex_\d+/);
            if (className) {
                return className[0];
            }
          })
          .addClass('parentRowIndex_'+i);
    });
    this.globalService.addUpdateAllIndexPos();
  }

  // (0 - bagname, 1 - el, 2 - target, 3 - source, 4 - sibling)
   public onDrop(value) {
   
       if(value[2] == null) { // dragged outside any of the bags and right to left
           return;
       }

       if(value[2].classList.contains('multiCol') ) { // IF dropped at multi column layout
         const curreIndexPos = this.utilityService.getCompIndexPos( $(value[2]).closest(this.constants.DROPPEDITEM_CLS).attr('class'));

         // Check if previous column is empty
         const previousColField = $(value[2].previousElementSibling);
         const containrRef = this.widgetContainer.get(curreIndexPos)._view.nodes[1].instance;
         if(previousColField.hasClass('multiCol')) {
           if(!previousColField.hasClass('added') && containrRef.hasOwnProperty('multicolModel')) {
            // cancel drop event only if multicol
            containrRef.dragulaService.bags[0].drake.cancel(true);
            this.multicolValidModal.showModal(this.constants.MULTICOL_DROP_ERR_MSG);
           } else if (!previousColField.hasClass('added') && containrRef.hasOwnProperty('groupFieldModel')){
             // cancel drop event if multi col is inside group field
            containrRef.dragulaService.bags[0].drake.cancel(true);
             this.multicolValidModal.showModal(this.constants.MULTICOL_DROP_ERR_MSG);
           } else {
            containrRef['onDrop'](value);
           }
         } else{
            containrRef['onDrop'](value);
         }
        
         return;
       }

       // If field dropped inside the group field
       if(value[2].classList.contains(this.constants.GROUP_FIELD) ) {

         // Dont allow widgets dropped inside the group field.
         if(!$(value[3]).hasClass('basicTab')) {
           value[1].outerHTML = '';
           return;
         }
         const curreIndexPos = this.utilityService.getCompIndexPos( $(value[2]).closest(this.constants.DROPPEDITEM_CLS).attr('class'));
         this.widgetContainer.get(curreIndexPos)._view.nodes[1].instance['onDrop'](value);
         return;
       }

       const $formAllEle = $(this.dragandDropContainerSelector);
       if($(value[3]).hasClass('fieldSection-list')) {

         value[1].outerHTML = '';
         if(!value[4]) { // If it's dropped as last element
           this.compPosition = $formAllEle.find(this.constants.DROPPEDITEM_CLS).length;
         }else if(this.initDrag && value[4]) {
           this.compPosition = this.utilityService.getCompIndexPos( $(value[4]).find(this.constants.DROPPEDITEM_CLS).attr('class'));
         }

         this.removeExistingSelectedCls($formAllEle);
         let dtObj = value[1].getAttribute('data-obj'); // Determine whether the component under the Section tab
         dtObj = JSON.parse(dtObj);
         if(dtObj && dtObj['type'] === 'custom') {// For Sections
           const _t = this;
          this.httpService.getSectionDet( dtObj).subscribe(function(dt){
            if(dt && dt['pages']) { // dt['secFieldsArr']
            dt['refId'] = _t.utilityService.timeasRefId();
              _t.addComponent(_t.fieldsFactoryService.getComponent(dt['type']), 'populate', dt);
            }
            // if(!_t.formValidModalComp['validateForm']()) {
              // _t.formValidModalComp['showModal']();
            // }
          });
         }else {
           this.addComponent(this.fieldsFactoryService.getComponent(value[1].getAttribute('data-fieldname')), 'new', {});
         }

       } else {// when sorting

          /* START - Need to rearrange the position for 'ViewContainerRef' manually because while we sort it wont update
              the WidgetContainer index position and there will be an issue when drag and drop the new component and
              getting the index position*/

          // Get the normal fields position
          let $regField =  $(value[3]).find('.'+this.constants.SELECTED);

          if(!$regField.length) { // Get the Multi column field position
            $regField =  $(value[3]).closest('.'+this.constants.SELECTED);
          }
          const currentIndexPos = this.utilityService.getCompIndexPos($regField.attr('class'));
          let targetIndexPos: any;
          if(!value[4]) { // If it's dropped as last element
            targetIndexPos = $formAllEle.find(this.constants.DROPPEDITEM_CLS).length-1;
          }else {
            const clsNames = $(value[4]).find(this.constants.DROPPEDITEM_CLS).attr('class');
            targetIndexPos  = (clsNames) ? this.utilityService.getCompIndexPos(clsNames) : 0;
            // Dont count if dropped the component above the existing components
            if(targetIndexPos > currentIndexPos) {
              targetIndexPos -= 1;
            }
          }
          // Reposition the WidgetContainer indexposition accordingly
          this.widgetContainer.move(this.widgetContainer.get(currentIndexPos), targetIndexPos);
          /* END */

          // Change the index position for global app data
          this.globalService.appJSONRearrange(currentIndexPos, targetIndexPos);

          // Focus to dropped item when sorting
          $(value[1]).find(this.constants.DROPPEDITEM_CLS).addClass(this.constants.SELECTED);

       }
       const timeoutId = setTimeout(() => {
         this.reorderIndexPos($formAllEle);
       }, 100);
   }

   addComponent(selectedComp:any, mode:string, values:any) {

     let _selected = '';
     const factory = this.componentFactoryResolver.resolveComponentFactory(selectedComp['type']);

     // Determine the selected class based on mode of the creation
     _selected = (mode === 'populate' || mode === 'reloadFields') ? '' : this.constants.SELECTED;

     this.cmpRef = this.widgetContainer.createComponent(factory, this.compPosition);

     this.cmpRef['instance']['className'] =  'droppedItemContainer ' + this.constants.DROPPEDITEM + ' ' + _selected + ' comp_'+ this.compPosition;

    // Send the values if prepulating or duplicating
     let existingValue;
     if(mode === 'populate' || mode === 'duplicate' || mode === 'reloadFields') {

       // Dont use the existing refID and isConditional flag when duplicating the field.
       if(mode === 'duplicate') {
         values = this.globalService.generateRefIds(values);
       }
       existingValue = values;
     }

     // When swtiching between pages set the flag in order to dont add it to AppData array
     let isReLoadFields:boolean;
     isReLoadFields = (mode === 'reloadFields') ? true : false;

     this.cmpRef['instance']['setAppData'](existingValue, this.compPosition, isReLoadFields);

     // Set subtype for Text area
     if(selectedComp['subType']) {
       this.cmpRef['instance']['setSubType'](selectedComp['subType'], this.compPosition);
     }

     // Set the data to corrosponding component's method called "setExistingData"
     if(mode === 'populate' || mode === 'reloadFields') {
       this.compPosition += 1;
     }

     // Remove the "Drag & Drop here" placeholder
     if(this.globalService.appData[this.globalService.selectedIndexPgArr].length > 1) {
       $('.plHm').remove();
     }

     this.initDrag = true;

     // reorder the index position of rest of the components if it's duplicated
     if(mode === 'duplicate') {
       const timeoutId = setTimeout(() => {
         this.reorderIndexPos($(this.dragandDropContainerSelector));
       }, 100);
     }
   }
   ngOnInit() {
     // $('.container-fluid.wrapper').height( $( window ).height()-70);


     const pgArr:any = this.globalService.appData[0];

     // Load the Header for new section
     if(this.utilityService.formMode === 'Section') {
       if(pgArr.length === 0) {
         this.addComponent(this.fieldsFactoryService.getComponent(this.constants.TITLE_FIELD), 'new', {});
         this.addComponent(this.fieldsFactoryService.getComponent(this.constants.SECTION), 'new', {});
         this.addComponent(this.fieldsFactoryService.getComponent(this.constants.PAGE_FIELD), 'new', {});
       }
     }
     // Load the Page field for new form
     if(this.globalService.appData[this.globalService.selectedIndexPgArr].length === 0) {
       this.addComponent(this.fieldsFactoryService.getComponent(this.constants.PAGE_FIELD), 'new', {});
     }
   }

  /*
   * This will be called when clicking the add page button
   */
  public addPage() {
    if(this.globalService.selectedIndexPgArr===0 && this.globalService.appGlobalData.pages.length > 1) {
      // show Modal window
      this.beforePagePosition=this.globalService.selectedIndexPgArr-1;
      this.afterPagePosition=this.globalService.selectedIndexPgArr;
      this.selectedPagePosition=this.globalService.selectedIndexPgArr+1;
      this.newPagePositionModal.show();
    } else {
      this.onaddpage.emit(this.globalService.selectedIndexPgArr);
    }
  }
  public positionNewPage(modal,obj:any) {
    modal.hide();
    this.onaddpage.emit(obj.pagePosition);
  }
}
