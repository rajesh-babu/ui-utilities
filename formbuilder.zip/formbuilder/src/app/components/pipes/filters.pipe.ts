import { Pipe, PipeTransform } from '@angular/core';
@Pipe({
    name: 'conditionFilter',
    pure: false
})
export class ConditionFilterPipe implements PipeTransform {
    transform(items: any[], filter: any): any {
        if (!items || !filter) {
            return items;
        }
        // filter items array, items which match and return true will be kept, false will be filtered out
        return items.filter(item => (item.fields)?item.fields.indexOf(filter) !== -1:item);
    }
}
