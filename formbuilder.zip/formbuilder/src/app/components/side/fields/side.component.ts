import { Component, OnInit} from '@angular/core';
import { Constants } from '../../../services/Constants';
import { UtilityService } from '../../../services/UtilityService';
import { HttpService} from '../../../services/HttpService';

@Component({
  selector: 'side-fields',
  templateUrl: './side.component.html'
})

export class SideFieldsComponent implements OnInit {
  public sections:any;
  constructor(public constants:Constants, public utilityService:UtilityService, private httpService:HttpService ) {}
  ngOnInit() {
    this.updateSecList();
  }
  /*
   * It will be triggered when page load and clicking the Refresh Button
   */
  public updateSecList() {
    this.sections = this.httpService.getSectionsList();
  }
  /*
   * It will be triggered when clickcing the 'Create Section' section.
   */
  public createNewSection() {
    const win = window.open(window.location.origin + this.utilityService.appContext +'ContentServer?d=&pagename=TIAA/DFF/FormBuilder&mode=Section&appAction=Create&siteName='
    + this.utilityService.siteName,  '_blank');
     win.focus();

  }
}
