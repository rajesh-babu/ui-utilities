import { Component } from '@angular/core';
import { Constants } from '../../../services/Constants';
import { GlobalService } from '../../../services/GlobalService';
import { UtilityService } from '../../../services/UtilityService';
declare var $:any;

@Component({
  selector: 'side-settings',
  templateUrl: './settings.component.html'
})

export class SideSettingsComponent {
  constructor(private globalService:GlobalService, public constants:Constants,
              public utilityService:UtilityService) {}
  /*
   * It will be triggered upon clicking the menu items, toggle the 'selected' class
   */
  menuClicked(evt: Event, type: any):void {
    const $ele = $(evt.currentTarget);
    this.globalService.selSettings = type;
    $ele.siblings('li').removeClass('selected');
    $ele.addClass('selected');
  }
}
