import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SettingsPageComponent } from './settings-page.component';
import { FormAttrPgComponent } from './form-attr.comp';
import { ConditionFilterPipe } from '../../pipes/filters.pipe';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { MultiSelectModule } from 'primeng/primeng';

@NgModule({
  imports: [
    BrowserModule, FormsModule, ReactiveFormsModule, CustomCommonsModule, MultiSelectModule
  ],
  declarations: [
    SettingsPageComponent, ConditionFilterPipe, FormAttrPgComponent
  ],
  exports: [
    SettingsPageComponent
  ],
  providers: [],
  entryComponents: [  ],
})
export class SettingsPageModule { }
