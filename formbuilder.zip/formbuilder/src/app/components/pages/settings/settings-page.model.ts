declare var $:any;
export class SettingsPageModel {
public conditions:Array<Object> = [];
constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class FormAttrModel {
  public FormTitle:string;
  public FormName:string;
  public FormId:string;
  public FormAction:string;
  public FormMethodType:string = 'post';
  public FormFieldRequired:string = 'yes';
  public MetadataServiceName:string;
  public MetadataRoles:string;
  public MetadataFormResource:string;
  public MetadataDescription:string;
  public MetadataPortalDocDesc:string;
  public MetadataDocCode:string;
  public DocumentTypeId:string;
  public MetadataProductAndService:string;
  public MetadataPrintFieldsToRemove:string;
  public MetadataMailFieldsToRemove:string;
  public MetadataEDeliverFieldsToRemove:string;
  public Archive:string = 'no';
  public DCRS:string = 'no';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
