import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SettingsPageModel, FormAttrModel } from './settings-page.model';
import { GlobalService } from '../../../services/GlobalService';
import { FieldControlsService} from '../../../services/FieldControlsService';
import { FormsModule } from '@angular/forms';
import { Constants } from '../../../services/Constants';
import { ControlMessagesComponent } from '../../../shared/validations/control-messages.comp';
import { ValidationService } from '../../../shared/validations/validation.service';

declare var $:any;

@Component({
  selector: 'form-attr-page',
  templateUrl: './form-attr.comp.html'
})
export class FormAttrPgComponent implements OnInit  {

  formAttr:FormAttrModel = new FormAttrModel();
  attributesForm : any;
  isFormAttrSubmitted:boolean;

  // showConditionDetail
  public constructor(public globalService:GlobalService, public constants:Constants, private fieldControlsService:FieldControlsService, private formBuilder: FormBuilder) {

    this.attributesForm = this.formBuilder.group({
     'FormTitle': [this.formAttr.FormTitle, [Validators.required]],
     'FormName': [this.formAttr.FormName, [Validators.required]],
     'FormId': [this.formAttr.FormId, [Validators.required]],
     'FormAction': [this.formAttr.FormAction, [Validators.required]],
     'FormMethodType': [this.formAttr.FormMethodType, [Validators.required]],
     'FormFieldRequired': [this.formAttr.FormFieldRequired, [Validators.required]],
     'MetadataServiceName': [],
     'MetadataRoles': [],
     'MetadataFormResource': [],
     'MetadataDescription': [],
     'MetadataPortalDocDesc': [],
     'MetadataDocCode': [],
     'DocumentTypeId': [],
     'MetadataProductAndService': [],
     'MetadataPrintFieldsToRemove': [],
     'MetadataMailFieldsToRemove': [],
     'MetadataEDeliverFieldsToRemove': [],
     'MetadataConfirmationTxt': [],
     'Archive': [],
     'DCRS': []
   });
  }

  ngOnInit() {

    if(localStorage.getItem('FormData')) {
      // this.formAttr = JSON.parse(localStorage.getItem('FormData'));
    }

    if($.isEmptyObject(this.globalService.appGlobalData.settings.form)) {
      this.globalService.appGlobalData.settings.form = this.formAttr = new FormAttrModel();
    }else { // Load Existing Data
      this.formAttr = this.globalService.appGlobalData.settings.form;
    }
  }

  // Form Attributes Save Button Click
  saveFormAttr() {
    this.isFormAttrSubmitted = true;

    if(this.attributesForm.valid) {
      localStorage.setItem('FormData', JSON.stringify(this.formAttr));
      this.fieldControlsService.onsaveFormattr({});
    }
  }
}
