import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { SettingsPageModel, FormAttrModel } from './settings-page.model';
import { GlobalService } from '../../../services/GlobalService';
import { FieldControlsService} from '../../../services/FieldControlsService';
import { FormsModule } from '@angular/forms';
import { Constants } from '../../../services/Constants';
import { ControlMessagesComponent } from '../../../shared/validations/control-messages.comp';
import { ValidationService } from '../../../shared/validations/validation.service';
import { UtilityService } from '../../../services/UtilityService';
import { SelectItem } from 'primeng/primeng';
declare var $:any;
@Component({
  selector: 'settings-page',
  templateUrl: './settings-page.component.html'
})
export class SettingsPageComponent implements OnInit  {
  showConditions:boolean = true;
  showSuccess:boolean = false;
  showConditionHome:boolean = true;
  showConditionDetail:boolean = false;
  showValidation:boolean = false;
  validationCounter:any = 0;
  fieldType:Array<Object> = [];
  conditions:Array<Object> = [];
  valueArray:Array<any> = [];
  formJson:Array<any> = [];
  formJsonIf:Array<any> = [];
  formJsonComplete:Array<Object> = [];
  conditionData:any = {};
  addCondition:boolean = true;
  conditionIndex:any = -1;
  conditionCounter:any = 0;
  doFieldMultipleSelectionArray: any;
  // showConditionDetail
  public constructor(public globalService:GlobalService, public constants:Constants, private fieldControlsService:FieldControlsService,
                     private formBuilder: FormBuilder, private utilityService:UtilityService) {
    // this.updateFormFieldArrays();

    // Update the source and target references
    this.globalService.updateConditionalData();
  }
  multipleDoFieldArray() {
    this.doFieldMultipleSelectionArray = [];
    for(let k=0; k<this.formJson.length; k++) {
        const doFieldDisplayData = this.formJson[k].componentName + ((this.formJson[k].name) ? ' - '+this.formJson[k].name : '');
        const obj:any = {label:doFieldDisplayData, value:{name:this.formJson[k].name, refId:this.formJson[k].refId, type:this.formJson[k].type}};
        if(this.formJson[k].hasOwnProperty('refIdIndex')) {
          obj.value.refIdIndex = this.formJson[k].refIdIndex;
        }
        if(this.formJson[k].hasOwnProperty('componentName')) {
          obj.value.componentName = this.formJson[k].componentName;
        }
        this.doFieldMultipleSelectionArray.push(obj);
    }
  }

  updateConditionsArray(field) {
    if(field.numberofFields > 0) {
      for(let k=0; k<field.numberofFields; k++) {
        const fieldName = field['name'+(k+1)];
        if(fieldName) {
          this.formJson.push({'componentName':field.componentName,'name':fieldName, refId:field.refId, type:field.type, refIdIndex:k});
        }
      }
    } else if (field.type === this.constants.BUTTON_FIELD) {
        for(let k=0; k<field.buttons.length; k++) {
          if(field.buttons[k].name) {
            this.formJson.push({'componentName':'Button','name':field.buttons[k].name,refId:field.buttons[k].buttonRefId, type:field.type});
          }
        }
    } else if (field.type === this.constants.GRIDTABLE_FIELD) {
        if(field.name) {
          this.formJson.push({'componentName':'Grid Table','name':field.name,refId:field.refId, type:field.type});
        }
        for(let k=0; k<field.columns.length; k++) {
          if(field.columns[k].rowFieldConf.name) {
            const obj = {'componentName':'Grid Table(field)','name':field.columns[k].rowFieldConf.name,
            refId:field.columns[k].rowFieldConf.refIdName, type:this.constants.TXT_FIELD, refIdIndex:k};
            this.formJson.push(obj);
            this.formJsonIf.push(obj);
          }
          if(field.columns[k].rowFieldConf.radioName) {
            const obj = {'componentName':'Grid Table(field)','name':field.columns[k].rowFieldConf.radioName,
            refId:field.columns[k].rowFieldConf.refIdRadioName, type:this.constants.RADIO_FIELD, refIdIndex:k, options: field.columns[k].radioOptions};
            this.formJson.push(obj);
            this.formJsonIf.push(obj);
          }
          if(field.columns[k].rowFieldConf.textName) {
            const obj = {'componentName':'Grid Table(field)','name':field.columns[k].rowFieldConf.textName,
            refId:field.columns[k].rowFieldConf.refIdTextName, type:this.constants.TXT_FIELD, refIdIndex:k};
            this.formJson.push(obj);
            this.formJsonIf.push(obj);
          }
        }
    } else if (field.type === this.constants.MULTICOL) {
      for(let k=0;k<4;k++) {
        if(typeof field.fieldsObj['col'+k] !== "undefined") {
          if(typeof field.fieldsObj['col'+k].name !== "undefined") {
            this.formJson.push(field.fieldsObj['col'+k]);
          }
        }
      }
    } else {
      if(field.name) {
        this.formJson.push(field);
      }
    }
    // Update fields for IF selection
    if(field.type === this.constants.CHECKBOX_FIELD || field.type === this.constants.SELECT_FIELD ||
      field.type === this.constants.RADIO_FIELD || field.type === this.constants.TXT_FIELD) {
        if(field.name) {
          this.formJsonIf.push(field);
        }
    }

  }

  updateFormFieldArrays() {

    this.formJsonIf = [];
    this.formJson = [];
    this.formJsonIf.push({componentName:'Please Select a Field'});

    this.formJsonComplete = this.globalService.appData;


    if(this.formJsonComplete.length) {
      for(let i=0; i<this.formJsonComplete.length; i++) {
        const page:Array<any> = this.formJsonComplete[i] as Array<any>;
        if(page.length) {
          for(let j=0;j<page.length;j++) {
            if (page[j].type === this.constants.GROUP_FIELD) {
              // Push address utility group
              if (page[j].category === 'addressUtility') {
                this.updateConditionsArray(page[j]);
              }
                for(let k=0; k<Object.keys(page[j].groupFields).length; k++) {
                    this.updateConditionsArray(page[j].groupFields[k]);
                }
            } else if (page[j].type === this.constants.MULTICOL) {
              for(let k=0;k<Object.keys(page[j].fieldsObj).length;k++) {
                  this.updateConditionsArray(page[j].fieldsObj['col'+k]);
              }
            } else if (page[j].type === this.constants.PAGE_FIELD) {

              page[j]['name'] = (i+1);

              this.updateConditionsArray(page[j]);
            } else if (page[j].type === this.constants.SEC_CONTAINER) {
              this.updateConditionsArray(page[j]);
              const sectionPages = page[j].pages;
              for (let k = 0; k < sectionPages.length; k++) {
                const sectionField = sectionPages[k];
                for (let l = 0; l < sectionField.length; l++) {
                 if(sectionField[l].type === this.constants.PAGE_FIELD) {
                    sectionField[l]['name'] = (i+1)+' - Widget->Page '+(k+1);
                    this.updateConditionsArray(sectionField[l]);
                  } else if (sectionField[l].type === this.constants.GROUP_FIELD) {
                      for(let m=0; m<Object.keys(sectionField[l].groupFields).length; m++) {
                          const groupField = sectionField[l].groupFields[m];
                          if (groupField.type === this.constants.MULTICOL) {
                            for(let n=0; n<4; n++) {
                                if(typeof groupField.fieldsObj['col'+n] !== "undefined") {
                                  this.updateConditionsArray(groupField.fieldsObj['col'+n]);
                                }
                            }
                          } else {
                            this.updateConditionsArray(sectionField[l].groupFields[m]);
                          }
                      }
                  } else if (sectionField[l].type === this.constants.MULTICOL) {
                    for(let m=0; m<4; m++) {
                        if(sectionField[l].fieldsObj['col'+m]) {
                          this.updateConditionsArray(sectionField[l].fieldsObj['col'+m]);
                        }
                    }
                  } else if(sectionField[l].type !== this.constants.SECTION && sectionField[l].type !== this.constants.PAGE_FIELD
                       && sectionField[l].type !== this.constants.TITLE_FIELD && sectionField[l].type !== this.constants.GROUP_FIELD
                       && sectionField[l].type !== this.constants.MULTICOL) {
                      this.updateConditionsArray(sectionField[l]);
                    }
                }
              }
            } else {
              this.updateConditionsArray(page[j]);
            }
          }
        }
      }
    }
    this.multipleDoFieldArray();
  }
  // Toggle Condition Home page and Details page
  showSection(type: String) {
    this.showConditionHome = false;
    this.showConditionDetail = false;
    if(type === 'showConditionHome') {
      this.showConditionHome = true;
    } else if(type === 'showConditionDetail') {
      this.showConditionDetail = true;
    }
  }
  // On change of IF dropdown. Used to save selected field for filter purpose
  onIfidChange(value: any) {
    this.conditionData.fieldType = this.formJsonIf[value.selectedIndex].type;
    this.conditionData.sourceRegex = '';
    if(this.conditionData.fieldType === this.constants.CHECKBOX_FIELD ||
      this.conditionData.fieldType === this.constants.SELECT_FIELD ||
      this.conditionData.fieldType === this.constants.RADIO_FIELD) {
        this.valueArray = this.formJsonIf[value.selectedIndex].options;
    }
    this.conditionData.ifRefId = this.formJsonIf[value.selectedIndex].refId;

    if(this.formJsonIf[value.selectedIndex].componentName) {
      this.conditionData.componentName = this.formJsonIf[value.selectedIndex].componentName;
    }

    this.conditionData.condState = '';
  }
  // On change of IF dropdown. Used to save selected field for filter purpose
  onIfvalueChange(value: any) {
    this.conditionData.sourceRegex = '';
    if(this.conditionData.fieldType === this.constants.CHECKBOX_FIELD ||
      this.conditionData.fieldType === this.constants.SELECT_FIELD ||
      this.conditionData.fieldType === this.constants.RADIO_FIELD) {
        this.conditionData.optionRefId = this.valueArray[value.selectedIndex].optionRefId;
    } else {
        this.conditionData.optionRefId = '';
    }
  }
  // On change of IF STATE dropdown. Used to hide VALUE in case of isEmpty or isFilled
  onIfStateChange(value: any) {
    if(value === 'isEmpty' || value === 'isFilled') {
      this.conditionData.showTarget = false;
    } else {
      this.conditionData.showTarget = true;
    }
  }
  // Form Validation
  validateForm() {
    // validationCounter will be set to 0 initially
    // If both IF and STATE is not selected , then validation counter increamented
    if(!(this.conditionData.condIf && this.conditionData.condState)) {
      this.validationCounter++;
    }
    // If TARGET is selected either VALUE or FIELD should be filled , else validation counter increamented
    if(this.conditionData.showTarget) {
      if(!(this.conditionData.value) && this.conditionData.condState !== 'change') { // No need to validate value for state is "change"
        this.validationCounter++;
      }
    }
    // Looping through number of DO items if DO items lenght is 0. Else validation counter increamented
    if(this.conditionData.condDo.length > 0) {
      this.conditionData.condDo.forEach((item, i) => {
          // If DO field is not filled validation counter increamented
          if(item.dostate) {
            // If DO FIELD is selected either SINGLE or MULTIPLE FIELD should be filled , else validation counter increamented
            if(item.dofield.length < 1) {
              this.validationCounter++;
            }
          } else {
            this.validationCounter++;
          }
      });
    } else {
      this.validationCounter++;
    }
  }
  // Save button click
  saveCondition() {
      this.validateForm();
      // If validationCounter in more than 0, it means we have error. Show error message
      // Else save the condition and show the table
      if(this.validationCounter) {
        this.showValidation = true;
      } else {
        this.showValidation = false;
        if(this.addCondition) {
          this.conditions.push(this.conditionData);
        } else {
          this.conditions[this.conditionIndex] = this.conditionData;
        }
        this.showSection('showConditionHome');
        // localStorage.setItem('SettingsData', JSON.stringify(this.conditions));
        this.globalService.appGlobalData.settings.pages = this.conditions;
        this.globalService.setConditionalDtToFields(true);
      }
      this.validationCounter = 0;
  }
  // Add Condition button click
  addNewCondition() {
    this.updateFormFieldArrays();
    this.addCondition = true;
    this.conditionData = JSON.parse(JSON.stringify(this.constants.conditionsNew));
    this.showSection('showConditionDetail');
  }
  // Edit Condition Button Click
  editCondition(index:Number) {
    this.updateFormFieldArrays();
    this.showValidation = false;
    this.addCondition = false;
    this.conditionIndex = index;
    this.conditionData = this.conditions[this.conditionIndex];
    this.showSection('showConditionDetail');
    this.globalService.setConditionalDtToFields(true);
    const timeoutId = setTimeout(() => {
      if(this.conditionData.fieldType === this.constants.CHECKBOX_FIELD ||
        this.conditionData.fieldType === this.constants.SELECT_FIELD ||
        this.conditionData.fieldType === this.constants.RADIO_FIELD) {
          this.valueArray = this.formJsonIf[$('.conditionIfSelect')[0].selectedIndex].options;
      }
    }, 100);
  }
  // Delete Condition Button Click
  deleteCondition(index) {
    this.conditions.splice(index, 1);
    // localStorage.setItem('SettingsData', JSON.stringify(this.conditions));
    this.globalService.appGlobalData.settings.pages = this.conditions;
    this.globalService.setConditionalDtToFields(true);
  }
  // Add DO Button Click
  addDo() {
    this.conditionData.condDo.push(JSON.parse(JSON.stringify(this.constants.conditionsNew.condDo[0])));
  }
  // Delete DO Button Click
  deleteDo(index) {
    this.conditionData.condDo.splice(index, 1);
  }

  public ckeckForDDTextField() {
    let counter = 0;
    // for(let i=0; i<this.conditions.length; i++) {
      for(let j=0; j<this.conditionData['condDo'].length; j++) {
        const curItem = this.conditionData['condDo'][j];
        for(let k=0; k<curItem['dofield'].length; k++) {
          if(curItem['dofield'][k].type === 'selectfield' || curItem['dofield'][k].type === 'textfield') {
            counter++;
          }
        }
      }
    // }
    return counter;
  }

  ngOnInit() {
     // Load Existing Data
      this.conditions = this.globalService.appGlobalData.settings.pages;
  }
}
