import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { PreviewComponent } from './preview-form.component';
@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    PreviewComponent
  ],
  exports: [
    PreviewComponent
  ],
  providers: [],
  entryComponents: [  ],
})
export class PreviewFormModule { }
