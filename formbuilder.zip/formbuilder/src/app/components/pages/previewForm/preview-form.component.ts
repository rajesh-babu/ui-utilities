import { Component} from '@angular/core';

declare var $:any;

@Component({
  selector: 'preview-form',
  templateUrl: './preview-form.component.html'
})
export class PreviewComponent  {
 compPosition:number = 0;
 initDrag:Boolean = false;
}
