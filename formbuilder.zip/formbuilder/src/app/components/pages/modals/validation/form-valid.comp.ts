import { Component, ViewChild } from '@angular/core';
import { UtilityService } from '../../../../services/UtilityService';
import { GlobalService } from '../../../../services/GlobalService';
import { HttpService } from '../../../../services/HttpService';
import { ValidationService } from '../../../../shared/validations/validation.service';
import { Constants } from '../../../../services/Constants';
import { ModalDirective } from 'ngx-bootstrap/modal';

declare var $:any;
declare var skipValidation:boolean;

@Component({
  selector: 'form-valid-modal',
  templateUrl: './form-valid.comp.html'
})
export class FormValidModalComponent {

  public saveMsg:string = '';
  public loaderAni:boolean;
  public statusMsg:string = 'Please wait...';
  public formData:any;
  public notValidList:any;

  @ViewChild('validationModal') public validationModal:ModalDirective;

  public constructor(private utilityService:UtilityService, private globalService:GlobalService,
                     private constants:Constants, private httpService:HttpService) {}
  /*
   * It will be show the modal based on type and it's association with conditional logic
   */
  private showModal() {
    this.validationModal.show();
  }

  nameValidationDetails(nameInp,pgno,fdno,fname,validations) {
    let nameDetailsMsg = '';
    if(validations.indexOf('required') > -1) {
      nameDetailsMsg = nameDetailsMsg + ValidationService.validateAll(ValidationService.customRequiredVal,nameInp, 'name', '', '', '');
    }
    if(nameDetailsMsg) {
      nameDetailsMsg = 'required';
    } else {
      if(validations.indexOf('attr') > -1) {
        nameDetailsMsg = ValidationService.validateAll(ValidationService.attributeVal, nameInp, 'name', '', '', '');
      }
      if(nameDetailsMsg) {
        nameDetailsMsg = 'invalid';
      } else {
        if(validations.indexOf('unique') > -1) {
          nameDetailsMsg = ValidationService.validateAll(ValidationService.uniqueNameValOnsave,nameInp, 'name',pgno,fdno,fname);
        }
        if(nameDetailsMsg) {
          nameDetailsMsg = 'already used in '+nameDetailsMsg;
        }
      }
    }
    return nameDetailsMsg;
  }

  nameOverrideValidationDetails(nameInp,pgno,fdno,fname) {
    let nameDetailsMsg = '';
    nameDetailsMsg = ValidationService.validateAll(ValidationService.attributeVal, nameInp, 'name', '', '', '');
    if(nameDetailsMsg) {
      nameDetailsMsg = 'invalid';
    } else {
      nameDetailsMsg = ValidationService.validateAll(ValidationService.uniqueNameValOnsave,nameInp, 'name',pgno,fdno,fname);
      if(nameDetailsMsg) {
        nameDetailsMsg = 'is already used in '+nameDetailsMsg;
      }
    }
    return nameDetailsMsg;
  }

  nameValidation(nmField,pgno,fdno,fname) {
    let nameMsg = '';
    let nameSubMsg = '';
    // name validation

    if(nmField.numberofFields) { // For SSN, Account Number and Phone fields
      for(let m=0;m<nmField.numberofFields;m++) {
        nameMsg = this.nameValidationDetails(nmField['name'+(m+1)],pgno,fdno,fname,['required','attr','unique']);
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name'+(m+1)+ ' is ' +nameMsg;
          nameMsg = '';
        }
      }
    } else  if(nmField.componentName === 'Button') { // For Button Field
      for(let k=0;k<nmField.buttons.length;k++) {
        nameMsg = this.nameValidationDetails(nmField.buttons[k].name,pgno,fdno,fname,['required','attr','unique']);
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name inside Button '+ (k+1) + ' is ' +nameMsg;
          nameMsg = '';
        }
      }
    } else if(nmField.componentName === 'Grid Table') { // For Grid Table
      nameMsg = this.nameValidationDetails(nmField.name,pgno,fdno,fname,['required','attr','unique']);
      if(nameMsg) {
        nameSubMsg =  'Name is ' +nameMsg;
        nameMsg = '';
      }
      // Validation for 4 additional name fields if type is "plansTable"
      if(nmField.tableType !== 'Default') {
        nameMsg = this.nameValidationDetails(nmField.planNumber,pgno,fdno,fname,['required','attr']);
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'PlanNumber Name is ' +nameMsg;
          nameMsg = '';
        }
        if(nmField.tableType !== 'plansTableBalance') {
          nameMsg = this.nameValidationDetails(nmField.subPlanNumber,pgno,fdno,fname,['required','attr']);
          if(nameMsg) {
            nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'SubPlanNumber Name is ' +nameMsg;
            nameMsg = '';
          }
        }
        nameMsg = this.nameValidationDetails(nmField.tiaaNumber,pgno,fdno,fname,['required','attr']);
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'TiaaNumber Name is ' +nameMsg;
          nameMsg = '';
        }
        nameMsg = this.nameValidationDetails(nmField.crefNumber,pgno,fdno,fname,['required','attr']);
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'CrefNumber Name is ' +nameMsg;
          nameMsg = '';
        }
        if(nmField.tableType == 'plansTableBalance') {
          nameMsg = this.nameValidationDetails(nmField.productCode,pgno,fdno,fname,['required','attr']);
          if(nameMsg) {
            nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'Productcode Name is ' +nameMsg;
            nameMsg = '';
          }
            nameMsg = this.nameValidationDetails(nmField.balance,pgno,fdno,fname,['required','attr']);
            if(nameMsg) {
              nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'Balance Name is ' +nameMsg;
              nameMsg = '';
            }
        }
        if(nmField.tableType === 'ITDPlansTable') {
          nameMsg = this.nameValidationDetails(nmField.itdNumber,pgno,fdno,fname,['required','attr']);
          if(nameMsg) {
            nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') +  'ITDNumber Name is ' +nameMsg;
            nameMsg = '';
          }
        }
      }

      for(let k=0;k<nmField.columns.length;k++) {
        if(nmField.columns[k].rowField === 'text') {
          nameMsg = this.nameValidationDetails(nmField.columns[k].rowFieldConf.name,pgno,fdno,fname,['required','attr','unique']);
        }
        if(nmField.columns[k].rowField === 'radio') {
          nameMsg = this.nameValidationDetails(nmField.columns[k].rowFieldConf.radioName,pgno,fdno,fname,['required','attr','unique']);
        }
        if(nmField.columns[k].rowField === 'radioText') {
          nameMsg = this.nameValidationDetails(nmField.columns[k].rowFieldConf.textName,pgno,fdno,fname,['required','attr','unique']);
          nameMsg = this.nameValidationDetails(nmField.columns[k].rowFieldConf.radioName,pgno,fdno,fname,['required','attr','unique']);
        }
        if(nameMsg) {
          nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name inside Column '+ (k+1) + ' is ' +nameMsg;
          nameMsg = '';
        }
      }

    } else if(nmField.componentName === 'Widget') { // For Grid Table
      nameMsg = this.nameValidationDetails(nmField.name,pgno,fdno,fname,['required','attr','unique']);
      if(nameMsg) {
        nameSubMsg = 'Name is ' +nameMsg;
        nameMsg = '';
      }
      for(let k=0;k<nmField.pages.length;k++) {
        const secEle = nmField.pages[k];
        for(let l=0;l<secEle.length;l++) {
          // No need to validate the button which is inside the Widget
          if(secEle[l].componentName !== 'Multi Column' && secEle[l].componentName !== 'Title'
              && secEle[l].componentName !== 'Section' && secEle[l].componentName !== 'Button' && secEle[l].componentName !== 'Page' && secEle[l].componentName !== 'Page Field') {
            // For SSN, Account Number and Phone fields

            if(secEle[l].numberofFields) {
              for(let m=0;m<secEle[l].numberofFields;m++) {
                nameMsg = this.nameValidationDetails(secEle[l]['name'+(m+1)],pgno,fdno,fname,['required','attr','unique']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name inside field'+(m+1)+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                nameMsg = this.nameValidationDetails(secEle[l]['name_override'+(m+1)],pgno,fdno,fname,['attr','unique']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name Override inside field'+(m+1)+ ' is ' +nameMsg;
                  nameMsg = '';
                }
              }
            } else if(secEle[l].componentName === 'Grid Table') {
              nameMsg = this.nameValidationDetails(secEle[l].name,pgno,fdno,fname,['required','attr','unique']);
              if(nameMsg) {
                nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name inside Field '+l+ ' is ' +nameMsg;
                nameMsg = '';
              }
              nameMsg = this.nameValidationDetails(secEle[l].name_override,pgno,fdno,fname,['attr','unique']);
              if(nameMsg) {
                nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name Override inside Field '+l+ ' is ' +nameMsg;
                nameMsg = '';
              }
              if(secEle[l].tableType !== 'Default') {
                nameMsg = this.nameValidationDetails(secEle[l].planNumber,pgno,fdno,fname,['required','attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'PlanNumber Name inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                nameMsg = this.nameValidationDetails(secEle[l].planNumber_override,pgno,fdno,fname,['attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'PlanNumber Name Override inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                if(secEle[l].tableType !== 'plansTableBalance') {
                  nameMsg = this.nameValidationDetails(secEle[l].subPlanNumber,pgno,fdno,fname,['required','attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'SubPlanNumber Name inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                  nameMsg = this.nameValidationDetails(secEle[l].subPlanNumber_override,pgno,fdno,fname,['attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'SubPlanNumber Name Override inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                }
                if(secEle[l].tableType == 'plansTableBalance') {
                  nameMsg = this.nameValidationDetails(secEle[l].productCode,pgno,fdno,fname,['required','attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'ProductCode Name inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                  nameMsg = this.nameValidationDetails(secEle[l].productCode_override,pgno,fdno,fname,['attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'ProductCode Name Override inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                  nameMsg = this.nameValidationDetails(secEle[l].balance,pgno,fdno,fname,['required','attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Balance Name inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                  nameMsg = this.nameValidationDetails(secEle[l].balance_override,pgno,fdno,fname,['attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Balance Name Override inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                }
                nameMsg = this.nameValidationDetails(secEle[l].tiaaNumber,pgno,fdno,fname,['required','attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'TiaaNumber Name inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                nameMsg = this.nameValidationDetails(secEle[l].tiaaNumber_override,pgno,fdno,fname,['attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'TiaaNumber Name Override inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                nameMsg = this.nameValidationDetails(secEle[l].crefNumber,pgno,fdno,fname,['required','attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'CrefNumber Name inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                nameMsg = this.nameValidationDetails(secEle[l].crefNumber_override,pgno,fdno,fname,['attr']);
                if(nameMsg) {
                  nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'CrefNumber Name Override inside Field '+l+ ' is ' +nameMsg;
                  nameMsg = '';
                }
                if(secEle[l].tableType === 'ITDPlansTable') {
                  nameMsg = this.nameValidationDetails(secEle[l].itdNumber,pgno,fdno,fname,['required','attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'ITD Name inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                  nameMsg = this.nameValidationDetails(secEle[l].itdNumber_override,pgno,fdno,fname,['attr']);
                  if(nameMsg) {
                    nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'ITD Name Override inside Field '+l+ ' is ' +nameMsg;
                    nameMsg = '';
                  }
                }
              }
            } else {
              nameMsg = this.nameValidationDetails(secEle[l].name,pgno,fdno,fname,['required','attr','unique']);
              if(nameMsg) {
                nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name inside Field '+l+ ' is ' +nameMsg;
                nameMsg = '';
              }
              nameMsg = this.nameValidationDetails(secEle[l].name_override,pgno,fdno,fname,['attr','unique']);
              if(nameMsg) {
                nameSubMsg = ((nameSubMsg === '') ? '' : nameSubMsg + ', ') + 'Name Override inside Field '+l+ ' is ' +nameMsg;
                nameMsg = '';
              }
            }
          }
        }
      }
    } else { // For other fields
       if(nmField.componentName === 'Section' || nmField.componentName === 'Page' || nmField.componentName === 'Page Field' || nmField.componentName === 'Title') { return nameMsg; };
      nameMsg = this.nameValidationDetails(nmField.name,pgno,fdno,fname,['required','attr','unique']);
      if(nameMsg) {
        nameSubMsg = 'Name is '+nameMsg;
      }
    }
    return nameSubMsg;
  }

  idValidationDetails(idInp,pgno,fdno,fname) {
    let idDetailsMsg = '';
    idDetailsMsg = ValidationService.validateAll(ValidationService.attributeVal, idInp, 'id', '', '', '');
    if(idDetailsMsg) {
      idDetailsMsg = 'invalid';
    } else {
      idDetailsMsg = idDetailsMsg + ValidationService.validateAll(ValidationService.uniqueIdValOnsave, idInp, 'id',pgno,fdno,fname);
      if(idDetailsMsg) {
        idDetailsMsg  = 'already used in '+idDetailsMsg;
      }
    }
    return idDetailsMsg;
  }

  idValidation(idField,pgno,fdno,fname) {
    let idMsg = '';
    let idSubMsg = '';
    // id validation

    if(idField.numberofFields) { // For SSN, Account Number and Phone fields
      for(let m=0;m<idField.numberofFields;m++) {
        idMsg = this.idValidationDetails(idField['id'+(m+1)],pgno,fdno,fname);
        if(idMsg) {
          idSubMsg = ((idSubMsg === '') ? '' : idSubMsg + ', ') + 'Id'+(m+1)+' is '+idMsg;
          idMsg = '';
        }
      }
    } else if(idField.componentName === 'Button') {
      for(let k=0;k<idField.buttons.length;k++) {
        idMsg = this.idValidationDetails(idField.buttons[k].id,pgno,fdno,fname);
        if(idMsg) {
          idSubMsg = ((idSubMsg === '') ? '' : idSubMsg + ', ') + 'Id inside Button '+ (k+1)+' is '+idMsg;
          idMsg = '';
        }
      }
    } else if(idField.componentName === 'Grid Table') {
      idMsg = this.idValidationDetails(idField.id,pgno,fdno,fname);
      if(idMsg) {
        idSubMsg = 'Id is '+idMsg;
        idMsg = '';
      }
      for(let k=0;k<idField.columns.length;k++) {
        if(idField.columns[k].rowField !== 'label') {
          idMsg = this.idValidationDetails(idField.columns[k].rowFieldConf.id,pgno,fdno,fname);
        }
        if(idMsg) {
          idSubMsg = ((idSubMsg === '') ? '' : idSubMsg + ', ') + 'Id inside Column '+ (k+1) +' is '+idMsg;
          idMsg = '';
        }
      }
    } else {
      if(idField.componentName === 'Widget') { return idMsg; };
      idMsg = this.idValidationDetails(idField.id,pgno,fdno,fname);
      if(idMsg) {
        idSubMsg = 'Id is '+idMsg;
      }
    }
    return idSubMsg;
  }

  adaAttrValidation(field) {
    let adaAttrMsg = '';
    let adaAttrSubMsg = '';
    // id validation

    if(field.componentName === 'Button') {
      for(let k=0;k<field.buttons.length;k++) {
        adaAttrMsg = ValidationService.validateAll(ValidationService.adaAttributesVal, field.buttons[k].adaAttrs, 'adaAttrs', '', '', '');
        if(adaAttrMsg) {
          adaAttrSubMsg = ((adaAttrSubMsg === '') ? '' : adaAttrSubMsg + ', ') + 'Accessibility Attributes inside Button '+ (k+1) + 'is invalid';
          adaAttrMsg = '';
        }
      }
    } else {
      if(field.componentName === 'Widget') { return adaAttrMsg; };
      adaAttrMsg = adaAttrMsg + ValidationService.validateAll(ValidationService.adaAttributesVal, field.adaAttrs, 'adaAttrs', '', '', '');
      if(adaAttrMsg) {
        adaAttrSubMsg = 'Accessibility Attributes is invalid';
      }
    }
    return adaAttrSubMsg;
  }

  validateField(field,pgno,fdno) {
    let errorMsg = '';

    // call id validation
    errorMsg = errorMsg + this.idValidation(field,pgno,fdno,field.componentName);
    if(errorMsg !== '') {
      this.notValidList.push({'component':field.componentName, 'page':pgno+1, 'fno':fdno+1, 'property':'Id', 'error':errorMsg});
      errorMsg = '';
    }

    // call name validation
    errorMsg = errorMsg + this.nameValidation(field,pgno,fdno,field.componentName);
    if(errorMsg !== '') {
      this.notValidList.push({'component':field.componentName, 'page':pgno+1, 'fno':fdno+1, 'property':'Name','error':errorMsg});
      errorMsg = '';
    }

    // ADA attribute validation
    errorMsg = errorMsg + this.adaAttrValidation(field);
    if(errorMsg !== '') {
      this.notValidList.push({'component':field.componentName, 'page':pgno+1, 'fno':fdno+1, 'property':'Accessibility Attributes','error':errorMsg});
      errorMsg = '';
    }
  }

  /*
   * Checking the form for validation issues
   */
  public validateForm() {
    if(skipValidation) { return true; };
    this.notValidList = [];
    ValidationService.namesArray = [];
    ValidationService.IdArray = [];
    this.formData = this.globalService.appData;
    for(let i=0;i<this.formData.length;i++) {
      for(let j=0;j<this.formData[i].length;j++) {
        if(this.formData[i][j].componentName === 'Page' || this.formData[i][j].componentName === 'Page Field') {
        } else if(this.formData[i][j].componentName === 'Multi Column') {
            for(let k=0;k<Object.keys(this.formData[i][j].fieldsObj).length;k++) {
              const colObj = this.formData[i][j].fieldsObj['col'+k];
              if(colObj) {
              this.validateField(colObj,i,j);
              }
            }
        } else if(this.formData[i][j].componentName === 'Group Field') {
           this.validateField(this.formData[i][j],i,j);
           for(let k=0;k<Object.keys(this.formData[i][j].groupFields).length;k++) {
             const colObj = this.formData[i][j].groupFields[k];
             if(colObj.componentName === 'Multi Column') {
                 for(let l=0;l<Object.keys(colObj.fieldsObj).length;l++) {
                   const colObjNew = colObj.fieldsObj['col'+l];
                   if(colObjNew) {
                   this.validateField(colObjNew,i,j);
                   }
                 }
             } else {
               this.validateField(colObj,i,j);
             }
           }
        } else if(this.formData[i][j].componentName !== 'Title') {
         this.validateField(this.formData[i][j],i,j);
        }
      }
    }
    if(this.notValidList.length > 0) {
      return false;
    } else {
      return true;
    }
  }

  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }

}
