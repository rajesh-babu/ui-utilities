import { Component, ViewChild } from '@angular/core';
import { ModalDirective } from 'ngx-bootstrap/modal';

declare var $:any;

@Component({
  selector: 'multicol-valid-modal',
  templateUrl: './multicol-valid.comp.html'
})
export class MulticolValidModalComponent {

  public errMsg:string = '';
  @ViewChild('multiColValidationModal') public multiColValidationModal:ModalDirective;

  public constructor() {}
  /*
   * It will be show the modal based on type and it's association with conditional logic
   */
  public showModal(msg:string) {
    this.errMsg = msg;
    this.multiColValidationModal.show();
  }
}
