import { Component, ViewChild } from '@angular/core';
import { UtilityService } from '../../../../services/UtilityService';
import { GlobalService} from '../../../../services/GlobalService';
import { HttpService} from '../../../../services/HttpService';
import { Constants} from '../../../../services/Constants';
import { ModalDirective } from 'ngx-bootstrap/modal';

declare var $:any;

@Component({
  selector: 'form-save-modal',
  templateUrl: './form-save.comp.html'
})
export class FormSaveModalComponent {

  public saveMsg:string = '';
  public loaderAni:boolean;
  public statusMsg:string = 'Please wait...';

  @ViewChild('saveModal') public saveModal:ModalDirective;

  public constructor(private utilityService:UtilityService, private globalService:GlobalService,
                     private constants:Constants, private httpService:HttpService) {}
  /*
   * It will be show the modal based on type and it's association with conditional logic
   */
  private showModal() {
    this.saveModal.show();
    if(this.globalService.appGlobalData.assetId) {

      // Call Ajax to update the form
      this.saveMsg = this.constants.FORM_SAVE_EDIT;
      this.loaderAni = true;
      const thisRef = this;
      this.httpService.updateForm(this.globalService.appGlobalData).then(function(result:any){
       if(result.status === 'success') {
         thisRef.loaderAni = false;
       }else {
         thisRef.loaderAni = true;
         thisRef.statusMsg = 'Server error while Updating the Form...';
       }
      });

    }else {
      this.saveMsg = this.constants.FORM_SAVE_CREATE;
    }
  }

  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }

}
