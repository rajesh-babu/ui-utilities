import { Component, ViewChild,  HostListener } from '@angular/core';
import { UtilityService } from '../../../../services/UtilityService';
import { GlobalService} from '../../../../services/GlobalService';
import { Constants} from '../../../../services/Constants';
import { FieldControlsService} from '../../../../services/FieldControlsService';
import { AsideService } from '../../../../services/AsideService';
import { CommonsFieldsService } from '../../../../services/fields/CommonsFieldsService';
import { ModalDirective } from 'ngx-bootstrap/modal';

declare var $:any;

@Component({
  selector: 'update-refid-modal',
  templateUrl: './update-refid.comp.html'
})
export class UpdateRefidModalComponent {
  public refIdCounter = 1;
  @ViewChild('updateRefidFailureModal') public updateRefidFailureModal:ModalDirective;
  @ViewChild('updateRefidSuccessModal') public updateRefidSuccessModal:ModalDirective;

  public constructor(public utilityService:UtilityService, private globalService:GlobalService,
                     private fieldControlsService:FieldControlsService, private asideService:AsideService,
                     private constants:Constants, private commonsFieldsService:CommonsFieldsService) {

  }
  /*
   * It will be show the modal based on type and it's association with conditional logic
   */
  private showModal() {
    this.updateRefidFailureModal.show();
  }

  public updateRefid() {
    this.globalService.appGlobalData.settings.pages = [];
    this.globalService.appGlobalData.pages = this.updateRefidLoop(this.globalService.appGlobalData.pages);
    this.updateRefidFailureModal.hide();
    this.updateRefidSuccessModal.show();
  }

  private updateRefidLoop(arrObject) {
    this.refIdCounter++;
    const newRefId = this.utilityService.timeasRefId();
    const _this = this;
    if( arrObject instanceof Array) {
      for(let i = 0; i < arrObject.length; i++) {
          setTimeout(function(){ arrObject[i] = _this.updateRefidLoop(arrObject[i]); }, 100);
      }
    } else {
        for(const prop in arrObject) {
           if(arrObject.hasOwnProperty(prop)) {
            if(prop === 'refId' || prop === 'optionRefId' || prop === 'buttonRefId' || prop === 'refIdName' ||
            prop === 'refIdRadioName' || prop === 'refIdTextName') {
                arrObject[prop] = newRefId + this.refIdCounter;
                if(arrObject['isConditional']) {
                  arrObject['isConditional'] = false;
                }
                this.refIdCounter++;
                return arrObject;
            }
            if(arrObject[prop] instanceof Object || arrObject[prop] instanceof Array) {
              setTimeout(function(){ arrObject[prop] = _this.updateRefidLoop(arrObject[prop]); }, 100);
            }
          }
        }
    }
    return arrObject;
  }

  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }

  /*
   * On clicking the 'Yes' in delete modal, delete form element and hide modal
   */
  onYesDeleteClick($ele:any):void {
    $ele.hide();
    const className = $('.droppedItem.selected').attr('class');
    if(className) {
        const indexPosition = this.utilityService.getCompIndexPos(className);
        this.fieldControlsService.onRemoveAction({indexPos:indexPosition});
        this.asideService.closeAside({});
    }
  }

}
