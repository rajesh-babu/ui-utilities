import { Component, ViewChild,  HostListener } from '@angular/core';
import { UtilityService } from '../../../../services/UtilityService';
import { GlobalService} from '../../../../services/GlobalService';
import { Constants} from '../../../../services/Constants';
import { FieldControlsService} from '../../../../services/FieldControlsService';
import { AsideService } from '../../../../services/AsideService';
import { CommonsFieldsService } from '../../../../services/fields/CommonsFieldsService';
import { ModalDirective } from 'ngx-bootstrap/modal';

declare var $:any;

@Component({
  selector: 'delete-modal',
  templateUrl: './delete.comp.html'
})
export class DelModalComponent {
  public deletePopupMessage:string = '';
  public deletePopupTitle:string = '';

  @ViewChild('deleteModal') public deleteModal:ModalDirective;
  @ViewChild('deletePopupModal') public deletePopupModal:ModalDirective;
  @ViewChild('deleteCondModal') public deleteCondModal:ModalDirective;
  @ViewChild('saveFormAttrModal') public saveFormAttrModal:ModalDirective;
  @ViewChild('conditionalAssoErrorModal') public conditionalAssoErrorModal:ModalDirective;

  public conditionalAssoError:any = {
    titleText:'', mainContent:''
  };

  public constructor(public utilityService:UtilityService, private globalService:GlobalService,
                     private fieldControlsService:FieldControlsService, private asideService:AsideService,
                     private constants:Constants, private commonsFieldsService:CommonsFieldsService) {

       this.fieldControlsService.onRemove$.subscribe((obj) => {
         this.showModal(obj.indexPos);
        });

        this.fieldControlsService.onRemoveOutside$.subscribe((obj) => {
          this.deleteCondModal.show();
        });

        this.fieldControlsService.onsaveFormattr$.subscribe((obj) => {
          this.saveFormAttrModal.show();
        });

        this.commonsFieldsService.onConditionalAssoError$.subscribe((obj:any) => {
          this.conditionalAssoError.titleText = obj.titleText;
          this.conditionalAssoError.mainContent = obj.mainContent;
          this.conditionalAssoErrorModal.show();
        });

  }
  /*
   * It will be show the modal based on type and it's association with conditional logic
   */
  private showModal(indexPos:any) {
  const refId = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['refId'];
      if((this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]).hasOwnProperty("buttons")) {
        const buttons = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['buttons'];
        let isButtoninCondition = false;
        for (let i = 0; i < buttons.length; i++) {
            if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],buttons[i]['buttonRefId'])) {
              isButtoninCondition=true;
            }
        }
        if(isButtoninCondition) {
          this.deleteCondModal.show();
        } else {
          this.deleteModal.show();
        }
      } else if(this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]["type"]===this.constants.GRIDTABLE_FIELD) {
        // check if grid table exist in conditions
        const gridTable = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos];
        let isgridTableinCondition = false;
        if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],gridTable['refId'])) {
          isgridTableinCondition=true;
        } else {
          // check if child components of grid table exist in conditions
          if(gridTable['columns'].length > 0) {
            for (let i = 0; i < gridTable['columns'].length; i++) {
                const column = gridTable['columns'][i];
                const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                if(refIdName || refIdRadioName || refIdTextName) {
                  isgridTableinCondition=true;
                }
            }
          }
        }
        if(isgridTableinCondition) {
          this.deleteCondModal.show();
        } else {
          this.deleteModal.show();
        }
      } else if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],refId)) {
        this.deleteCondModal.show();
      } else if(this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]["type"]===this.constants.SEC_CONTAINER) {
        const sectionPages =this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['pages'];
        let isFieldInsideWidgetInCondition=false;
        for (let i = 0; i < sectionPages.length; i++) {
            const widgetPages = sectionPages[i];
            for (let j = 0; j < widgetPages.length; j++) {
                const fieldType = widgetPages[j]['type'];
                if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],widgetPages[j]['refId'])) {
                  isFieldInsideWidgetInCondition = true;
                } else if(fieldType === this.constants.GROUP_FIELD) {
                  const groupField = widgetPages[j].groupFields;
                    for (let groupCounter = 0; groupCounter < groupField.length; groupCounter++) {
                      const groupFieldChildType = groupField[groupCounter]['type'];
                      if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],groupField[groupCounter]['refId'])) {
                        isFieldInsideWidgetInCondition = true;
                      } else if(groupFieldChildType === this.constants.MULTICOL) {
                        for(let m=0;m<4;m++) {
                          if(typeof groupField[groupCounter].fieldsObj['col'+m] !=="undefined") {
                            const multiColFields = groupField[groupCounter].fieldsObj['col'+m];
                            if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
                              isFieldInsideWidgetInCondition = true;
                            }
                          }
                        }
                      } else if(groupFieldChildType === this.constants.GRIDTABLE_FIELD) {
                        if(groupField[groupCounter]['columns'].length > 0) {
                          for (let gridTableCounter = 0; gridTableCounter < groupField[groupCounter]['columns'].length; gridTableCounter++) {
                              const column = groupField[groupCounter]['columns'][gridTableCounter];
                              const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                              const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                              const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                              if(refIdName || refIdRadioName || refIdTextName) {
                                isFieldInsideWidgetInCondition=true;
                              }
                          }
                        }
                      }
                    }
                } else if(fieldType === this.constants.MULTICOL) {
                  for(let m=0;m<4;m++) {
                    if(typeof widgetPages[j].fieldsObj['col'+m] !=="undefined") {
                      const multiColFields = widgetPages[j].fieldsObj['col'+m];
                      if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
                        isFieldInsideWidgetInCondition = true;
                      }
                    }
                  }
                } else if(fieldType === this.constants.GRIDTABLE_FIELD) {
                  if(widgetPages[j]['columns'].length > 0) {
                    for (let gridTableCounter = 0; gridTableCounter < widgetPages[j]['columns'].length; gridTableCounter++) {
                        const column = widgetPages[j]['columns'][gridTableCounter];
                        const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                        const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                        const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                        if(refIdName || refIdRadioName || refIdTextName) {
                          isFieldInsideWidgetInCondition=true;
                        }
                    }
                  }
                }
            }
        }
      if(isFieldInsideWidgetInCondition) {
          this.deleteCondModal.show();
        } else {
          this.deleteModal.show();
        }
      } else {
        const componentName = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['componentName'];
        const componentType = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['type'];
        let isPopupMapped = false;
        let multiColHasChild = false;
        let groupFieldHasChild = false;
        let buttonName="";
        if(componentType === this.constants.GROUP_FIELD && componentName ==="Group Field") {
          if(this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['popup']===true) {
            // To check popup is mapped to a button ?
            const componentFieldName = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['name'];
            for(let i=0;i<this.globalService.appGlobalData.pages.length;i++) {
              const pages = this.globalService.appGlobalData.pages[i];
              for(let k=0;k<pages.length;k++) {
                const componentTypeLookout = pages[k]['type'];
                if(componentTypeLookout===this.constants.BUTTON_FIELD) {
                  const buttons = pages[k]['buttons'];
                  for(let a=0;a<buttons.length;a++) {
                    if(buttons[a]['mappedPopup']) {
                      if(buttons[a]['mappedPopup'] === componentFieldName) {
                        isPopupMapped = true;
                        buttonName = buttons[a]['name'];
                      }
                    }
                  }
                }
              }
            }
          }
            // check if any fields exist in Group
            const groupFields = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['groupFields'];
            if(groupFields.length > 0) {
              groupFieldHasChild=true;
            }
        } else if(componentType==="multiCol") {
            const fieldObjs = this.globalService.appGlobalData.pages[this.globalService.selectedIndexPgArr][indexPos]['fieldsObj'];
            if(fieldObjs['col0'] || fieldObjs['col1'] || fieldObjs['col2'] || fieldObjs['col3']) {
              multiColHasChild=true;
            }
        }
        if(isPopupMapped) {
          this.showPopupModal(buttonName,'popup'); // this.deletePopupModal.show();
        } else if(multiColHasChild) {
          this.showPopupModal(buttonName,'multicol');
        } else if(groupFieldHasChild) {
          this.showPopupModal(buttonName,'groupFieldHasChild');
        } else {
          this.deleteModal.show();
        }
      }
  }

  /*
   * Display popup modal, when delete action is triggered.
   */
  private showPopupModal(buttonFieldName:string,componentType:string) {
    if(componentType==="popup") {

      this.deletePopupTitle =this.constants.POPUP_DELETE_TITLE;

      if(buttonFieldName) {
        this.deletePopupMessage = this.constants.POPUP_DELETE_MESSAGE + buttonFieldName + " button.";
        this.deletePopupModal.show();
      } else {
        this.deletePopupMessage = this.constants.POPUP_DELETE_MESSAGE + "button.";
        this.deletePopupModal.show();
      }
    } else if(componentType==="multicol") {

        this.deletePopupTitle =this.constants.POPUP_MULTICOL_TITLE;
        this.deletePopupMessage =this.constants.DELETE_POPUP_MESSAGE + " multi column.";

        this.deletePopupModal.show();
    } else if(componentType==="groupFieldHasChild") {

        this.deletePopupTitle =this.constants.POPUP_GROUPFIELD_TITLE;
        this.deletePopupMessage =this.constants.DELETE_POPUP_MESSAGE + " group field.";

        this.deletePopupModal.show();
    }
  }
  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }
  /*
   * Listen for keyup in document,
   */
  @HostListener('document:keyup', ['$event'])
  onKeyUp(ev:KeyboardEvent) {
     if(ev.key === 'Delete') {
       const tgtCls = ev.target['className'].search('app');
       if(tgtCls !== -1) {
         const className = $(ev.target).find('.droppedItem.selected').attr('class');
         if(className) {
             const indexPosition = this.utilityService.getCompIndexPos(className);
             this.showModal(indexPosition);
         }
       }
     }
  }
  /*
   * On clicking the 'Yes' in delete modal, delete form element and hide modal
   */
  onYesDeleteClick($ele:any):void {
    $ele.hide();
    const className = $('.droppedItem.selected').attr('class');
    if(className) {
        const indexPosition = this.utilityService.getCompIndexPos(className);
        this.fieldControlsService.onRemoveAction({indexPos:indexPosition});
        this.asideService.closeAside({});
    }
  }

}
