import { Component, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule } from '@angular/forms';
import { UtilityService } from '../../../../services/UtilityService';
import { GlobalService} from '../../../../services/GlobalService';
import { ControlMessagesComponent } from '../../../../shared/validations/control-messages.comp';
import { ValidationService } from '../../../../shared/validations/validation.service';

declare var $:any;

@Component({
  selector: 'section-modal',
  templateUrl: './modal.comp.html'
})
export class SecModalComponent {

  @ViewChild('saveModalSection') saveModalSection: ElementRef;

  public isSecNameContainerShow:boolean;
  public isSecNameInpFieldShow:boolean = true;
  public isCloseFieldSecShow:boolean = false;
  public statusMessageSec:string = '';
  public loaderAni:boolean;
  public inputSecName:string = '';
  public isFormSubmitted:boolean;
  userForm: any;

  public constructor(public utilityService:UtilityService, private globalService:GlobalService, private formBuilder: FormBuilder) {
    this.userForm = this.formBuilder.group({
      'name': ['', [Validators.required, ValidationService.secNameValidator, Validators.maxLength(64)]]
    });
  }

  /*
   * It will be triggered from app.component.ts when clikcing the save button from navigation
   */
  public setView() {
    this.isCloseFieldSecShow = false;
    if(this.utilityService.appAction === 'Create') {
      // Hide the Name input field
      this.isSecNameInpFieldShow = true;
      this.isSecNameContainerShow = true;
    }else {
      this.isSecNameInpFieldShow = false;
      this.onSaveSection();
    }
  }
  /*
   * This will be triggered upon clikcing the save button for section.
   */
  public onSaveSection() {

    this.isFormSubmitted = true;

    // No need to Validate the form in edit mode as "name" field wont' be visible.
    if(this.utilityService.appAction === 'Create' && !this.userForm.valid) {
      return;
    }
    const isCreate = (this.utilityService.appAction === 'Create') ? true :false,
        thisRef = this;

    // Hide the Name & Close
    this.isSecNameContainerShow = false;
    this.isCloseFieldSecShow = false;

    this.loaderAni = true;

    const updateSecObj = {assetId:this.globalService.appGlobalData.assetId, assetType:this.globalService.appGlobalData.assetType};

    this.globalService.createEditSectionFW(isCreate, this.inputSecName, updateSecObj).then(function(result:any){
     if(result.status === 'success') {

       // Update the JSON value to Parent if it's has parent window
       thisRef.globalService.storeJSON();

       thisRef.isCloseFieldSecShow = true;
       thisRef.isSecNameContainerShow = false;
       thisRef.loaderAni = false;
       thisRef.statusMessageSec = result.message;
       thisRef.globalService.appGlobalData.assetType = result.sectionInfo.assetType;
       thisRef.globalService.appGlobalData.assetId = result.sectionInfo.assetId;
       thisRef.utilityService.appAction = 'Edit';
     }else {
       thisRef.statusMessageSec = 'Server error while creating/updating the Widget...';
     }
    });
  }
  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }
}
