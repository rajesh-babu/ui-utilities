import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AsideService} from '../../services/AsideService';
import { CustomCommonsModule } from '../../shared/customCommons.module';
import { DragulaModule} from 'ng2-dragula';
import { StageComponent } from './stage.comp';
import { DragandDropModule } from '../drag-and-drop/drag-drop.module';
import { AsideModule } from '../fields/aside.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    DragulaModule,
    DragandDropModule,
    AsideModule
  ],
  declarations: [
    StageComponent
  ],
  exports:[StageComponent],
  providers: [AsideService],
  entryComponents: [ StageComponent ]
})
export class StageModule { }
