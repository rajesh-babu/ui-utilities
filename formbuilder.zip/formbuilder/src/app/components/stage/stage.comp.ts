import { Component, EventEmitter, Output, OnInit, ViewChild, AfterViewInit } from '@angular/core';
import { Constants } from '../../services/Constants';
import { UtilityService} from '../../services/UtilityService';
import { GlobalService} from '../../services/GlobalService';
import { FieldControlsService} from '../../services/FieldControlsService';
import { CommonsFieldsService} from '../../services/fields/CommonsFieldsService';
import { DragAndDropComponent} from '../drag-and-drop/drag-drop.component';
import { AsideService } from '../../services/AsideService';

import { DragulaService } from 'ng2-dragula';
declare var $:any;
declare var appGlobalData: any;


@Component({
  selector: 'stage-comp',
  templateUrl: './stage.comp.html'
})
export class StageComponent implements OnInit, AfterViewInit {
 public pgArr:Array<any> = [{pgName:'Page'}];

 @ViewChild('ddcomp') public ddcomp:DragAndDropComponent;

 public stages:Array<any> = [];
 public constructor( private constants:Constants, private utilityService:UtilityService, public globalService:GlobalService,
                     private dragulaService: DragulaService, private fieldControlsService:FieldControlsService,
                     private commonsFieldsService:CommonsFieldsService, private asideService:AsideService) {

   // It will be triggered when user deleting the field and get Column IndexPos as parameter. Destroy the corresponding component created.
   this.fieldControlsService.multiColOnRemove$.subscribe((obj) => {
     this.ddcomp.deleteMultiCol(obj);
    });

    // It will be triggered when user deleting the Group field and get Column IndexPos as parameter. Destroy the corresponding component created.
    this.fieldControlsService.grpFieldOnRemove$.subscribe((obj) => {
      this.ddcomp.deleteGroupField(obj);
     });

    // It will be triggered when user deleting the field and get IndexPos as parameter. Destroy the corresponding component created.
    this.fieldControlsService.onRemoveAction$.subscribe((obj) => {
       this.ddcomp.deleteRow(obj);
     });

    // This will be triggered upon clicking the duplicate of corresponding field
    this.commonsFieldsService.onDuplicateField$.subscribe((obj) => {
       if(typeof obj['values'].grpRowIndex !== 'undefined') {
         // this.commonsFieldsService.onDuplicateGrpField(obj);
         this.ddcomp.duplicateGrpField(obj);
       } else {
         this.ddcomp.duplicateField(obj);
       }
    });

   dragulaService.setOptions('first-bag', {
      copy: function (el, source) {
        // To copy only elements in left container, the right container can still be sorted
        return source.classList.contains('fieldSection-list');
      },
      // copySortSource: true,
       revertOnSpill: true,
      accepts: function(el, target, source, sibling) {
        const $pl = $(target).find('.plHm');
        if($pl.length) {
          $pl.removeClass('show')
             .addClass('hide');
        }

        // Don't allow the outer fields dropped into group field
        if(source && source.classList && target && target.classList) {
          if(source.classList.contains('form-all') && target.classList.contains('groupField')) {
            return false;
          }
        }

        // For Widget, Don't allow drga drop the fields to above the widget Header or Title field
         if($(sibling).find('.noDrag').length || sibling && sibling.classList.contains('noDrag')) {
          return false;
        }

        // To avoid draggin from right to left container
        return !$(target).hasClass('fieldSection-list')  && (!target.classList.contains('moving'));
      },
      moves: function (el:any, container:any, handle:any):any {
        let unselected:boolean = true;

        // Dont Drag unselected item
        if(!container.classList.contains('fieldSection-list')) {
          unselected = $(el).find('.selected').length;
        }


        // Dont drag title-field component
        if($(el).find('.noDrag').length) {
          return false;
        }

        // Dont Drag for common field controls and unselected item
        return  unselected && !handle.classList.contains('fa');
      }
  });
  dragulaService.out.subscribe((value) => {

  });
  dragulaService.drop.subscribe((value) => {
      this.ddcomp.onDrop(value);
  });
  dragulaService.drag.subscribe((value) => {
    this.lockChildrenContainers(true, value.slice(1)[0]);
  });

  dragulaService.dragend.subscribe((value) => {
    this.lockChildrenContainers(false, value.slice(1)[0]);
  });
}

/*
* The below function locks the child of multi column field when dragging otherise will face internal dragula JS error
*/
private lockChildrenContainers(lock:boolean, el:any) {
  let initialState, finalState:string;
  if(lock) {
    initialState = 'lockParent';
    finalState = 'moving';
  }else {
    initialState = 'moving';
    finalState = 'lockParent';
  }

  // Add class 'moving' when drag started and remove class 'moving' after dropped.
  if(el!== undefined && el!== null) {
    const childrenContainers = el.querySelectorAll('.' + initialState);
    for(let i = 0; i < childrenContainers.length; i++) {
      const $child = $(childrenContainers[i]);
        $child.removeClass(initialState)
            .addClass(finalState);
    }
  }
  
}
 /*
  * This will be triggered when one of the pagination buttons clicked
  */
 public pageBtnClick(_indexPos:number) {
   if(this.globalService.selectedIndexPgArr !== _indexPos) {
     this.globalService.selectedIndexPgArr = _indexPos;

     this.stages.forEach((obj)=>obj.isShow = false);
     this.stages[_indexPos]['isShow'] = true;

     const timeoutId = setTimeout(() => {
       this.ddcomp.reLoadFields(this.globalService.selectedIndexPgArr);
     }, 100);
     this.asideService.closeAside({});
   }
 }
 ngOnInit() {
   this.stages.push({isShow: true});
   // If opened from FATWIRE, this will check for hidden div with JSON. Dont get values from Parent window if App opened from start menu

   if(this.utilityService.appAction !== 'Create' && window.opener) {
     const jsonEle = window.opener.$('#editFormInput_' + this.utilityService.assetId);
     if(jsonEle.length && jsonEle.val() !== '') {
      this.globalService.convertAppData(this.utilityService.decodeJSONParse(jsonEle.val()));
      this.globalService.setConditionalDtToFields(false);
     }
   }

   // Get the JSON and set it to AppData Array
   // this.globalService.getJSONSetAppDataArr();

   const _data = this.globalService.appData;

   // Check any multiple pages are there
   if(_data && _data.length > 1) {
     for(let i=1;i<_data.length;i++) {
       this.stages.push({isShow: false});
       this.pgArr.push({pgName:'Page'});
     }
   }else if(!_data.length) {
     this.globalService.appData.push([]);
     this.globalService.appGlobalData.pages = this.globalService.appData ;
     if(this.utilityService.formMode === 'Section') {
       this.globalService.appGlobalData.type ='secContainer';
     }
   }
   // Expose the appdata globally
   appGlobalData = this.globalService.appGlobalData;
 }
 ngAfterViewInit() {
   // Load 1st page data if it's there
   if(this.globalService.appData.length > 0) {

     // As DD component created Section by default, Dont reload fields if section header is only there
     const pgArr:any = this.globalService.appData[0];
     if(this.utilityService.formMode === 'Section' && pgArr.length ===1) {
       return;
     }
     const timeoutId = setTimeout(() => {
       this.ddcomp.reLoadFields(0);
     }, 100);
   }
 }
 /*
  * This will be triggered when adding the page
  */
 public addPg(_indexPos:number) {
   this.globalService.selectedIndexPgArr = _indexPos + 1;
   if(this.globalService.appData.length === this.globalService.selectedIndexPgArr) {
     this.globalService.appData.push([]);
   }else {
     this.globalService.appData.splice(this.globalService.selectedIndexPgArr, 0, []);
   }
   this.globalService.storeJSON();

   const indexPg:number = this.globalService.selectedIndexPgArr;
   this.stages.forEach((obj)=>obj.isShow = false);
   if(indexPg > this.stages.length) {
     this.stages.push({isShow: true});
     this.pgArr.push({pgName:'Page'});
   }else {
     this.stages.splice(indexPg, 0, {isShow: true});
     this.pgArr.splice(indexPg, 0, {pgName:'Page'});
   }
   this.asideService.closeAside({});
 }
 /*
  * This will be triggered when page's delete button clicked
  */
 public deletePg(i:number) {
   const pageEle = this.globalService.appData[i];
   let dontDelete = 0;
   let stageToBeDisplayed=-1;
   let selectedPage=-1;
   for(let k=0;k<pageEle.length;k++) {
      const ele = pageEle[k];
      if(ele.hasOwnProperty("buttons")) {
        const buttons = ele['buttons'];
        let isButtoninCondition = false;
        for (let b = 0; b < buttons.length; b++) {
            if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],buttons[b]['buttonRefId'])) {
              isButtoninCondition=true;
            }
        }
        if(isButtoninCondition) {
          dontDelete += 1;
        }
      } else if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'], ele['refId'])) {
        dontDelete += 1;
      }  else if(ele["type"]===this.constants.SEC_CONTAINER) {
        const sectionPages =ele['pages'];
        let isFieldInsideWidgetInCondition=false;
        for (let seci = 0; seci < sectionPages.length; seci++) {
            const widgetPages = sectionPages[seci];
            for (let j = 0; j < widgetPages.length; j++) {
                const fieldType = widgetPages[j]['type'];
                if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],widgetPages[j]['refId'])) {
                  isFieldInsideWidgetInCondition = true;
                } else if(fieldType === this.constants.GROUP_FIELD) {
                  const groupField = widgetPages[j].groupFields;
                    for (let groupCounter = 0; groupCounter < groupField.length; groupCounter++) {
                      const groupFieldChildType = groupField[groupCounter]['type'];
                      if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],groupField[groupCounter]['refId'])) {
                        isFieldInsideWidgetInCondition = true;
                      } else if(groupFieldChildType === this.constants.MULTICOL) {
                        for(let m=0;m<4;m++) {
                          if(typeof groupField[groupCounter].fieldsObj['col'+m] !=="undefined") {
                            const multiColFields = groupField[groupCounter].fieldsObj['col'+m];
                            if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
                              isFieldInsideWidgetInCondition = true;
                            }
                          }
                        }
                      } else if(groupFieldChildType === this.constants.GRIDTABLE_FIELD) {
                        if(groupField[groupCounter]['columns'].length > 0) {
                          for (let gridTableCounter = 0; gridTableCounter < groupField[groupCounter]['columns'].length; gridTableCounter++) {
                              const column = groupField[groupCounter]['columns'][gridTableCounter];
                              const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                              const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                              const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                              if(refIdName || refIdRadioName || refIdTextName) {
                                isFieldInsideWidgetInCondition=true;
                              }
                          }
                        }
                      }
                    }
                } else if(fieldType === this.constants.MULTICOL) {
                  for(let m=0;m<4;m++) {
                    if(typeof widgetPages[j].fieldsObj['col'+m] !=="undefined") {
                      const multiColFields = widgetPages[j].fieldsObj['col'+m];
                      if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
                        isFieldInsideWidgetInCondition = true;
                      }
                    }
                  }
                } else if(fieldType === this.constants.GRIDTABLE_FIELD) {
                  if(widgetPages[j]['columns'].length > 0) {
                    for (let gridTableCounter = 0; gridTableCounter < widgetPages[j]['columns'].length; gridTableCounter++) {
                        const column = widgetPages[j]['columns'][gridTableCounter];
                        const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                        const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                        const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                        if(refIdName || refIdRadioName || refIdTextName) {
                          isFieldInsideWidgetInCondition=true;
                        }
                    }
                  }
                }
            }
        }
        if(isFieldInsideWidgetInCondition) {
            dontDelete += 1;
        }
      } else if(ele["type"]===this.constants.GRIDTABLE_FIELD) {
        // check if grid table exist in conditions
        const gridTable = ele;
        let isgridTableinCondition = false;
        if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],gridTable['refId'])) {
          isgridTableinCondition=true;
        } else {
          // check if child components of grid table exist in conditions
          if(gridTable['columns'].length > 0) {
            for (let gridTableCounter = 0; gridTableCounter < gridTable['columns'].length; gridTableCounter++) {
                const column = gridTable['columns'][gridTableCounter];
                const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                if(refIdName || refIdRadioName || refIdTextName) {
                  isgridTableinCondition=true;
                }
            }
          }
        }
        if(isgridTableinCondition) {
            dontDelete += 1;
        }
      } else if(ele["type"] === this.constants.GROUP_FIELD) {
        const groupField = ele.groupFields;
        let groupFieldinCondition = false;
        for (let groupCounter = 0; groupCounter < groupField.length; groupCounter++) {
          const groupFieldChildType = groupField[groupCounter]['type'];
          if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],groupField[groupCounter]['refId'])) {
            groupFieldinCondition = true;
          } else if(groupFieldChildType === this.constants.MULTICOL) {
            for(let m=0;m<4;m++) {
              if(typeof groupField[groupCounter].fieldsObj['col'+m] !=="undefined") {
                const multiColFields = groupField[groupCounter].fieldsObj['col'+m];
                if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
                  groupFieldinCondition = true;
                }
              }
            }
          } else if(groupFieldChildType === this.constants.GRIDTABLE_FIELD) {
            if(groupField[groupCounter]['columns'].length > 0) {
              for (let gridTableCounter = 0; gridTableCounter < groupField[groupCounter]['columns'].length; gridTableCounter++) {
                  const column = groupField[groupCounter]['columns'][gridTableCounter];
                  const refIdName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdName);
                  const refIdRadioName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdRadioName);
                  const refIdTextName = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],column.rowFieldConf.refIdTextName);
                  if(refIdName || refIdRadioName || refIdTextName) {
                    groupFieldinCondition=true;
                  }
              }
            }
          }
        }
        if(groupFieldinCondition) {
            dontDelete += 1;
        }
      } else if(ele["type"] === this.constants.MULTICOL) {
        let multiColFieldinCondition = false;
        for(let m=0;m<4;m++) {
          if(typeof ele.fieldsObj['col'+m] !=="undefined") {
            const multiColFields = ele.fieldsObj['col'+m];
            if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
              multiColFieldinCondition = true;
            }
          }
        }
        if(multiColFieldinCondition) {
            dontDelete += 1;
        }
      }
   }
   if(dontDelete) {
     this.fieldControlsService.onRemoveOutside({});
   } else {
     this.globalService.deleteAppDtByIndex(i);
     this.stages.splice(i, 1);
     this.pgArr.splice(i, 1);
     if(this.stages.length > 1) {
       if(i===0) {
         if(this.globalService.selectedIndexPgArr!==i) {
          // arr-1
          stageToBeDisplayed=this.globalService.selectedIndexPgArr-1;
          selectedPage = this.globalService.selectedIndexPgArr-1;
        } else {
          // 0
          stageToBeDisplayed=0;
          selectedPage = 0;
        }
       } else {
         if(this.globalService.selectedIndexPgArr>i) {
          // arr>1
          stageToBeDisplayed=this.globalService.selectedIndexPgArr-1;
          selectedPage = this.globalService.selectedIndexPgArr-1;
        } else {
          // i-1
          stageToBeDisplayed=i-1;
          selectedPage = i-1;
        }
       }
     }else {
       // 0
       stageToBeDisplayed=0;
       selectedPage = 0;
     }
     this.stages.forEach((obj)=>obj.isShow = false);

     if(stageToBeDisplayed !== -1) {
       this.stages[stageToBeDisplayed]['isShow'] = true;
     }

     if(selectedPage !== -1) {
       this.globalService.selectedIndexPgArr = selectedPage;
     }
     const timeoutId = setTimeout(() => {
       this.ddcomp.reLoadFields(this.globalService.selectedIndexPgArr);
     }, 100);
     this.asideService.closeAside({});
   }
  }
}
