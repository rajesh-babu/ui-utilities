import { Component, Input } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { UtilityService} from '../../../../services/UtilityService';
import { GlobalService} from '../../../../services/GlobalService';
import { FieldControlsService} from '../../../../services/FieldControlsService';
import { NavService } from '../../../../services/NavService';
import { Constants } from '../../../../services/Constants';

declare var $:any;

@Component({
  selector: 'field-controls',
  templateUrl: './fieldControls.component.html'
})
export class FieldControlsComponent {
  @Input() fieldType:string;
  @Input() isConditional:boolean;
  public isSettShow:boolean = true;

  public constructor(private asideService:AsideService,private utilityService:UtilityService, private constants:Constants,
                    private fieldControlsService:FieldControlsService, private globalService:GlobalService,
                    public navService:NavService ) {}

  /*
   * It will be triggered when user clicks the delete icon
   */
  removeHandler(evt:Event) {
    const elem = this.getRootEleIndexPos(evt),
      $currentEle = $(evt.currentTarget),
      $multiColParentEle = $currentEle.closest('.multiColPl'),
      $grpFieldParentEle = $currentEle.closest('.'+ this.constants.droppedGrpItemCls),
      $grpFieldMultiCol = $grpFieldParentEle.find('.multiColPl'),
      $grpFieldGridTable = $grpFieldParentEle.find('.gridTable'),
      $widgetParentEle = $currentEle.closest('.secContainer');
    let colIndex;
    // IF delete performed for one of the multi column field
    if($grpFieldParentEle.length) {
        const rowIndex = this.utilityService.getCompIndexPos($grpFieldParentEle.attr('class'));
        if($multiColParentEle.length) {
          if($multiColParentEle.hasClass('col0')) {
            colIndex = 0;
          }else if($multiColParentEle.hasClass('col1')) {
            colIndex = 1;
          }else if($multiColParentEle.hasClass('col2')) {
            colIndex = 2;
          }else if($multiColParentEle.hasClass('col3')) {
            colIndex = 3;
          }

          const obj = {indexPos:elem._indexPos, colIndexPos: colIndex, grpIndexPos:rowIndex};

          // Below 'colIndexPos' used in multicol.component.ts
          this.fieldControlsService.onMultiColRemove(obj);
        } else if($grpFieldMultiCol.length > 0) {
          // Multi column in group
          if($grpFieldParentEle.find(".multiCol.added").length > 0) {
            // Multi column has child, show message popup
            this.fieldControlsService.onGrpFieldRemove({indexPos:elem._indexPos, grpIndexPos:rowIndex,msgPopup:true,fieldType:this.constants.MULTICOL});
            // show delete popup, do delete action.
          } else {
            this.fieldControlsService.onGrpFieldRemove({indexPos:elem._indexPos, grpIndexPos:rowIndex});
          }
        } else if($grpFieldGridTable.length > 0) {
          // check for columns exist in conditions
          this.fieldControlsService.onGrpFieldRemove({indexPos:elem._indexPos, grpIndexPos:rowIndex,fieldType:this.constants.GRIDTABLE_FIELD});
        } else {
          // show delete popup, do delete action.
          this.fieldControlsService.onGrpFieldRemove({indexPos:elem._indexPos, grpIndexPos:rowIndex});
        }
    } else if($multiColParentEle.length) {
      if($multiColParentEle.hasClass('col0')) {
        colIndex = 0;
      }else if($multiColParentEle.hasClass('col1')) {
        colIndex = 1;
      }else if($multiColParentEle.hasClass('col2')) {
        colIndex = 2;
      }else if($multiColParentEle.hasClass('col3')) {
        colIndex = 3;
      }

      const obj = {indexPos:elem._indexPos, colIndexPos: colIndex};

      // If multi column field inside the group field, pass the grpIndexPos. it's used when deleting the one of the multi column field.
      if($grpFieldParentEle.length) {
        const grpIndexPos = this.utilityService.getCompIndexPos($grpFieldParentEle.attr('class'));
        obj['grpIndexPos'] = grpIndexPos;
      }

      // Below 'colIndexPos' used in multicol.component.ts
      this.fieldControlsService.onMultiColRemove(obj);
    } else if($widgetParentEle.length > 0) {
      this.fieldControlsService.onRemove({indexPos:elem._indexPos});
    } else {
      this.fieldControlsService.onRemove({indexPos:elem._indexPos});
    }
    this.asideService.closeAside({});
    this.globalService.addUpdateAllIndexPos();
  }

  /*
   * It will be triggered when user clicks the settings icon
   */
  openAsideComp(evt:Event) {
    const elem = this.getRootEleIndexPos(evt),
      _data = this.globalService.getappData(elem._indexPos);
    const $mEle = $(evt.currentTarget).closest('.multiColPl');
    if($mEle.length) {
      // Get the corresponding column by it's class name ex:col1
      const matColCls = $mEle.attr('class').match(/col[\w-]*\b/);
      if(matColCls && matColCls.length) {
        if(_data.type === this.constants.GROUP_FIELD) { // For multi column iside group fields
          const $grpEle = $(evt.currentTarget).closest('.droppedGrpItem');
          const grpPos = this.utilityService.getCompIndexPos($grpEle.attr('class'));
          _data.groupFields[grpPos].fieldsObj[matColCls[0]]['isMultiCol'] = true;
        } else if(_data.type === this.constants.MULTICOL) { // For multi column
          _data.fieldsObj[matColCls[0]]['isMultiCol'] = true;
        }
      }

      /*if(matColCls && matColCls.length && _data.fieldsObj) {
        _data.fieldsObj[matColCls[0]]['isMultiCol'] = ($mEle.length)? true:false;
      }*/

    }
    this.asideService.openAside({type:this.fieldType, data:_data, indexPos:elem._indexPos, isToggle:true});
  }

  /*
   * Get the root element and index position of the component
   */
   getRootEleIndexPos(evt:Event) {
     const $rootEle = $(evt.currentTarget).closest(this.constants.DROPPEDITEM_CLS),
       _indexPos = this.utilityService.getCompIndexPos($rootEle.attr('class'));
       return {$rootEle: $rootEle, _indexPos:_indexPos};
   }
   /*
    * This will be triggered from multicolumn as it's not required
    */
    public hideSettingsBut() {
      this.isSettShow = false;
    }

}
