import { Component } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild, EventEmitter } from '@angular/core';
import { AsideTextFieldComponent } from './textfield/aside/aside-text-field.component';
import { AsideService} from '../../services/AsideService';
import { GlobalService } from '../../services/GlobalService';
import { Constants } from '../../services/Constants';
declare var $:any;

@Component({
  selector: 'aside-component',
  templateUrl: './aside.component.html'
})
export class AsideComponent {
 fieldType:string;
 data:any;
 indexPos:number;
 addiData:any = {namesArr:[], tokensArr:[]};
 public insideSecCls:string;
 public constructor( private componentFactoryResolver: ComponentFactoryResolver, private asideService:AsideService,
                     public constants:Constants, private globalService:GlobalService) {
   this.asideService.asideOpen$.subscribe((obj) => {

     // set the flag  true to to make selected component visible
     this.fieldType = obj['type'];

     // pass the source values to corresponding field
     this.data = obj['data'];

     // Assign the Additional FW inputs to data
     const fwDt = this.globalService.additionalFwDt;
     if(fwDt) {
       if(fwDt.nameData) {
         this.addiData['namesArr'] = fwDt.nameData;
       }
       if(fwDt.tokenData) {
         this.addiData['tokensArr'] = fwDt.tokenData;
       }
     }

     // Index Position
     this.indexPos = obj['indexPos'];

     // Toggle the aside menu. Toggle if it's clicked control button
     if(obj['isToggle']) {
       document.querySelector('body').classList.remove('aside-menu-hidden');
     }
     // set the class "insideSec" If user clicks the field or icon button which is inside the Sec container
     if(obj[this.constants.isInsideSecContainer]) {
       this.insideSecCls = this.constants.insideSecCls;
     }else {
       this.insideSecCls = '';
     }
   });

   this.asideService.asideClose$.subscribe(() => {
    $('body').addClass('aside-menu-hidden');
   });

   this.asideService.asideAccordion$.subscribe((index) => {
     const thisRef = this;
     if(thisRef.fieldType===thisRef.constants.BUTTON_FIELD || thisRef.fieldType===thisRef.constants.GRIDTABLE_FIELD) {
       thisRef.asideService.destroyAccordion();
       setTimeout(function(){
         const accordionIcons = {
           header: "fa fa-fw fa-caret-right",
           activeHeader: "fa fa-fw fa-caret-down"
         };

         $(".accordion-component")
           .accordion({
             header: ".accordion-header",
             collapsible: true,
             icons:accordionIcons,
             heightStyle: "content",
             active: index
           })
           .sortable({
             axis: "y",
             handle: ".accordion-header",
             stop: function( event, ui ) {
             // IE doesn't register the blur when sorting
             // so trigger focusout handlers to remove .ui-state-focus
             ui.item.children( ".accordion-header" ).triggerHandler( "focusout" );


             // Refresh accordion to handle new order
             $(this).accordion( "refresh" );
             // Loop and store button order displayed in aside
             const sortedButtonOrder = [];
             const sortedOrder = [];
             $(".group").each(function(){
               const classNamesStr = $(this).find(".accordion-header").attr("class");
                const classes:any = classNamesStr.split(' ');
                let result: number;
                for (let i = 0; i < classes.length; i++) {
                  const matches = /^accordion_(.+)/.exec(classes[i]);
                  if (matches != null) {
                    result = Number(matches[1]);
                  }
                }
                sortedButtonOrder.push(result);
             });

             // Button Field
             if(thisRef.data.hasOwnProperty('buttons')) {
                for (let i = 0; i < sortedButtonOrder.length; i++) {
                  for (let k = 0; k < thisRef.data.buttons.length; k++) {
                      if(sortedButtonOrder[i]===thisRef.data.buttons[k]['buttonRefId']) {
                        sortedOrder[i]=thisRef.data.buttons[k];
                      }
                  }
                }
                thisRef.data.buttons = sortedOrder;
              }else if(thisRef.data.hasOwnProperty('columns')) {
                for (let i = 0; i < sortedButtonOrder.length; i++) {
                  for (let k = 0; k < thisRef.data.columns.length; k++) {
                      if(sortedButtonOrder[i]===thisRef.data.columns[k]['rowFieldConf']['refIdName']) {
                        sortedOrder[i]=thisRef.data.columns[k];
                      }
                  }
                }
                thisRef.data.columns = sortedOrder;
              }
              thisRef.asideService.updateView();

           }
         });
        }, 10);
     } else {
         thisRef.asideService.destroyAccordion();
     }
   });
 }

}
