import { Component, Input } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { HeaderFieldModel } from '../headerfield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-header-field',
  templateUrl: './aside-header-field.component.html',
})
export class AsideHeaderFieldComponent {
  @Input() fieldData:HeaderFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  headerFieldFormGrp:any;
  disbleOption:boolean = false;
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.headerFieldFormGrp = this.formBuilder.group({
                              'text':['',[]],
                              'text_override':['',[]],
                              'id':['',[ValidationService.attributeValidator]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'size':['',[]],
                              'alignment':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'hidefield':['',[]],
                              'hidefield_override':['',[]]
                           });
                      }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField(
      {field:this.constants.HEADER_FIELD, values:JSON.parse(JSON.stringify(this.fieldData)),
        indexPos:this.indexPos});
  }
}
