declare var $:any;
export class HeaderFieldModel {
  id:string;
  name:string;
  name_override:string;
  cssClass:string;
  indexPos: number;
  text:string;
  text_override:string;
  // subLabelText:string;
  hidefield:boolean;
  hidefield_override:boolean;
  adaAttrs:string;
  alignment:string;
  size:string;
  public componentName:string = 'Header';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class HeaderFieldModalText {
  SUB_LABEL_TEXT:string = 'Type a sublabel';
  HEADER_TEXT:string = 'Type a Header Text';


}
