import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HeaderfieldComponent } from './headerfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [HeaderfieldComponent],
  providers:[AsideService],
  entryComponents: [HeaderfieldComponent]
})
export class HeaderFieldModule { }
