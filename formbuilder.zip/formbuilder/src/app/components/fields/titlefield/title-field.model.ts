declare var $:any;
export class TitleModel {
  indexPos: number;
  public componentName:string = 'Title';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public label:string;
  public label_override:string;
  public pgTopIndex:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class TitleModelText {
  LABEL_PLACE_HOLDER:string = 'Enter Title Text';
}
