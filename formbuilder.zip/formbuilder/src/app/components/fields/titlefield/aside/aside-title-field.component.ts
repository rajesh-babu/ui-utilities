import { Component, Input } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { TitleModel } from '../title-field.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-title-field',
  templateUrl: './aside-title-field.component.html'
})
export class AsideTitleComponent {
  @Input() fieldData:TitleModel;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  titleFieldFormGrp:any;

  public constructor(public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.titleFieldFormGrp = this.formBuilder.group({
                          'label':['',[]],
                          'label_override': ['', []],
                        });
  }
}
