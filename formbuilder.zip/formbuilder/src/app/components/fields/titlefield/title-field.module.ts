import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TitleComponent} from './title-field.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    TitleComponent
  ],
  providers: [AsideService],
  entryComponents: [  TitleComponent ],
})
export class TitleModule { }
