import { Component, AfterViewInit, ChangeDetectorRef} from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { ButtonFieldModel } from './buttonfield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'button-field',
  templateUrl: './buttonfield.component.html'
})
export class ButtonfieldComponent implements AfterViewInit {
  public buttonFieldModel:ButtonFieldModel = new ButtonFieldModel();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(public asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService, private cdRef:ChangeDetectorRef) {
    this.buttonFieldModel['type'] = this.constants.BUTTON_FIELD;
    this.buttonFieldModel['refId'] = utilityService.timeasRefId();
    this.asideService.updateView$.subscribe(() => {
      this.cdRef.detectChanges();
     });
  }

  /*
   * This will be triggered upon loading the form and pre populating
   */
   public setAppData(_data:any, _index:number, isReLoadFields:boolean) {

     if(_data) { // If existing data
       this.buttonFieldModel = _data;
     } else {
       // For Grid table, generated 3 types of refId for manging the conditional logic datas
       for(let i=0;i<this.buttonFieldModel['buttons'].length;i++) {
         const thatRef = this;
         setTimeout(function(){thatRef.buttonFieldModel['buttons'][i]['buttonRefId']=thatRef.utilityService.timeasRefId(); }, 10);
       }
     }
     if(!isReLoadFields) { this.globalService.addappData(this.buttonFieldModel, _index); }
   }
   /*
    * This will be triggered upon dropping the component in multi column
    */
   public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
     if(_data) { // If existing data
       this.buttonFieldModel = _data;
     }
     this.buttonFieldModel['colIndex'] = _colIndex;

     if(typeof(grpRowIndex) !== 'undefined') {
       this.buttonFieldModel['grpRowIndex'] = grpRowIndex;
     }

     // If Multi column inside the secContainer, dont set the Data to AppData
     if(!isSecContainer) {
       this.globalService.addappData(this.buttonFieldModel, _index, true, isGroupField);
     }
   }

   /*
    * This will be triggered upon dropping the component in Group field
    */
   public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.buttonFieldModel = _data;
     } else {
       if(!isReLoadFields) {
         // For button, each button has refId for manging the conditional logic datas
         for(let i=0;i<this.buttonFieldModel['buttons'].length;i++) {
           const thatRef = this;
           setTimeout(function(){thatRef.buttonFieldModel['buttons'][i]['buttonRefId']=thatRef.utilityService.timeasRefId(); }, 10);
         }
       }
     }
     this.buttonFieldModel['grpRowIndex'] = _grpRowIndex;
     this.buttonFieldModel['indexPos'] = _index;

     if(!isReLoadFields) { this.globalService.addappData(this.buttonFieldModel, _index, false, true); }
   }
  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.BUTTON_FIELD, data:this.buttonFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
    this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.BUTTON_FIELD, data:this.buttonFieldModel,
      indexPos:this.currentSelectedIndexPos, isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }
}
