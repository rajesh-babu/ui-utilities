import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { ButtonFieldModel } from '../buttonfield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { UtilityService } from '../../../../services/UtilityService';
import { FieldControlsService} from '../../../../services/FieldControlsService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
declare var $:any;

@Component({
  selector: 'aside-button-field',
  templateUrl: './aside-button-field.component.html'
})
export class AsideButtonFieldComponent implements OnChanges {
  @Input() fieldData:ButtonFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  disbleOption:boolean = false;
  buttonFieldFormGrp:any;
  nameValidArray:Array<any> = [ValidationService.customRequiredVal,ValidationService.attributeVal];
  adaValidArray:Array<any> = [ValidationService.adaAttributesVal];
  otherValidArray:Array<any> = [ValidationService.attributeVal];
  popupCollection:Array<any> = [];
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService, public globalService:GlobalService,
                      private fieldControlsService:FieldControlsService, private utilityService:UtilityService) {}

  ngOnChanges(changes: SimpleChanges) {
    if(changes['fieldData']) {
      this.popupCollection = [];
      this.findAllPopup();
   }
  }
  /*
   * Fetch all popup widgets and store in array
   */
  findAllPopup() {
    const _this = this;
    if(this.globalService.appGlobalData.pages.length > 0) {
      const globalDataPages = this.globalService.appGlobalData.pages;
      for(let i=0; i<globalDataPages.length;i++) {
        const formFields = globalDataPages[i];
        for(let k=0; k<formFields.length;k++) {
          if(formFields[k].popup && k !== this.fieldData.indexPos) {
            _this.popupCollection.push({'label':formFields[k].name,'value':formFields[k].name});
          }
        }
      }
    }
  }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.BUTTON_FIELD,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }

  /*
   * Remove the buttons row
   */
  removeRow(index:number) {
    const _this = this;
    if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['refId'], this.fieldData.buttons[index]['buttonRefId'])) {
      this.fieldControlsService.onRemoveOutside({});
    } else {
      this.fieldData.buttons.splice(index,1);
    }
    setTimeout(function(){
      _this.asideService.initAccordion(0);
   }, 200);
  }
  /*
   * Add the buttons row
   */
  addRow() {
    const _this = this;
    $.each(this.fieldData.buttons,function(i,v) {v.open=false;} );
    this.fieldData.buttons.push({label:'Submit',method:'Submit',cssclass:'btn',disabled:'',
    id:'',name:'',adaAttrs:'',validation:'',action:'',title:'', open:true,buttonRefId:this.utilityService.timeasRefId()});
    setTimeout(function(){
      _this.asideService.initAccordion(_this.fieldData.buttons.length - 1);
   }, 200);
  }

  toggleOption(e:string) {
    if(/\S/.test(e)) {
      this.disbleOption = true;
    } else {
      this.disbleOption = false;
    }
  }

}
