declare var $:any;
export class ButtonFieldModel {
  indexPos: number;
  buttons:Array<Object> =[
      {label:'Cancel',method:'Cancel', cssClass:'', buttonStyle:'btn btnLink',validation:'yes',buttonRefId:'',udLabelText:''},
      {label:'Submit',method:'Submit',cssClass:'', buttonStyle:'btn btn4',validation:'yes',buttonRefId:'',udLabelText:''}];
  selectedIndex:number;
  helpText:string;
  hidefield:boolean;
  stickyButton:boolean;
  isLink:boolean;
  public type:string;
  public componentName:string = 'Button';
  public isConditional:boolean = false;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
