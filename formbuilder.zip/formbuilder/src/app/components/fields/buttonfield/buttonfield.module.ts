import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ButtonfieldComponent} from './buttonfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    FormsModule
  ],
  declarations: [
    ButtonfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  ButtonfieldComponent ]
})
export class ButtonFieldModule { }
