import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SelectfieldComponent} from './selectfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    SelectfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  SelectfieldComponent ]
})
export class SelectFieldModule { }
