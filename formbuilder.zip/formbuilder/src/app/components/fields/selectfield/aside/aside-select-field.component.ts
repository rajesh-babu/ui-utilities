import { Component, Input, OnInit } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { SelectFieldModel } from '../selectfield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
import { UtilityService } from '../../../../services/UtilityService';
import { FieldControlsService} from '../../../../services/FieldControlsService';
declare var $:any;

@Component({
  selector: 'aside-select-field',
  templateUrl: './aside-select-field.component.html'
})
export class AsideSelectFieldComponent implements OnInit {
  @Input() fieldData:SelectFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  selectFieldFormGrp:any;
  disbleOption:boolean = false;
  optionCount:number = 3;
  optionValidation:boolean = false;
  optionDuplicateCount:number;
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService,
                      private utilityService:UtilityService,
                      private formBuilder: FormBuilder, public globalService:GlobalService,
                      private fieldControlsService:FieldControlsService) {
                        this.selectFieldFormGrp = this.formBuilder.group({
                              'labelText':['',[]],
                              'reviewLabelText':['',[]],
                              'udLabelText':['',[]],
                              'id':['',[ValidationService.attributeValidator]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'size':['',[]],
                              'token':['',[]],
                              'required':'',
                              'populateCountry':'',
                              'UsaStateDropDownName':['',[]],
                              'UsaStateDropDownName_override':['',[]],
                              'populateUsaState':'',
                              'category':['',[]],
                              'dataSourceReference':['',[]],
                              'filterConditions':['',[]],
                              'rowNumber':['',[]],
                              'helpText':['',[]],
                              'errmsg':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'disabled':['',[]],
                              'hidefield':['',[]],
                              'fieldStyle':['',[]],
                              'hidefield_override':['',[]],
                              'populatePlanSponserData': ['', []]
                           });
                      }

  ngOnInit() {
    this.updateRowNumber();
  }

  updateRowNumber() {
    if(this.fieldData.hasOwnProperty('options')) {
      this.fieldData.rowNumber = this.fieldData.options.length + 1;
    }
  }

  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField(
      {field:this.constants.SELECT_FIELD, values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }

  checkSingle(index:any) {
    this.fieldData.selectedIndex = -1;
    for(let i=0; i<this.fieldData.options.length; i++) {
      if(i === index) {
        if(this.fieldData.options[i]['selected'] === true) {
          this.fieldData.options[i]['selected'] = false;
        } else {
          this.fieldData.options[i]['selected'] = true;
          this.fieldData.selectedIndex = i;
        }
      } else {
        this.fieldData.options[i]['selected'] = false;
      }
     }
  }

  /*
   * Remove the options row
   */
  removeRow(index:number) {
    if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['optionRefId'], this.fieldData.options[index]['optionRefId'])) {
      this.fieldControlsService.onRemoveOutside({});
    } else {
      this.fieldData.options.splice(index,1);
      this.updateRowNumber();
    }
  }
  /*
   * Add the options row
   */
   addRow() {
     if(this.fieldData.rowNumber !== 0 && this.fieldData.rowNumber <= this.fieldData.options.length) {
       this.fieldData.options.splice((this.fieldData.rowNumber - 1), 0,
       {label:'option ' + this.optionCount, value:'value ' + this.optionCount, selected:false, optionRefId:this.utilityService.timeasRefId()});
     } else {
       this.fieldData.options.push({label:'option ' + this.optionCount, value:'value ' + this.optionCount, selected:false, optionRefId:this.utilityService.timeasRefId()});
     }
     this.optionCount++;
     this.updateRowNumber();
   }

  toggleOption(e:string) {
    if(/\S/.test(e)) {
      this.disbleOption = true;
    }else {
      this.disbleOption = false;
    }
  }
  /*
   * Upon changing the Datasource Reference or Filter condition, generate the script string accordingly
   */
  dataSrcFilterChange() {
    if(this.fieldData.dataSourceReference) {
      const randomNo = Math.floor(Math.random() * 1000) + 1;
      this.fieldData.dataSourceScriptStr =  this.utilityService.genearteJSPreviewMode(this.fieldData.dataSourceReference, this.fieldData.filterConditions, randomNo);
      const drArr = this.fieldData.dataSourceReference.split('.');
      this.fieldData.dataSourceReferenceVar = drArr.join('') + randomNo;
    } else {
      this.fieldData.dataSourceScriptStr = '';
    }
  }

  checkOptionsDuplicate(thisObj:any) {
    $(thisObj).parent('ol.sortable-options').find('li').removeClass('has-error');
    this.optionDuplicateCount = (<any>this.fieldData.options).filter((opt, index, self) =>
      self.findIndex(o => o.value === opt.value) !== index).length;
    if(this.optionDuplicateCount) {
        this.optionValidation = true;
        $(thisObj).addClass('has-error');
    }else {
      this.optionValidation = false;
    }
  }
}
