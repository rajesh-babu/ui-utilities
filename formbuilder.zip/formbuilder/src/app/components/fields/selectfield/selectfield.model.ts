declare var $:any;
export class SelectFieldModel {
  indexPos: number;
  labelText:string = 'Label Text';
  reviewLabelText:string;
  udLabelText:string;
  required: boolean;
  id:string;
  name:string;
  name_override:string;
  cssClass:string;
  token:string;
  disabled:boolean = false;
  options:Array<Object> = [{label:'option 1', value: 'value 1', optionRefId:''}, {label:'option 2', value: 'value 2', optionRefId:''}];
  selectedIndex:number = 0;
  category:string;
  dataSourceReference:string;
  rowNumber:number;
  helpText:string;
  hidefield:boolean;
  hidefield_override:boolean;
  populatePlanSponserData:boolean;
  adaAttrs:string;
  alignment:string;
  size:number;
  populateCountry: boolean = false;
  UsaStateDropDownName:string;
  UsaStateDropDownName_override:string;
  populateUsaState: boolean = false;
  public componentName:string = 'DropDown';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public dataSourceScriptStr:string;
  public filterConditions:string;
  public dataSourceReferenceVar:string;
  public fieldStyle:string = 'type_1';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class SelectFieldModelVars {
  public DEF_LAB_TXT:String = 'Type a Label Text';
}
