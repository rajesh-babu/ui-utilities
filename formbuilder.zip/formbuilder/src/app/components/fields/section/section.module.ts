import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SectionComponent} from './section.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    SectionComponent
  ],
  providers: [AsideService],
  entryComponents: [  SectionComponent ],
})
export class SectionModule { }
