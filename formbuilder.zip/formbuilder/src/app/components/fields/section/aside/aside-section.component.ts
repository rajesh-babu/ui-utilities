import { Component, Input, OnInit } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { SectionModel } from '../section.model';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'aside-section-field',
  templateUrl: './aside-section.component.html'
})
export class AsideSectionComponent {
  @Input() fieldData:SectionModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;


  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants) {}
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.SECTION,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }
}
