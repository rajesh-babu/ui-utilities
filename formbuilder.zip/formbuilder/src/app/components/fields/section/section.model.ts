declare var $:any;
export class SectionModel {
  public titleTxt:string = 'WIDGET';
  public componentName:string = 'Section';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
