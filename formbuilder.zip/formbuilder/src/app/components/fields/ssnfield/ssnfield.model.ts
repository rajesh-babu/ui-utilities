declare var $:any;
export class SsnFieldModel {
  public id1:string;
  public id2:string;
  public id3:string;
  public name1:string;
  public name2:string;
  public name3:string;
  public name1_override:string;
  public name2_override:string;
  public name3_override:string;
  public cssClass1:string;
  public cssClass2:string;
  public cssClass3:string;
  public indexPos: number;
  public labelText:string = 'SSN Label Text';
  public reviewLabelText:string;
  public udLabelText:string;
  public required: boolean = true;
  public size1:number;
  public size2:number;
  public size3:number;
  public numberofFields:number = 1;
  public hidefield:boolean;
  public hidefield_override:boolean;
  public disabled:boolean;
  public token1:string;
  public token2:string;
  public token3:string;
  public placeHolder1:string = '';
  public placeHolder2:string = '';
  public placeHolder3:string = '';
  public adaAttrs:string;
  public componentName:string = 'SSN';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public fieldStyle:string = 'type_1';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class SsnFieldModelVars {
  public ID:string = 'id';
  public NAME:string = 'name';
  public INDEXPOS:string = 'indexPos';
  public DEF_LAB_TXT:String = 'SSN Label Text';
  public LABELTEXT:string = 'labelText';
  public REQUIRED:string = 'required';
}
