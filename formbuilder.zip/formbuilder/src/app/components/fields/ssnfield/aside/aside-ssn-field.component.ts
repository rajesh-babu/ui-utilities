import { Component, Input, OnInit } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { SsnFieldModel, SsnFieldModelVars } from '../ssnfield.model';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
declare var $:any;
@Component({
  selector: 'aside-ssn-field',
  templateUrl: './aside-ssn-field.component.html'
})
export class AsideSsnFieldComponent {
  @Input() fieldData:SsnFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  ssnFieldFormGrp:any;
  public ssnFieldModelVars:SsnFieldModelVars = new SsnFieldModelVars();

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.ssnFieldFormGrp = this.formBuilder.group({
                              'labelText':['',[]],
                              'reviewLabelText':['',[]],
                              'udLabelText':['',[]],
                              'id1':['',[ValidationService.attributeValidator]],
                              'id2':['',[ValidationService.attributeValidator]],
                              'id3':['',[ValidationService.attributeValidator]],
                              'name1': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name2': ['', [ValidationService.ssnRequiredValidator]],
                              'name3': ['', [ValidationService.ssnRequiredValidator]],
                              'name1_override': ['', [ValidationService.attributeValidator]],
                              'name2_override': ['', [ValidationService.ssnRequiredValidator]],
                              'name3_override': ['', [ValidationService.ssnRequiredValidator]],
                              'cssClass1':['',[]],
                              'cssClass2':['',[]],
                              'cssClass3':['',[]],
                              'size1':['',[]],
                              'size2':['',[]],
                              'size3':['',[]],
                              'numberofFields':['',[]],
                              'token1':['',[]],
                              'token2':['',[]],
                              'token3':['',[]],
                              'required':'',
                              'errmsg':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'placeHolder1':['',[]],
                              'placeHolder2':['',[]],
                              'placeHolder3':['',[]],
                              'disabled':['',[]],
                              'hidefield':['',[]],
                              'fieldStyle':['',[]],
                              'hidefield_override':['',[]]
                           });
                      }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.SSN_FIELD,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }
  numberofFieldsChanged(e:any) {
    const placeHolder = this.fieldData.placeHolder1;
    if(e.target.value==="3") {
      this.fieldData.placeHolder1 = (placeHolder? placeHolder.substr(0,3):'');
      $(".small-or-none").addClass("form-control-small");
    } else {
      this.fieldData.placeHolder1 = placeHolder;
      $(".small-or-none").removeClass("form-control-small");
    }
  }
}
