import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SsnfieldComponent} from './ssnfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    SsnfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  SsnfieldComponent ],
})
export class SsnFieldModule { }
