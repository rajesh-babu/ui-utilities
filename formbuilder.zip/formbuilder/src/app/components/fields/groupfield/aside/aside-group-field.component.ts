import { Component, Input } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { GlobalService} from '../../../../services/GlobalService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GroupFieldModel } from '../groupfield.model';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-group-field',
  templateUrl: './aside-group-field.component.html'
})

export class AsideGrpFieldComponent {
  @Input() fieldData:GroupFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  grpFieldFormGrp:any;

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder,
                      public globalService:GlobalService) {
        this.grpFieldFormGrp = this.formBuilder.group({

              'name': ['', [Validators.required, ValidationService.attributeValidator]],
              'udLabelText': ['',[]],
              'labelText': ['',[]],
              'investmentListVariation': ['',[]],
              'category':['',[]],
              'maxLimit':['',[]],
              'minLimit':['',[]],
              'bgColor':['',[]],
              'popup': ['',[]],
              'popupWidth': ['',[]],
              'popupTitle': ['',[]],
              'hidefield':['',[]],
              'hidefield_override': ['', []],
              'address1': ['', []],
              'address1_override': ['', []],
              'address2': ['', []],
              'address2_override': ['', []],
              'address3': ['', []],
              'address3_override': ['', []],
              'city' : ['', []],
              'city_override' : ['', []],
              'province': ['', []],
              'province_override': ['', []],
              'postalCode': ['', []],
              'postalCode_override': ['', []],
              'zipCode': ['', []],
              'zipCode_override': ['', []],
              'state': ['', []],
              'state_override': ['', []],
              'country': ['', []],
              'country_override': ['', []],
           });
  }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.GROUP_FIELD,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }
}
