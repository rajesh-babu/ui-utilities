import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { GroupFieldComponent } from './groupfield.component';
import { AsideService} from '../../../services/AsideService';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { DragulaModule} from 'ng2-dragula';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    DragulaModule
  ],
  declarations: [
    GroupFieldComponent
  ],
  exports:[GroupFieldComponent],
  providers: [AsideService, FieldsFactoryService],
  entryComponents: [ GroupFieldComponent ]
})
export class GroupFieldModule { }
