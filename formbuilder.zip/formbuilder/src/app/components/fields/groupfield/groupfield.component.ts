import { Component, AfterViewInit,ViewContainerRef, ViewChild , ComponentRef,
         ComponentFactoryResolver, OnInit,Inject, forwardRef} from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { FieldControlsService } from '../../../services/FieldControlsService';
import { Constants } from '../../../services/Constants';
import { TextfieldComponent} from '../textfield/textfield.component';
import { GroupFieldModel } from './groupfield.model';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';
import { CommonsFieldsService} from '../../../services/fields/CommonsFieldsService';
import { DragulaService } from 'ng2-dragula';

declare var $:any;

@Component({
  selector: 'group-field',
  templateUrl:'./groupfield.component.html'
})

export class GroupFieldComponent implements AfterViewInit {

  @ViewChild('widgetGroupField', {read: ViewContainerRef}) widgetGroupField;
  cmpRef: ComponentRef<Component>;
  compPosition:number = 0;

  @ViewChild(FieldControlsComponent) fc:FieldControlsComponent;

  public groupFieldModel:GroupFieldModel = new GroupFieldModel();

  public added1:boolean;

  currentSelectedIndexPos:number;
  public className:string;

  constructor(private asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService,
              private componentFactoryResolver:ComponentFactoryResolver,
              private fieldControlsService:FieldControlsService,
              public commonsFieldsService:CommonsFieldsService,
              @Inject(forwardRef(() => FieldsFactoryService)) private fieldsFactoryService:FieldsFactoryService,
              private dragulaService:DragulaService) {
    this.groupFieldModel['type'] = this.constants.GROUP_FIELD;
    this.groupFieldModel['refId'] = utilityService.timeasRefId();

 }
 // This will be triggered from dd component upon clicking the duplicate of corresponding field
 public duplicateField(obj:any) {
   this.compPosition = obj['values'].grpRowIndex + 1;
   obj['values'] = this.globalService.generateRefIds(obj['values']);
   this.createComponent(obj['values'].type, obj['values'].indexPos, false, obj['values']);
 }

 /*
  * It will be triggered once dropped and trigger the aside component to change the view
  */
 ngAfterViewInit() {
   // set the Aside component if it has class "selected"
   if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
     const _indexPos = this.utilityService.getCompIndexPos(this['className']);
     this.asideService.openAside({
       type:this.constants.GROUP_FIELD, data:this.groupFieldModel, indexPos:_indexPos, isToggle:false
     });
   }
 }
 reorderIndexPos($grpFieldElems:any) {
   const thisRef = this;
   $grpFieldElems.each(function() {

     $(this).find('.'+thisRef.constants.droppedGrpItemCls).each(function(i){

       // Remove class starts with 'comp_'
       $(this).removeClass(function () {
           const className = this.className.match(/comp_\d+/);
           if (className) {
               return className[0];
           }
       });
       $(this)
        .addClass('comp_'+i);
     });
   });
 }
 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {

    if(_data) { // If existing data
      this.groupFieldModel = _data;
      for (let i=0;i<this.groupFieldModel.groupFields.length;i++) {

          const robj = this.groupFieldModel.groupFields[i];
          this.compPosition = i;
          this.createComponent(robj['type'], _index, true, robj);
      }
    }
    if(!isReLoadFields) { this.globalService.addappData(this.groupFieldModel, _index); }
  }

 // It will be triggered when user deleting the field and get Column IndexPos as parameter. Destroy the corresponding component created.
 public onDelete(obj:any) {
   if( typeof(obj.grpIndexPos) !== 'undefined') {
     (this.widgetGroupField.get(obj.grpIndexPos)).destroy();
     if(this.widgetGroupField.length === 0) {
       this.added1 = false;
     }
      // Delete the Global App data
      this.globalService.deleteGrpFieldappData(obj.indexPos, obj.grpIndexPos);

      // Reoder the index position after the deletion
      const timeoutId = setTimeout(() => {
        this.reorderIndexPos($('.'+this.constants.groupField_cls));
      }, 100);
    }
 }

 // (0 - bagname, 1 - el, 2 - target, 3 - source, 4 - sibling)
 public onDrop(value) {

   // This will be triggered from drag and drop component,  If field dropped in multi column
   if(value[2].classList.contains('multiCol') ) {
     const curreIndexPos = this.utilityService.getCompIndexPos( $(value[2]).closest('.'+this.constants.droppedGrpItemCls).attr('class'));
     this.widgetGroupField.get(curreIndexPos)._view.nodes[1].instance['onDrop'](value);
     return;
   }

   if(!value[2] || !value[2].classList.contains(this.constants.GROUP_FIELD)) {  // multiCol
     return;
   }

   // Delete the soure field
   value[1].outerHTML = '';

   if(value[1].getAttribute('data-fieldname') === this.constants.GROUP_FIELD && value[2].classList.contains(this.constants.GROUP_FIELD)) {

     // Dont allow if dropping multicolumn field within itself and Section
     return;
   }
   // Get the current row index
   const $selEle = $(value[2]).closest('.' + this.constants.DROPPEDITEM );
   if(!$selEle.length) { // Dont allow  non selected row
     return;
   }else {
     $selEle.addClass(this.constants.SELECTED);
   }
   const rowIndex = this.utilityService.getCompIndexPos($selEle.attr('class'));
   const fdName = value[1].getAttribute('data-fieldname');

   if(!value[4]) { // If it's dropped as last element
     this.compPosition = $(value[2]).find('.'+this.constants.groupField_cls).find('.'+this.constants.droppedGrpItemCls).length;
   }else if( value[4]) {

     // Check whether sibling node with class "droppedGrpItem", otherwise consider as 1st element
     const $sibEle = $(value[4]).find('.'+this.constants.droppedGrpItemCls);
     if($sibEle.length) {
       this.compPosition = this.utilityService.getCompIndexPos( $(value[4]).find('.'+this.constants.droppedGrpItemCls).attr('class'));
     }else {
       this.compPosition = $(value[2]).find('.'+this.constants.droppedGrpItemCls).length;
     }
   }
   this.createComponent(fdName, rowIndex, false);
   const timeoutId = setTimeout(() => {
     this.reorderIndexPos($('.'+this.constants.groupField_cls));
   }, 100);
   this.globalService.addUpdateAllIndexPos();
 }
 /*
  * It will create the fields to multicomponent
  */
 createComponent(fdName:string, _rowIndex:number, isReLoadFields:boolean, obj?:any) {
   let factory;
   const cls:any = this.fieldsFactoryService.getComponent(fdName);
   factory = this.componentFactoryResolver.resolveComponentFactory(cls['type']);

   this.cmpRef = this.widgetGroupField.createComponent(factory, this.compPosition);
   this.cmpRef['instance']['setGrpFieldAppData'](obj, _rowIndex, this.compPosition, isReLoadFields );
   this.cmpRef['instance']['className'] = this.constants.droppedGrpItemCls+' comp_'+this.compPosition+' parentRowIndex_'+_rowIndex;
   this.added1 = true;
   // Set subtype for Text area
   if(cls['subType']) {
     this.cmpRef['instance']['setSubType'](cls['subType']);
   }
 }

 itemClicked(e:Event) {
  const $currentEle = $(e.currentTarget),
    $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
  this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
  const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;
  const targetEle = $(e.target).closest('field-controls');
  if(!targetEle.length || targetEle.hasClass('groupField')) {
  // Open aside only for its own element and not for child elements
  const obj:any = {type:this.constants.GROUP_FIELD, data:this.groupFieldModel,
  indexPos:this.currentSelectedIndexPos, isToggle:false};
  obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
  this.asideService.openAside(obj);
 }

  // remove class "select" to all existing elements except currently selected
  $ele.removeClass(this.constants.SELECTED);
  $currentEle.addClass(this.constants.SELECTED);
}
}
