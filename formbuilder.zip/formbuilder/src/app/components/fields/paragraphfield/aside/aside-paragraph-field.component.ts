import { Component, Input, OnChanges, OnInit, OnDestroy } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { GlobalService} from '../../../../services/GlobalService';
import { Constants} from '../../../../services/Constants';
import { UtilityService} from '../../../../services/UtilityService';
import { ParagraphFieldModel, ParagraphFieldModelVars } from '../paragraphfield.model';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
declare var tinymce: any;
declare var $: any;

@Component({
  selector: 'aside-paragraph-field',
  templateUrl: './aside-paragraph-field.component.html'
})
export class AsideParagraphFieldComponent implements OnChanges, OnInit {

  public paragraphFieldModelVars:ParagraphFieldModelVars = new ParagraphFieldModelVars();

  @Input() fieldData:ParagraphFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  paragraphFieldFormGrp:any;
  asideParaId:string;

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder, public globalService:GlobalService,
                      public utilityService:UtilityService) {
                        this.asideParaId = 'asidePara_'+this.utilityService.timeasRefId();
                        this.paragraphFieldFormGrp = this.formBuilder.group({
                              'labelText':['',[]],
                              'labelText_override':['',[]],
                              'textArr_override_label':['',[]],
                              'textArr_override_desc':['',[]],
                              'paraType':['',[]],
                              'helpTextBGColor':['',[]],
                              'id':['',[ValidationService.attributeValidator]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'token':['',[]],
                              'hidefield':['',[]],
                              'rowNumber':['',[]],
                              'rowNumber_override':['',[]],
                              'hidefield_override':['',[]]
                           });
                      }

  ngOnInit() {
    this.updateRowNumber();
    if(this.fieldData.hasOwnProperty('labelText_override')) {
      this.updateParaId();
    }
  }

  ngOnChanges() {
    if(!this.fieldData.textArr_override) {
      this.fieldData.textArr_override = [{label:'', desc:''}];
    }
    this.updateRowNumberOverride();
    this.updateParaId();
  }

  updateRowNumber() {
    if(this.fieldData.hasOwnProperty('textArr')) {
      this.fieldData.rowNumber = this.fieldData.textArr.length + 1;
    }
  }
  updateParaId() {
    this.asideParaId = 'asidePara_'+this.utilityService.timeasRefId();
  }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({
      field:this.constants.PARAGRAPH_FIELD, values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos
    });
  }
  /*
   * Remove the options row
   */
  removeRow(index:number) {
    this.fieldData.textArr.splice(index,1);
    this.updateRowNumber();
  }
  /*
   * Add the options row
   */
   addRow() {
     if(this.fieldData.rowNumber !== 0 && this.fieldData.rowNumber <= this.fieldData.textArr.length) {
       this.fieldData.textArr.splice((this.fieldData.rowNumber - 1), 0,
       {label:'Paragraph Text', desc:'Type Description Text here...', paraId:this.utilityService.getUniqueElementId()});
     } else {
       this.fieldData.textArr.push({label:'Paragraph Text', desc:'Type Description Text here...', paraId:this.utilityService.getUniqueElementId()});
     }
     this.updateRowNumber();
   }
   /*
    * Remove the options row
    */
   removeOverrideRow(index:number) {
     this.fieldData.textArr_override.splice(index,1);
     this.updateRowNumberOverride();
     this.updateParaId();
   }
   /*
    * Add the options row
    */
    addOverrideRow() {
      if(this.fieldData.rowNumber_override !== 0 && this.fieldData.rowNumber_override <= this.fieldData.textArr_override.length) {
        this.fieldData.textArr_override.splice((this.fieldData.rowNumber_override - 1), 0,
        {label:'', desc:'', paraId:this.utilityService.getUniqueElementId()});
      } else {
        this.fieldData.textArr_override.push({label:'', desc:'', paraId:this.utilityService.getUniqueElementId()});
      }
      this.updateRowNumberOverride();
    }

    updateRowNumberOverride() {
      if(this.fieldData.hasOwnProperty('textArr_override')) {
        this.fieldData.rowNumber_override = this.fieldData.textArr_override.length + 1;
      }
    }

  onUpdateEditor():void {
    /*
    const tinymceEditorId = $('.droppedItem.selected').find('.tinyMceEditor').attr('id');
    if(tinymceEditorId) {
      //tinymce.get(tinymceEditorId).setContent(this.fieldData.labelText);
    }
    */
  }
}
