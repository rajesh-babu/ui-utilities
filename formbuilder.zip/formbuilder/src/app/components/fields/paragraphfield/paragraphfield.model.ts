declare var $:any;
export class ParagraphFieldModel {
  public id:string;
  public name:string;
  public name_override:string;
  public indexPos: number;
  public labelText:string = '<p>Paragraph Text</p>';
  public labelText_override:string = '';
  public cssClass:string;
  public token:string;
  public componentName:string = 'Paragraph';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public hidefield:boolean;
  public hidefield_override:boolean;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public rowNumber:number;
  public rowNumber_override:number;
  public paraType:string = 'simple';
  public helpTextBGColor:string = 'white';
  public textArr:Array<Object> = [{label:'Paragraph Text', desc:'Type Description Text here...'}];
  public textArr_override:Array<Object> = [{label:'', desc:''}];
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class ParagraphFieldModelVars {
  public ID:string = 'id';
  public NAME:string = 'name';
  public INDEXPOS:string = 'indexPos';
  public LABELTEXT:string = 'labelText';
  public CSSCLASS:string = 'cssClass';
}
