import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ParagraphfieldComponent} from './paragraphfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    ParagraphfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  ParagraphfieldComponent ],
})
export class ParagraphFieldModule { }
