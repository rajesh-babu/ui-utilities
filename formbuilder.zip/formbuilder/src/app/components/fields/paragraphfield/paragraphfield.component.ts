import { Component, AfterViewInit, OnInit, OnChanges  } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { ParagraphFieldModel, ParagraphFieldModelVars } from './paragraphfield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'paragraph-field',
  templateUrl:'./paragraphfield.component.html'
})

export class ParagraphfieldComponent implements AfterViewInit, OnInit, OnChanges {
  public paragraphFieldModel:ParagraphFieldModel = new ParagraphFieldModel();
  public paragraphFieldModelVars:ParagraphFieldModelVars = new ParagraphFieldModelVars();
  currentSelectedIndexPos:number;
  paraId:string;
  public className:string;

  constructor(public asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService) {
    this.paragraphFieldModel['type'] = this.constants.PARAGRAPH_FIELD;
    this.paragraphFieldModel['refId'] = utilityService.timeasRefId();
    this.paragraphFieldModel['textArr'][0]['paraId'] = utilityService.timeasRefId();
    this.paragraphFieldModel['textArr_override'][0]['paraId'] = utilityService.timeasRefId();

  }

 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.paragraphFieldModel = _data;
    }
    if(!isReLoadFields) { this.globalService.addappData(this.paragraphFieldModel, _index); }
  }
  /*
   * This will be triggered upon dropping the component in multi column
   */
  public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
    if(_data) { // If existing data
      this.paragraphFieldModel = _data;
    }
    this.paragraphFieldModel['colIndex'] = _colIndex;

    if(typeof(grpRowIndex) !== 'undefined') {
      this.paragraphFieldModel['grpRowIndex'] = grpRowIndex;
    }

    // If Multi column inside the secContainer, dont set the Data to AppData
    if(!isSecContainer) {
      this.globalService.addappData(this.paragraphFieldModel, _index, true, isGroupField);
    }
  }
  /*
   * This will be triggered upon dropping the component in Group field
   */
  public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.paragraphFieldModel = _data;
    }
    this.paragraphFieldModel['grpRowIndex'] = _grpRowIndex;
    this.paragraphFieldModel['indexPos'] = _index;

    if(!isReLoadFields) { this.globalService.addappData(this.paragraphFieldModel, _index, false, true); }
  }

  ngOnInit() {
    this.paraId = 'para_' + this.utilityService.getUniqueElementId();
  }
  ngOnChanges() {
    this.paraId = 'para_' + this.utilityService.getUniqueElementId();
  }

  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {
    // set the Aside component if it has class "selected"

    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.PARAGRAPH_FIELD, data:this.paragraphFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {

    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
      this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.PARAGRAPH_FIELD, data:this.paragraphFieldModel, indexPos:this.currentSelectedIndexPos, isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }
}
