import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DividerComponent} from './divider-field.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    FormsModule,
    CustomCommonsModule
  ],
  declarations: [
    DividerComponent
  ],
  providers: [AsideService],
  entryComponents: [  DividerComponent ],
})
export class DividerModule { }
