declare var $:any;
export class DividerModel {
  indexPos: number;
  public componentName:string = 'Divider';
  public marginBottom:string = 'mblg';
  public isConditional:boolean = false;
  public type:string;
  public pgTopIndex:number;
  public name:string;
  public name_override:string;
  public widthType = '';
  public hidefield:boolean;
  public hidefield_override:string;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
