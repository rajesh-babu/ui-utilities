import { Component, Input, OnInit } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { DividerModel } from '../divider-field.model';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-divider-field',
  templateUrl: './aside-divider-field.component.html'
})
export class AsideDividerComponent {
  @Input() fieldData:DividerModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  dividerFieldFormGrp:any;

  public constructor( public asideService: AsideService, private commonsFieldsService: CommonsFieldsService,
                      private formBuilder: FormBuilder, public constants: Constants, public globalService: GlobalService) {
                        this.dividerFieldFormGrp = this.formBuilder.group({
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ ValidationService.attributeValidator]],
                              'marginBottom':['',[]],
                              'widthType':['',[]],
                              'hidefield':['',[]],
                              'hidefield_override': ['',[]]
                           });
                      }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.DIVIDER,
      values:Object.assign(new DividerModel(), this.fieldData), indexPos:this.indexPos});
  }
}
