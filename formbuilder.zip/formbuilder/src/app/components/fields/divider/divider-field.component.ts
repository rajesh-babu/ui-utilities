import { Component, AfterViewInit } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { DividerModel } from './divider-field.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'divider-field',
  templateUrl:'./divider-field.component.html'
})

export class DividerComponent implements AfterViewInit {
  public dividerModel:DividerModel = new DividerModel();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(private asideService:AsideService, public utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService) {
        this.dividerModel['type'] = this.constants.DIVIDER;
  }

 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.dividerModel = _data;
    }
    if(!isReLoadFields) { this.globalService.addappData(this.dividerModel, _index); }
  }

  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.DIVIDER, data:this.dividerModel, indexPos:_indexPos, isToggle:false});
    }
  }
  itemClicked(e:Event) {
   const $currentEle = $(e.currentTarget),
     $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
   this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
   const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

   // Change the selected value to opened Aside
   const obj:any = {type:this.constants.DIVIDER, data:this.dividerModel,
     indexPos:this.currentSelectedIndexPos, isToggle:false};
   obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
   this.asideService.openAside(obj);

   // remove class "select" to all existing elements except currently selected
   $ele.removeClass(this.constants.SELECTED);
   $currentEle.addClass(this.constants.SELECTED);
 }

}
