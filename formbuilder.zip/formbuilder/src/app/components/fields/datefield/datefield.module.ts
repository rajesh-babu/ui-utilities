import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatefieldComponent} from './datefield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { CalendarModule } from 'primeng/primeng';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    FormsModule,
    CalendarModule
  ],
  declarations: [
    DatefieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  DatefieldComponent ]
})
export class DateFieldModule { }
