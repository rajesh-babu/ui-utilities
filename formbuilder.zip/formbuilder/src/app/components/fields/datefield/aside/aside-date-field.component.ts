import { Component, Input } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { DateFieldModel } from '../datefield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-date-field',
  templateUrl: './aside-date-field.component.html'
})
export class AsideDateFieldComponent {
  @Input() fieldData:DateFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  dateFieldFormGrp:any;
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.dateFieldFormGrp = this.formBuilder.group({
                              'id':['',[ValidationService.attributeValidator]],
                              'reviewLabelText':['',[]],
                              'udLabelText':['',[]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'token':['',[]],
                              'selectedValidation':['',[]],
                              'errmsg':['',[]],
                              'required':'',
                              'size':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'placeHolder':['',[]],
                              'dateFormat':['',[]],
                              'defaultDateDD':['',[]],
                              'defaultDate':['',[]],
                              'disabled':['',[]],
                              'hidefield':['',[]],
                              'fieldStyle':['',[]],
                              'hidefield_override': ['',[]]
                           });
                      }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField(
      {field:this.constants.DATE_FIELD, values:Object.assign(new DateFieldModel(), this.fieldData), indexPos:this.indexPos});
  }

  onDefaultDateDropDownChange(value:String) {
    console.log(this.fieldData.defaultDate);
    if(value === 'current') {
      this.fieldData.defaultDate = new Date();
    } else {
      this.fieldData.defaultDate = null;
    }
  }

}
