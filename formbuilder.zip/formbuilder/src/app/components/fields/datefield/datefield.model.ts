declare var $:any;
export class DateFieldModel {
  public id:string;
  public name:string;
  public name_override:string;
  public indexPos: number;
  public labelText:string = 'Label Text';
  public udLabelText:string;
  public reviewLabelText:string;
  public required: boolean = true;
  public placeHolder:string;
  public disabled: boolean = false;
  public cssClass:string;
  public token:string;
  public dateFormat:string = 'mm-dd-yyyy';
  public defaultDateDD:string = 'none';
  public defaultDate:Date;
  public componentName:string = 'Date';
  public selectedValidation:string = 'pleaseSelect';
  public isConditional:boolean = false;
  public type:string;
  public adaAttrs:string;
  public refId:number;
  public size:number;
  public hidefield:boolean;
  public hidefield_override:string;
  public pgTopIndex:number;
  public errmsg:string;
  public grpRowIndex:number;
  public fieldStyle:string = 'type_1';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class DateFieldModelVars {
  public ID:string = 'id';
  public NAME:string = 'name';
  public INDEXPOS:string = 'indexPos';
  public LABELTEXT:string = 'labelText';
  public TYPEALABEL:string = 'Type a subLabel';
  public DEF_LAB_TXT:String = 'Type a Label Text';
  public REQUIRED:string = 'required';
  public DISABLED:string = 'disabled';
  public CSSCLASS:string = 'cssClass';
  public DEFAULTDATEDD:string = 'defaultDateDD';
  public DEFAULTDATE:string = 'defaultDate';
}
