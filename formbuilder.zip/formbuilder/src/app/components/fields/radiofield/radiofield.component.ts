import { Component, AfterViewInit } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import {  RadioFieldModel, RadioFieldModelVars } from './radiofield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'radio-field',
  templateUrl: './radiofield.component.html'
})
export class RadiofieldComponent implements AfterViewInit {
  public radioFieldModel:RadioFieldModel = new RadioFieldModel();
  public radioFieldModelVars:RadioFieldModelVars = new RadioFieldModelVars();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(public asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService) {
      this.radioFieldModel['type'] = this.constants.RADIO_FIELD;
      this.radioFieldModel['refId'] = utilityService.timeasRefId();
  }

  /*
   * This will be triggered upon loading the form and pre populating
   */
   public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.radioFieldModel = _data;
     } else {
       // For Grid table, generated 3 types of refId for manging the conditional logic datas
       for(let i=0;i<this.radioFieldModel['options'].length;i++) {
         const thatRef = this;
         setTimeout(function(){thatRef.radioFieldModel['options'][i]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
       }
     }
     this.radioFieldModel['type'] = this.constants.RADIO_FIELD;
     if(!isReLoadFields) { this.globalService.addappData(this.radioFieldModel, _index); }
   }
   /*
    * This will be triggered upon dropping the component in multi column
    */
   public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
     if(_data) { // If existing data
       this.radioFieldModel = _data;
     }
     this.radioFieldModel['colIndex'] = _colIndex;

     if(typeof(grpRowIndex) !== 'undefined') {
       this.radioFieldModel['grpRowIndex'] = grpRowIndex;
     }

     // If Multi column inside the secContainer, dont set the Data to AppData
     if(!isSecContainer) {
       this.globalService.addappData(this.radioFieldModel, _index, true, isGroupField);
     }
   }
   /*
    * This will be triggered upon dropping the component in Group field
    */
   public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.radioFieldModel = _data;
     } else {
       if(!isReLoadFields) {
         // For button, each button has refId for manging the conditional logic datas
         for(let i=0;i<this.radioFieldModel['options'].length;i++) {
           const thatRef = this;
           setTimeout(function(){thatRef.radioFieldModel['options'][i]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
         }
       }
     }
     this.radioFieldModel['grpRowIndex'] = _grpRowIndex;
     this.radioFieldModel['indexPos'] = _index;

     if(!isReLoadFields) { this.globalService.addappData(this.radioFieldModel, _index, false, true); }
   }
  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.RADIO_FIELD, data:this.radioFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
    this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.RADIO_FIELD,
      data:this.radioFieldModel,
      indexPos:this.currentSelectedIndexPos,
      isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }

}
