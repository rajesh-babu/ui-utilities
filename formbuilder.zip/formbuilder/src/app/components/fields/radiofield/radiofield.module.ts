import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RadiofieldComponent} from './radiofield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    RadiofieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  RadiofieldComponent ]
})
export class RadioFieldModule { }
