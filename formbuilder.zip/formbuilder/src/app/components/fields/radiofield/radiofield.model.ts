declare var $:any;
export class RadioFieldModel {
  indexPos: number;
  labelText:string = 'Label Text';
  reviewLabelText:string;
  udLabelText:string;
  required: boolean = false;
  id:string;
  name:string;
  name_override:string;
  cssClass:string;
  token:string;
  disabled:boolean = false;
  options:Array<Object> = [{label:'option 1', value: 'value 1', selected:false, optionRefId:''}, {label:'option 2', value: 'value 2', selected:false, optionRefId:''}];
  selectedIndex:number;
  dataSourceReference:string;
  rowNumber:number;
  helpText:string;
  hidefield:boolean;
  hidefield_override:boolean;
  adaAttrs:string;
  alignment:string;
  displayType:string = 'smallBox';
  public componentName:string = 'Radio';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public fieldStyle:string = 'type_1';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class RadioFieldModelVars {
  public DEF_LAB_TXT:String = 'Type a Label Text';
}
