import { Component, AfterViewInit } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { TextFieldModel, TextFieldModelVars } from './textfield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'text-field',
  templateUrl:'./textfield.component.html'
})

export class TextfieldComponent implements AfterViewInit {
  public textFieldModel:TextFieldModel = new TextFieldModel();
  public textFieldModelVars:TextFieldModelVars = new TextFieldModelVars();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(private asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService) {
    this.textFieldModel['type'] = this.constants.TXT_FIELD;
    this.textFieldModel['refId'] = utilityService.timeasRefId();
  }

 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.textFieldModel = _data;
    }
    if(!isReLoadFields) { this.globalService.addappData(this.textFieldModel, _index); }
  }
  /*
   * This will be triggered upon dropping the component in multi column
   */
  public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
    if(_data) { // If existing data
      this.textFieldModel = _data;
    }
    this.textFieldModel['colIndex'] = _colIndex;

    if(typeof(grpRowIndex) !== 'undefined') {
      this.textFieldModel['grpRowIndex'] = grpRowIndex;
    }

    // If Multi column inside the secContainer, dont set the Data to AppData
    if(!isSecContainer) {
      this.globalService.addappData(this.textFieldModel, _index, true, isGroupField);
    }
  }
  /*
   * This will be triggered upon dropping the component in Group field
   */
  public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.textFieldModel = _data;
    }
    this.textFieldModel['grpRowIndex'] = _grpRowIndex;
    this.textFieldModel['indexPos'] = _index;

    if(!isReLoadFields) { this.globalService.addappData(this.textFieldModel, _index, false, true); }
  }

  /*
   *This will be triggered if it has subType
   */
  public setSubType(_subtype: string, _index:number) {
    this.textFieldModel['type'] = this.constants.TXT_AREA_FIELD;
  }

  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.TXT_FIELD, data:this.textFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
    this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.TXT_FIELD, data:this.textFieldModel,
      indexPos:this.currentSelectedIndexPos, isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }

}
