import { Component, Input } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { GlobalService} from '../../../../services/GlobalService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { UtilityService } from '../../../../services/UtilityService';
import { TextFieldModel, TextFieldModelVars } from '../textfield.model';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-text-field',
  templateUrl: './aside-text-field.component.html'
})

export class AsideTextFieldComponent {
  @Input() fieldData:TextFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  textFieldFormGrp:any;

  public textFieldModelVars:TextFieldModelVars = new TextFieldModelVars();

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder,
                      public globalService:GlobalService, public utilityService:UtilityService) {
        this.textFieldFormGrp = this.formBuilder.group({
              'labelText':['',[]],
              'reviewLabelText':['',[]],
              'udLabelText':['',[]],
              'id':['',[ValidationService.attributeValidator]],
              'name': ['', [Validators.required, ValidationService.attributeValidator]],
              'name_override': ['', [ ValidationService.attributeValidator]],
              'cssClass':['',[]],
              'defaultText':['',[]],
              'defaultText_override':['',[]],
              'token':['',[]],
              'required':'',
              'lines':['',[]],
              'size':['',[]],
              'selectedValidation':['',[]],
              'errmsg':['',[]],
              'maxChars':['',[]],
              'minChars':['',[]],
              'maxVal':['',[]],
              'minVal':['',[]],
              'helpText':['',[]],
              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
              'placeHolder':['',[]],
              'disabled':['',[]],
              'hidefield':['',[]],
              'hidefield_override':['',[]],
              'hiddenfield':['',[]],
              'dataSourceReference':['',[]],
              'filterConditions':['',[]],
              'fieldStyle':['',[]],
              'iconType':['',[]],
           });
  }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.TXT_FIELD,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }
  /*
   * Upon changing the Datasource Reference or Filter condition, generate the script string accordingly
   */
  dataSrcFilterChange() {
    if(this.fieldData.dataSourceReference) {
      const randomNo = Math.floor(Math.random() * 1000) + 1;
      this.fieldData.dataSourceScriptStr =  this.utilityService.genearteJSPreviewMode(this.fieldData.dataSourceReference, this.fieldData.filterConditions, randomNo);
      const drArr = this.fieldData.dataSourceReference.split('.');
      this.fieldData.dataSourceReferenceVar = drArr.join('') + randomNo;
    }
  }
}
