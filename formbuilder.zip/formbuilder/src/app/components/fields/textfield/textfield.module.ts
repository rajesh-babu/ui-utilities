import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TextfieldComponent} from './textfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    TextfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  TextfieldComponent ],
})
export class TextFieldModule { }
