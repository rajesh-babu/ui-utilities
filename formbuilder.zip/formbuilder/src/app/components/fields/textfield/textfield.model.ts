declare var $:any;
export class TextFieldModel {
  public id:string;
  public name:string;
  public name_override:string;
  public cssClass:string;
  public token:string;
  public indexPos: number;
  public labelText:string = 'Label Text';
  public reviewLabelText:string;
  public udLabelText:string;
  public defaultText:string;
  public defaultText_override:string;
  public required: boolean = true;
  public placeHolder:string;
  public selectedValidation:string = 'pleaseSelect';
  public hidefield:boolean;
  public hidefield_override:boolean;
  public hiddenfield:boolean;
  public disabled:boolean;
  public lines:number;
  public size:number;
  public maxChars:number;
  public minChars:number;
  public maxVal:number;
  public minVal:number;
  public helpText:string;
  public adaAttrs:string;
  public componentName:string = 'Text Field';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public iconType:string = '';
  public dataSourceReference:string;
  public filterConditions:string;
  public dataSourceReferenceVar:string;
  public dataSourceScriptStr:string;
  public fieldStyle:string = 'type_1';
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class TextFieldModelVars {
  public ID:string = 'id';
  public NAME:string = 'name';
  public INDEXPOS:string = 'indexPos';
  public DEF_LAB_TXT:String = 'Type a Label Text';
  public LABELTEXT:string = 'labelText';
  public TYPEALABEL:string = 'Type a subLabel';
  public REQUIRED:string = 'required';
  public PLACEHOLDER:string = 'placeHolder';
}
