import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { GridTablefieldComponent} from './gridtablefield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    GridTablefieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  GridTablefieldComponent ]
})
export class GridTableFieldModule {}
