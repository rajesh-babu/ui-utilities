import { Component, Input, OnInit } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { GridTableFieldModel, GridTableColumns } from '../gridtablefield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { GlobalService} from '../../../../services/GlobalService';
import { Constants} from '../../../../services/Constants';
import { UtilityService} from '../../../../services/UtilityService';
import { FormsModule } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
declare var $:any;

@Component({
  selector: 'aside-gridtable-field',
  templateUrl: './aside-gridtable-field.component.html'
})
export class AsideGridTableFieldComponent implements OnInit  {
  @Input() fieldData:GridTableFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  disbleOption:boolean = false;
  optionValidation:boolean = false;
  optionDuplicateCount:number;
  nameValidArray:Array<any> = [ValidationService.customRequiredVal,ValidationService.attributeVal];
  name_overrideValidArray:Array<any> = [ValidationService.attributeVal];
  retTableValidArr:Array<any> = [ValidationService.customRequiredVal,ValidationService.attributeVal];
  retTable_overrideValidArr:Array<any> = [ValidationService.attributeVal];
  adaValidArray:Array<any> = [ValidationService.adaAttributesVal];
  otherValidArray:Array<any> = [ValidationService.attributeVal];
  gridTableColumns:GridTableColumns = new GridTableColumns();
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService, public globalService:GlobalService,
                      private utilityService:UtilityService) {}
  /*
   * This will duplicate the field
   */

  duplicateField() {
    this.commonsFieldsService.duplicateField({
      field:this.constants.GRIDTABLE_FIELD, values:JSON.parse(JSON.stringify(this.fieldData)),
      indexPos:this.indexPos
    });
  }
  /*
   * This will be triggered upon slecting the 'table' tab
   */
  onTableTabSelect() {
    // this.asideService.initAccordion(0);
  }

  /*
   * Remove the options row
   */
  removeRow(evt:Event, index:number, obj:any) {
    const _this = this;
    const result1 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdName);
    const result2 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdRadioName);
    const result3 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdTextName);
    if(result1 || result2 || result3) {
      this.commonsFieldsService.onConditionalAssoError({titleText:"Unable to Delete!",
        mainContent:"The Row content's Textbox or Radio is used in conditional logic under settings tab. Please remove the same if you need to change the Row content."});
      evt.stopImmediatePropagation();
    }else {
      this.fieldData.columns.splice(index,1);
      setTimeout(function(){
        _this.asideService.initAccordion(0);
     }, 200);
    }
    this.updateRowNumber();
  }
  /*
   * On Removing the Radio options
   */
  removeRadioOption(obj:any, index:number) {
    if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId','optionRefId'],obj.radioOptions[index]['optionRefId'])) {
      this.commonsFieldsService.onConditionalAssoError({titleText:"Unable to Delete!",
        mainContent:"Option is used in conditional logic under settings tab. Please remove the same if you need to change."});
    } else {
      obj.radioOptions.splice(index,1);
      if(obj.selectedIndex === index) {
        delete obj.selectedIndex;
      }
      this.updateRowNumber();
    }
  }
  /*
   * Add the options row
   */
   addColumn() {
     const _this = this;

     const colCount:any = this.fieldData.columns.length+1;

     this.gridTableColumns = {colTitle: 'Column '+colCount, colTitleDef: 'Column '+colCount, colClass: null,
     customColClass: null, rowField: 'text', radioInlineAlignment: true, selectedIndex :null,rowNumber :null,
     radioOptions: [{label: 'Option 1', value: 'value 1',selected: false, optionRefId: this.utilityService.timeasRefId},
     {label: 'Option 2', value: 'value 2',selected: false, optionRefId: this.utilityService.timeasRefId}],
     rowFieldConf:{ labelText: null, name: null, id: null, cssClass: null, customCssClass: null, validation: null, minChars: null,
        textfieldHide: true, maxChars: null, placeholder: null, token: null,  refIdName:this.utilityService.timeasRefId()}};

     this.fieldData.columns.push(this.gridTableColumns);
     setTimeout(function(){
      _this.asideService.initAccordion(_this.fieldData.columns.length - 1);
    }, 200);
    this.updateRowNumber();
   }

   getMinRows() {
      return this.fieldData.minRows;
   }

   ngOnInit() {
     this.updateRowNumber();
   }

   updateRowNumber() {
     // this.fieldData.rowNumber = this.fieldData.options.length + 1;
     if(this.fieldData.hasOwnProperty('columns')) {
       for(let i=0;i<this.fieldData.columns.length;i++) {
         if(this.fieldData.columns[i].hasOwnProperty('radioOptions')) {
           this.fieldData.columns[i].rowNumber = this.fieldData.columns[i].radioOptions.length + 1;
         }
       }
     }
   }

   checkSingle(colIndex:any, optionIindex:any) {
     this.fieldData.columns[colIndex].selectedIndex = -1;
     for(let i=0; i<this.fieldData.columns[colIndex].radioOptions.length; i++) {
       if(i === optionIindex) {
         if(this.fieldData.columns[colIndex].radioOptions[i]['selected'] === true) {
           this.fieldData.columns[colIndex].radioOptions[i]['selected'] = false;
         } else {
           this.fieldData.columns[colIndex].radioOptions[i]['selected'] = true;
           this.fieldData.columns[colIndex].selectedIndex = i;
         }
       } else {
         this.fieldData.columns[colIndex].radioOptions[i]['selected'] = false;
       }
     }
   }

   /*
    * Add the options row for Radio
    */
   addRadioOptionRow(target, index) {
     if(index !== 0 && index <= target.length) {
       target.splice((index - 1), 0,{label:'Option ' + (Number(target.length)+1), value:'value ' +  (Number(target.length)+1), selected:false, optionRefId: this.utilityService.timeasRefId});
     } else {
       target.push({label:'Option ' + (Number(target.length)+1), value:'value ' +  (Number(target.length)+1), selected:false, optionRefId: this.utilityService.timeasRefId});
     }
     this.updateRowNumber();
   }

   checkOptionsDuplicate(thisObj:any, options:any) {
     $(thisObj).parent('ol.sortable-options').find('li').removeClass('has-error');
     this.optionDuplicateCount = (<any>options).filter((opt, index, self) =>
       self.findIndex(o => o.value === opt.value) !== index).length;
     if(this.optionDuplicateCount) {
         this.optionValidation = true;
         $(thisObj).addClass('has-error');
     }else {
       this.optionValidation = false;
     }
   }
   /*
    * On clicking the Row Content Drop down, Check current Textbox or Radio is associated with conditional data, if so dont allow user to change the drop down
    */
   public rowContentMousedown(evt:Event, obj:any) {
     const result1 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdName);
     const result2 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdRadioName);
     const result3 = this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages, ['ifRefId','refId'],obj.rowFieldConf.refIdTextName);
     if(result1 || result2 || result3) {
       evt.preventDefault();
       this.commonsFieldsService.onConditionalAssoError({titleText:"Unable to Change the Row Content!",
         mainContent:"The Row content's Textbox or Radio is used in conditional logic under settings tab. Please remove the same if you need to change the Row content."});
     }
   }
   /*
    * This will be triggered Upon entering the Min or Max selection.
    */
   minMaxChange() {

     // Reset to '0' if no value
     this.fieldData.minSelection = (this.fieldData.minSelection) ? this.fieldData.minSelection: 0;
     this.fieldData.maxSelection = (this.fieldData.maxSelection) ? this.fieldData.maxSelection: 0;


     // Check min and max range and copy to min to max if max is lesser than min
     if(this.fieldData.maxSelection) {
       this.fieldData.maxSelection = (this.fieldData.minSelection > this.fieldData.maxSelection) ? this.fieldData.minSelection: this.fieldData.maxSelection;
     }else {
       this.fieldData.maxSelection = 0;
     }
     if(this.fieldData.maxSelection_override) {
       this.fieldData.maxSelection_override = (this.fieldData.minSelection_override > this.fieldData.maxSelection_override) ?
            this.fieldData.minSelection_override: this.fieldData.maxSelection_override;
     }

   }
   /*
    * Upon changing Filter condition, generate the script string accordingly
    */
   onFiltersChange() {
      let fieldName:string = '';
      if(this.fieldData.name ) {
        fieldName = 'plansTable_' + this.fieldData.name;
      }

       this.fieldData.plansScriptStr =  this.utilityService.geneartePlansJSPreviewMode( this.fieldData.filterConditions, fieldName);
       this.fieldData.plansTableReferenceVar =  fieldName;
     }
}
