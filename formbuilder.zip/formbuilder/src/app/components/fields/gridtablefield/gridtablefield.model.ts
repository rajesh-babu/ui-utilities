 declare var $:any;
export class GridTableFieldModel {
  indexPos: number;
  id:string;
  reviewLabelText:string;
  udLabelText:string;
  name:string;
  name_override:string;
  cssClass:string;
  helpText:string;
  labelText:string;
  adaAttrs:string;
  minRows:number = 1;
  maxRows:number;

  tableRowAutoNumbering:Boolean = false;
  componentName:string = 'Grid Table';
  noOfRowValidation:number;
  hidefield:boolean;
  hidefield_override:boolean;
  hidemf:boolean;
  hidemf_override:boolean;
  hidebrok:boolean;
  hidebrok_override:boolean;
  disabled:boolean;
  public type:string;
  public isConditional:boolean = false;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public tableType:string = 'Default';

  // For "Plans Table"
  public plansScriptStr:string;
  public filterConditions:string;
  public plansTableReferenceVar:string;
  minSelection:number = 0; // For Plans table's Contract selection
  maxSelection:number = 0;
  minSelection_override:number;
  maxSelection_override:number;
  public itdNumber:string;
  public itdNumber_override:string;

  // For Plans Table Balance
  populatePlanLoanNumberBalance:boolean = false;
  loanNumberPlanNameDropdownName:string = '';
  loanNumberPlanNameDropdownName_override:string = '';

  columns: GridTableColumns[] = [
    {
      colTitle: 'Account No.', colTitleDef: 'Account No.', colClass: null, customColClass: null, rowField: 'text', radioInlineAlignment: true, selectedIndex :null,rowNumber :null,
      radioOptions: [{label: 'Option 1', value: 'value 1',selected: false, optionRefId: ''},{label: 'Option 2', value: 'value 2',selected: false, optionRefId: ''}],
      rowFieldConf:{ labelText: null, name: null, id: null, cssClass: null, customCssClass: null, validation: null, minChars: null,
         textfieldHide: true, maxChars: null, placeholder: null, token: null, refIdName:null}
    },
    {
      colTitle: 'Percent', colTitleDef: 'Percent', colClass: null, customColClass: null, rowField: 'text', radioInlineAlignment: true, selectedIndex :null,rowNumber :null,
      radioOptions: [{label: 'Option 1', value: 'value 1',selected: false, optionRefId: ''},{label: 'Option 2', value: 'value 2',selected: false, optionRefId: ''}],
      rowFieldConf:{ labelText: null, name: null, id: null, cssClass: 'inputPct', customCssClass: null, validation: null, minChars: null,
         textfieldHide: true, maxChars: null, placeholder: null, token: null, refIdName:null }
    },
    {
      colTitle: '-or-', colTitleDef: '-or-', colClass: 'txtc', customColClass: null, rowField: 'label', radioInlineAlignment: true, selectedIndex :null,rowNumber :null,
      radioOptions: [{label: 'Option 1', value: 'value 1',selected: false, optionRefId: ''},{label: 'Option 2', value: 'value 2',selected: false, optionRefId: ''}], rowFieldConf:
        { labelText: 'or', name: null, id: null, cssClass: 'shd2 txtc', customCssClass: null, validation: null, minChars: null,
         textfieldHide: true, maxChars: null, placeholder: null, token: null, refIdName:null }
    },
    {
      colTitle: 'Amount', colTitleDef: 'Amount', colClass: null, customColClass: null, rowField: 'text', radioInlineAlignment: true, selectedIndex :null,rowNumber :null,
      radioOptions: [{label: 'Option 1', value: 'value 1',selected: false, optionRefId: ''},{label: 'Option 2', value: 'value 2',selected: false, optionRefId: ''}],
      rowFieldConf:  { labelText: null, name: null, id: null, cssClass: 'inputAmt', customCssClass: null, validation: null, minChars: null,
         textfieldHide: true, maxChars: null, placeholder: null, token: null, refIdName:null }
    }
  ];

  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class GridTableColumns {
    colTitle: string;
    colTitleDef: string;
    colClass: string;
    customColClass: string;
    rowField: string;
    radioOptions:Array<any>;
    radioInlineAlignment:boolean = true;
    selectedIndex:number;
    rowNumber:number;
    rowFieldConf: {
      labelText: string,
      name: string,
      id: string,
      cssClass: string,
      customCssClass: string,
      validation: string,
      minChars: number,
      maxChars: number,
      placeholder: string,
      token: string,
      textfieldHide:boolean,
      refIdName:number

    };
}

export class GridTableFieldModelVars {
  public DEF_LAB_TXT:String = 'Type a Label Text';
}
