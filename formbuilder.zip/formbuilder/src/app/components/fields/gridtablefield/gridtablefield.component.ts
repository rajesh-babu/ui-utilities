import { Component, AfterViewInit, ChangeDetectorRef } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import {  GridTableFieldModel, GridTableFieldModelVars } from './gridtablefield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'gridtable-field',
  templateUrl: './gridtablefield.component.html'
})
export class GridTablefieldComponent implements AfterViewInit {
  public gridtableFieldModel:GridTableFieldModel = new GridTableFieldModel();
  public gridtableFieldModelVars:GridTableFieldModelVars = new GridTableFieldModelVars();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(public asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService, private cdRef:ChangeDetectorRef) {
      this.gridtableFieldModel['type'] = this.constants.GRIDTABLE_FIELD;
      this.gridtableFieldModel['refId'] = utilityService.timeasRefId();
      this.asideService.updateView$.subscribe(() => {
        this.cdRef.detectChanges();
       });
  }

  /*
   * This will be triggered upon loading the form and pre populating
   */
   public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.gridtableFieldModel = _data;
     }else {
       // For Grid table, generated 3 types of refId for manging the conditional logic datas
       for(let i=0;i<this.gridtableFieldModel.columns.length;i++) {
         const thatRef = this;
         setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdName'] = thatRef.utilityService.timeasRefId(); }, 10);
         setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdRadioName'] = thatRef.utilityService.timeasRefId(); }, 10);
         setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdTextName'] = thatRef.utilityService.timeasRefId(); }, 10);
         for(let j=0;j<thatRef.gridtableFieldModel.columns[i]['radioOptions'].length;j++) {
           setTimeout(function(){thatRef.gridtableFieldModel.columns[i]['radioOptions'][j]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
         }
       }

       /*for(let i=0;i<this.radioFieldModel['options'].length;i++) {
         const thatRef = this;
         setTimeout(function(){thatRef.radioFieldModel['options'][i]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
       }*/
     }
     this.gridtableFieldModel.columns = this.globalService.removeJSON_null_properties(this.gridtableFieldModel.columns);
     this.gridtableFieldModel['type'] = this.constants.GRIDTABLE_FIELD;
     if(!isReLoadFields) { this.globalService.addappData(this.gridtableFieldModel, _index); }
   }
   /*
    * This will be triggered upon dropping the component in multi column
    */
   public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
     if(_data) { // If existing data
       this.gridtableFieldModel = _data;
     }
     this.gridtableFieldModel['colIndex'] = _colIndex;

     if(typeof(grpRowIndex) !== 'undefined') {
       this.gridtableFieldModel['grpRowIndex'] = grpRowIndex;
     }

     // If Multi column inside the secContainer, dont set the Data to AppData
     if(!isSecContainer) {
       this.globalService.addappData(this.gridtableFieldModel, _index, true, isGroupField);
     }
   }
   /*
    * This will be triggered upon dropping the component in Group field
    */
   public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.gridtableFieldModel = _data;
     } else {
       if(!isReLoadFields) {
         // For Grid table, generated 3 types of refId for manging the conditional logic datas
         for(let i=0;i<this.gridtableFieldModel.columns.length;i++) {
           const thatRef = this;
           setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdName'] = thatRef.utilityService.timeasRefId(); }, 10);
           setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdRadioName'] = thatRef.utilityService.timeasRefId(); }, 10);
           setTimeout(function(){ thatRef.gridtableFieldModel.columns[i].rowFieldConf['refIdTextName'] = thatRef.utilityService.timeasRefId(); }, 10);
           for(let j=0;j<thatRef.gridtableFieldModel.columns[i]['radioOptions'].length;j++) {
             setTimeout(function(){thatRef.gridtableFieldModel.columns[i]['radioOptions'][j]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
           }
         }
         this.gridtableFieldModel.columns = this.globalService.removeJSON_null_properties(this.gridtableFieldModel.columns);
       }
     }
     this.gridtableFieldModel['grpRowIndex'] = _grpRowIndex;
     this.gridtableFieldModel['indexPos'] = _index;

     if(!isReLoadFields) { this.globalService.addappData(this.gridtableFieldModel, _index, false, true); }
   }
  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {
    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside(
        {type:this.constants.GRIDTABLE_FIELD, data:this.gridtableFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
    this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.GRIDTABLE_FIELD,
      data:this.gridtableFieldModel,
      indexPos:this.currentSelectedIndexPos,
      isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }

  getNoOfRows() {
    return Array(this.gridtableFieldModel.minRows);
  }

}
