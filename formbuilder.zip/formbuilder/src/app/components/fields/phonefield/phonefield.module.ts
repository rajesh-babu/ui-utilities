import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { PhonefieldComponent} from './phonefield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    PhonefieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  PhonefieldComponent ],
})
export class PhoneFieldModule { }
