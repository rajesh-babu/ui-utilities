import { Component, Input, OnInit } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { GlobalService} from '../../../../services/GlobalService';
import { Constants} from '../../../../services/Constants';
import { PhoneFieldModel, PhoneFieldModelVars } from '../phonefield.model';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-phone-field',
  templateUrl: './aside-phone-field.component.html'
})
export class AsidePhoneFieldComponent {
  @Input() fieldData:PhoneFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  phoneFieldFormGrp:any;
  public phoneFieldModelVars:PhoneFieldModelVars = new PhoneFieldModelVars();

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.phoneFieldFormGrp = this.formBuilder.group({
                              'labelText':['',[]],
                              'reviewLabelText':['',[]],
                              'udLabelText':['',[]],
                              'id':['',[ValidationService.attributeValidator]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'size':['',[]],
                              'token':['',[]],
                              'required':'',
                              'phoneType':'',
                              'errmsg':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'placeHolder':['',[]],
                              'disabled':['',[]],
                              'hidefield':['',[]],
                              'hidefield_override':['',[]],
                              'fieldStyle':['',[]],
                              'prefCnt':['',[]],
                              'defCnt':['',[]]
                           });
                      }
  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField({field:this.constants.PHONE_FIELD,
      values:JSON.parse(JSON.stringify(this.fieldData)), indexPos:this.indexPos});
  }
}
