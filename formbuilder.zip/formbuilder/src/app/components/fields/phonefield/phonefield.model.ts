declare var $:any;
export class PhoneFieldModel {
  public id:string;
  public name:string;
  public name_override:string;
  public cssClass:string;
  public size:any;
  public indexPos: number;
  public labelText:string = 'Phone Label Text';
  public udLabelText:string;
  public reviewLabelText:string;
  public showExtension: boolean = false;
  public required: boolean = true;
  public placeHolder:string;
  public disabled:boolean;
  public hidefield:boolean;
  public hidefield_override:boolean;
  public token:string;
  public adaAttrs:string;
  public componentName:string = 'Phone';
  public isConditional:boolean = false;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  public prefCnt:Array<Object>;
  public defCnt:string = 'us';
  public fieldStyle:string = 'type_1';
  public phoneType:boolean = false;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
export class PhoneFieldModelVars {
  public ID:string = 'id';
  public NAME:string = 'name';
  public INDEXPOS:string = 'indexPos';
  public DEF_LAB_TXT:String = 'Phone Label Text';
  public LABELTEXT:string = 'labelText';
  public REQUIRED:string = 'required';
  public SHOWEXTENSION:string = 'showExtension';
  public EXTNLABEL:string = 'extnLabel';
}
