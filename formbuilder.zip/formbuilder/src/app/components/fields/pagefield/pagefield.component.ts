import { Component } from '@angular/core';
import { UtilityService} from '../../../services/UtilityService';
import { GlobalService } from '../../../services/GlobalService';
import { PageFieldModel } from './pagefield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'page-field',
  templateUrl:'./pagefield.component.html'
})

export class PageFieldComponent {
  public pageFieldModel:PageFieldModel = new PageFieldModel();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(public utilityService:UtilityService, public constants:Constants,
              private globalService:GlobalService) {
        this.pageFieldModel['type'] = this.constants.PAGE_FIELD;
        this.pageFieldModel['refId'] = utilityService.timeasRefId();
  }

 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.pageFieldModel = _data;
    }
    if(!isReLoadFields) { this.globalService.addappData(this.pageFieldModel, _index); }
  }
}
