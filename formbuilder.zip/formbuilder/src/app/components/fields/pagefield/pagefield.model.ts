declare var $:any;
export class PageFieldModel {
  public titleTxt:string;
  public componentName:string = 'Page';
  public isConditional:boolean = false;
  public type:string = 'pagefield';
  public refId:number;
  public isConfirmationPage:boolean = false;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
