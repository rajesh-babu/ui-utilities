import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { PageFieldComponent} from './pagefield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    PageFieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  PageFieldComponent ],
})
export class PageFieldModule { }
