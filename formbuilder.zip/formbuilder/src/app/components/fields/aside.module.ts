import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AccordionModule, CalendarModule } from 'primeng/primeng';
import { TooltipModule  } from 'ngx-bootstrap/tooltip';
import { Ng2AutoCompleteModule } from 'ng2-auto-complete';
import { MultiSelectModule } from 'primeng/primeng';
import { DropdownModule } from 'primeng/primeng';

import { AsideService} from '../../services/AsideService';
import { AsideComponent } from './aside.component';
import { AsideSectionComponent} from './section/aside/aside-section.component';
import { AsideSecContainerComponent} from './secContainer/aside/aside-secContainer.comp';
import { AsideTextFieldComponent} from './textfield/aside/aside-text-field.component';
import { AsideCheckboxFieldComponent} from './checkbox/aside/aside-checkbox-field.component';
import { AsideSelectFieldComponent} from './selectfield/aside/aside-select-field.component';
import { AsideRadioFieldComponent} from './radiofield/aside/aside-radio-field.component';
import { AsideDateFieldComponent} from './datefield/aside/aside-date-field.component';
import { AsidePhoneFieldComponent} from './phonefield/aside/aside-phone-field.component';
import { AsideParagraphFieldComponent} from './paragraphfield/aside/aside-paragraph-field.component';
import { AsideButtonFieldComponent} from './buttonfield/aside/aside-button-field.component';
import { AsideHeaderFieldComponent} from './headerfield/aside/aside-header-field.component';
import { AsideGridTableFieldComponent} from './gridtablefield/aside/aside-gridtable-field.component';
import { AsideDividerComponent} from './divider/aside/aside-divider-field.component';
import { AsideSsnFieldComponent} from './ssnfield/aside/aside-ssn-field.component';
import { AsideGrpFieldComponent } from './groupfield/aside/aside-group-field.component';
import { AsideTitleComponent } from './titlefield/aside/aside-title-field.component';

import { CustomCommonsModule } from './../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    TabsModule.forRoot(),
    AccordionModule,
    CalendarModule,
    TooltipModule.forRoot(),
    FormsModule,
    CustomCommonsModule,
    Ng2AutoCompleteModule,
    ReactiveFormsModule,
    MultiSelectModule,
    DropdownModule
  ],
  declarations: [
    AsideComponent,
    AsideSectionComponent,
    AsideSecContainerComponent,
    AsideTextFieldComponent,
    AsideCheckboxFieldComponent,
    AsideSelectFieldComponent,
    AsideRadioFieldComponent,
    AsideDateFieldComponent,
    AsidePhoneFieldComponent,
    AsideParagraphFieldComponent,
    AsideButtonFieldComponent,
    AsideHeaderFieldComponent,
    AsideGridTableFieldComponent,
    AsideDividerComponent,
    AsideSsnFieldComponent,
    AsideGrpFieldComponent,
    AsideTitleComponent
  ],
  exports: [
    AsideComponent, AsideSectionComponent, AsideSecContainerComponent, AsideTextFieldComponent, AsideCheckboxFieldComponent,
    AsideSelectFieldComponent, AsideRadioFieldComponent, AsideDateFieldComponent, AsidePhoneFieldComponent, AsideParagraphFieldComponent,
    AsideButtonFieldComponent, AsideHeaderFieldComponent, AsideGridTableFieldComponent, AsideGrpFieldComponent,
    AsideDividerComponent, AsideSsnFieldComponent,
    AsideTitleComponent
  ],
  providers: [],
  entryComponents: [  AsideComponent ],
})
export class AsideModule { }
