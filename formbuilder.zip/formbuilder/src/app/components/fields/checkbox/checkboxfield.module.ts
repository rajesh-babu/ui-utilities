import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CheckboxfieldComponent} from './checkboxfield.component';
import { AsideService} from '../../../services/AsideService';
import { CustomCommonsModule } from '../../../shared/customCommons.module';

@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    CheckboxfieldComponent
  ],
  providers: [AsideService],
  entryComponents: [  CheckboxfieldComponent ]
})
export class CheckboxFieldModule { }
