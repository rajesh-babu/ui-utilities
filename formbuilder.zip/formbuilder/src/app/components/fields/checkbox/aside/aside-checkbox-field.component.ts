import { Component, Input, OnChanges, SimpleChanges } from '@angular/core';
import { ComponentFactoryResolver, ViewContainerRef, ViewChild } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CheckboxFieldModel } from '../checkboxfield.model';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';
import { UtilityService } from '../../../../services/UtilityService';
import { FieldControlsService} from '../../../../services/FieldControlsService';
declare var $:any;

@Component({
  selector: 'aside-checkbox-field',
  templateUrl: './aside-checkbox-field.component.html'
})
export class AsideCheckboxFieldComponent implements OnChanges {
  @Input() fieldData:CheckboxFieldModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  checkboxFieldFormGrp:any;
  disbleOption:boolean = false;
  optionValidation:boolean = false;
  optionDuplicateCount:number;
  public constructor( public asideService:AsideService, public constants:Constants,
                      private commonsFieldsService:CommonsFieldsService,
                      private utilityService:UtilityService,
                      private formBuilder: FormBuilder, public globalService:GlobalService,
                      private fieldControlsService:FieldControlsService) {
                        this.checkboxFieldFormGrp = this.formBuilder.group({
                              'labelText':['',[]],
                              'reviewLabelText':['',[]],
                              'udLabelText':['',[]],
                              'id':['',[ValidationService.attributeValidator]],
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'name_override': ['', [ ValidationService.attributeValidator]],
                              'cssClass':['',[]],
                              'token':['',[]],
                              'alignment':['',[]],
                              'required':'',
                              'displayType':['',[]],
                              'dataSourceReference':['',[]],
                              'rowNumber':['',[]],
                              'maxChecked':['',[]],
                              'minChecked':['',[]],
                              'helpText':['',[]],
                              'errmsg':['',[]],
                              'adaAttrs':['',[ValidationService.adaAttributesValidator]],
                              'disabled':['',[]],
                              'hidefield':['',[]],
                              'fieldStyle':['',[]],
                              'hidefield_override':['',[]]
                           });
                        // this.fieldData.rowNumber = 11;
                      }

  updateRowNumber() {
    if(this.fieldData.hasOwnProperty('options')) {
      this.fieldData.rowNumber = this.fieldData.options.length + 1;
    }
  }

  ngOnChanges(changes: SimpleChanges) {
    if(changes['fieldData']) {
      this.updateRowNumber();
    }
  }

  /*
   * This will duplicate the field
   */
  duplicateField() {
    this.commonsFieldsService.duplicateField(
      {field:this.constants.CHECKBOX_FIELD, values:JSON.parse(JSON.stringify(this.fieldData)),
        indexPos:this.indexPos});
  }

  /*
   * Remove the options row
   */
  removeRow(index:number) {
    if(this.utilityService.findValueInArray(this.globalService.appGlobalData.settings.pages,['optionRefId'], this.fieldData.options[index]['optionRefId'])) {
      this.fieldControlsService.onRemoveOutside({});
    } else {
      this.fieldData.options.splice(index,1);
      this.updateRowNumber();
    }
  }
  /*
   * Add the options row
   */
  addRow() {
    if(this.fieldData.rowNumber !== 0 && this.fieldData.rowNumber <= this.fieldData.options.length) {
      this.fieldData.options.splice((this.fieldData.rowNumber - 1), 0,
      {label:'option ' + this.fieldData.rowNumber, value:'value ' + this.fieldData.rowNumber, selected:false, optionRefId:this.utilityService.timeasRefId()});
    } else {
      this.fieldData.options.push({label:'option ' + this.fieldData.rowNumber, value:'value ' + this.fieldData.rowNumber, selected:false, optionRefId:this.utilityService.timeasRefId()});
    }
    this.fieldData.rowNumber++;
    this.updateRowNumber();
  }

  toggleOption(e:string) {
    if(/\S/.test(e)) {
      this.disbleOption = true;
    }else {
      this.disbleOption = false;
    }
  }

  checkOptionsDuplicate(thisObj:any) {
    $(thisObj).parent('ol.sortable-options').find('li').removeClass('has-error');
    this.optionDuplicateCount = (<any>this.fieldData.options).filter((opt, index, self) =>
      self.findIndex(o => o.value === opt.value) !== index).length;
    if(this.optionDuplicateCount) {
        this.optionValidation = true;
        $(thisObj).addClass('has-error');
    }else {
      this.optionValidation = false;
    }
  }

}
