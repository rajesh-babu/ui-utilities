declare var $:any;
export class CheckboxFieldModel {
  indexPos: number;
  labelText:string = 'Label Text';
  udLabelText:string;
  reviewLabelText:string;
  required: boolean = false;
  id:string;
  name:string;
  name_override:string;
  cssClass:string;
  token:string;
  disabled:boolean = false;
  options:Array<Object> = [{label:'option 1', value: 'value 1', selected:false, optionRefId:''}, {label:'option 2', value: 'value 2', selected:false, optionRefId:''}];
  dataSourceReference:string;
  rowNumber:number;
  helpText:string;
  hidefield:boolean;
  hidefield_override:boolean;
  adaAttrs:string;
  alignment:string;
  maxChecked:number;
  minChecked:number;
  displayType:string = 'smallBox';
  public fieldStyle:string = 'type_1';
  public type:string;
  public componentName:string = 'Checkbox';
  public isConditional:boolean = false;
  public refId:number;
  public pgTopIndex:number;
  public grpRowIndex:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}

export class CheckboxFieldModelVars {
  public DEF_LAB_TXT:String = 'Type a Label Text';
}
