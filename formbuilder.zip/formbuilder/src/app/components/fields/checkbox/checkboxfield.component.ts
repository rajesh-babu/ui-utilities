import { Component, AfterViewInit } from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import {  CheckboxFieldModel, CheckboxFieldModelVars } from './checkboxfield.model';
import { Constants } from '../../../services/Constants';
declare var $:any;

@Component({
  selector: 'checkbox-field',
  templateUrl: './checkboxfield.component.html'
})
export class CheckboxfieldComponent implements AfterViewInit  {
  public checkboxFieldModel:CheckboxFieldModel = new CheckboxFieldModel();
  public checkboxFieldModelVars:CheckboxFieldModelVars = new CheckboxFieldModelVars();
  currentSelectedIndexPos:number;
  public className:string;

  constructor(public asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService) {
      this.checkboxFieldModel['type'] = this.constants.CHECKBOX_FIELD;
      this.checkboxFieldModel['refId'] = utilityService.timeasRefId();
  }

  /*
   * This will be triggered upon loading the form and pre populating
   */
   public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.checkboxFieldModel = _data;
     } else {
       // For Grid table, generated 3 types of refId for manging the conditional logic datas
       for(let i=0;i<this.checkboxFieldModel['options'].length;i++) {
         const thatRef = this;
         setTimeout(function(){thatRef.checkboxFieldModel['options'][i]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
       }
     }
     if(!isReLoadFields) { this.globalService.addappData(this.checkboxFieldModel, _index); }
   }
   /*
    * This will be triggered upon dropping the component in multi column
    */
   public setMColAppData(_data:any, _index:number, _colIndex:number, isSecContainer:boolean, isGroupField?:boolean, grpRowIndex?:number) {
     if(_data) { // If existing data
       this.checkboxFieldModel = _data;
     }
     this.checkboxFieldModel['colIndex'] = _colIndex;

     if(typeof(grpRowIndex) !== 'undefined') {
       this.checkboxFieldModel['grpRowIndex'] = grpRowIndex;
     }

     // If Multi column inside the secContainer, dont set the Data to AppData
     if(!isSecContainer) {
       this.globalService.addappData(this.checkboxFieldModel, _index, true, isGroupField);
     }
   }
   /*
    * This will be triggered upon dropping the component in Group field
    */
   public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
     if(_data) { // If existing data
       this.checkboxFieldModel = _data;
     } else {
       if(!isReLoadFields) {
         // For button, each button has refId for manging the conditional logic datas
         for(let i=0;i<this.checkboxFieldModel['options'].length;i++) {
           const thatRef = this;
           setTimeout(function(){thatRef.checkboxFieldModel['options'][i]['optionRefId']=thatRef.utilityService.timeasRefId(); }, 10);
         }
       }
     }
     this.checkboxFieldModel['grpRowIndex'] = _grpRowIndex;
     this.checkboxFieldModel['indexPos'] = _index;

     if(!isReLoadFields) { this.globalService.addappData(this.checkboxFieldModel, _index, false, true); }
   }
  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.CHECKBOX_FIELD, data:this.checkboxFieldModel, indexPos:_indexPos, isToggle:false});
    }
  }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
    this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
    const _isInsideSecContainer = ($currentEle.closest(this.constants.DROPPEDITEM_CLS).find(this.constants.SEC_OUTER_CLS).length) ? true : false;

    // Change the selected value to opened Aside
    const obj:any = {type:this.constants.CHECKBOX_FIELD, data:this.checkboxFieldModel,
      indexPos:this.currentSelectedIndexPos, isToggle:false};
    obj[this.constants.isInsideSecContainer] = _isInsideSecContainer;
    this.asideService.openAside(obj);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }
}
