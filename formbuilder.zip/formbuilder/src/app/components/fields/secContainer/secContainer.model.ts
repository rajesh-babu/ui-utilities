declare var $:any;
export class SecContainerModel {
  public pages:Array<any>;
  public assetId:string;
  public assetType:string;
  public name:string;
  public name_override:string;
  public token:string;
  public componentName:string = 'Widget';
  public isConditional:boolean = false;
  public hidefield:boolean;
  public type:string;
  public refId:number;
  public pgTopIndex:number;
  public reviewWidget:boolean;
  public stickyButtonWidget:boolean;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
