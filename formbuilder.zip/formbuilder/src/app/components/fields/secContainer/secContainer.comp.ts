import { Component, AfterViewInit,ViewContainerRef, ViewChild , ComponentRef,
         ComponentFactoryResolver, OnInit, Inject, forwardRef} from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { FieldControlsService } from '../../../services/FieldControlsService';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';
import { Constants } from '../../../services/Constants';
import { SecContainerModel } from './secContainer.model';

declare var $:any;

@Component({
  selector: 'section-container',
  templateUrl:'./secContainer.comp.html'
})

export class SecContainerComponent implements AfterViewInit {
  @ViewChild('widgetSecContainer', {read: ViewContainerRef}) widgetSecContainer;
  cmpRef: ComponentRef<Component>;

  public secContainerModel:SecContainerModel = new SecContainerModel();
  currentSelectedIndexPos:number;
  secFieldIndexPos:number = 0;
  public className:string;

  constructor(private asideService:AsideService, private utilityService:UtilityService,
              @Inject(forwardRef(() => FieldsFactoryService)) private fieldsFactoryService:FieldsFactoryService,
              public constants:Constants, private globalService:GlobalService,
              private componentFactoryResolver:ComponentFactoryResolver ) {
        this.secContainerModel['type'] = this.constants.SEC_CONTAINER;
        this.secContainerModel['refId'] = utilityService.timeasRefId();
  }

 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {
    if(_data) {
      this.secContainerModel = new SecContainerModel(_data);
    }
    if(!isReLoadFields) {
      this.globalService.addappData(this.secContainerModel, _index);
    }
    let rowIndexCounter:number = 0;
    let pgIndex:number = -1;
    for(let i=0;i<this.secContainerModel.pages.length;i++) {
        let isPageDisplayed = false;
        for(let j=0;j<this.secContainerModel.pages[i].length;j++) {

          // If widget has more than 1 pages, we need to show Page with its index value
          if(!isPageDisplayed && pgIndex !== j
            && (this.secContainerModel.pages[i][j]['type'] !== 'section' && this.secContainerModel.pages[i][j]['type'] !== 'titleField' && this.secContainerModel.pages[i][j]['type'] !== 'pagefield')
            && this.secContainerModel.pages.length > 1) {
            this.secContainerModel.pages[i][j]['pgTopIndex']= i+1;
            pgIndex = i;
            isPageDisplayed=true;
          }

          let isRenderField = true;
          // If user doesn't set 'label' for "titleField", Don't render the Title Field Component
          if(this.secContainerModel.pages[i][j]['type'] === this.constants.TITLE_FIELD) {
            if(!this.secContainerModel.pages[i][j].hasOwnProperty('label') || !this.secContainerModel.pages[i][j]['label']) {
              isRenderField = false;
            }
          }
          if(isRenderField) {
            this.createComponent(this.secContainerModel.pages[i][j]['type'], rowIndexCounter, this.secContainerModel.pages[i][j]);
            rowIndexCounter += 1;
          }
        }
    }
  }
  /*
   * It will create the fields
   */
  createComponent(fdName:string, _rowIndex:number, obj:any) {
    let factory;
    const selectedComp:any = this.fieldsFactoryService.getComponent(fdName) ;
    factory = this.componentFactoryResolver.resolveComponentFactory(selectedComp['type']);
    this.cmpRef = this.widgetSecContainer.createComponent(factory);

    // No need to set data to "appData", So set the paramater 'true'
    this.cmpRef['instance']['setAppData'](obj, _rowIndex, true);
    this.cmpRef['instance']['className'] = 'droppedItemContainer';

    // Set subtype for Text area
    if(selectedComp['subType']) {
      this.cmpRef['instance']['setSubType'](selectedComp['subType'], _rowIndex);
    }
  }

  /*
   * It will be triggered once dropped and trigger the aside component to change the view
   */
  ngAfterViewInit() {

    // set the Aside component if it has class "selected"
    if(this['className'] && this['className'].indexOf(this.constants.SELECTED) !== -1) {
      const _indexPos = this.utilityService.getCompIndexPos(this['className']);
      this.asideService.openAside({type:this.constants.SEC_CONTAINER, data:this.secContainerModel, indexPos:_indexPos, isToggle:false});
    }
    $('section-container').find('*[contenteditable]')
        .attr('contenteditable', false)
        .css('pointer-events', 'none');
  }
  itemClicked(e:Event) {
   const $currentEle = $(e.currentTarget),
     $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);
   this.currentSelectedIndexPos = this.utilityService.getCompIndexPos($currentEle.attr('class'));
   const targetEle = $(e.target).closest('field-controls');
   if(!targetEle.length || targetEle.hasClass('secContainer')) {
   // Open aside only for its own element and not for child elements
    this.asideService.openAside({type:this.constants.SEC_CONTAINER, data:this.secContainerModel,
    indexPos:this.currentSelectedIndexPos, isToggle:false});
  }

   // remove class "select" to all existing elements except currently selected
   $ele.removeClass(this.constants.SELECTED);
   $currentEle.addClass(this.constants.SELECTED);
 }

}
