import { Component, Input, OnInit } from '@angular/core';
import { AsideService} from '../../../../services/AsideService';
import { CommonsFieldsService} from '../../../../services/fields/CommonsFieldsService';
import { Constants} from '../../../../services/Constants';
import { SecContainerModel } from '../secContainer.model';
import { GlobalService} from '../../../../services/GlobalService';
import { FormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ValidationService } from '../../../../shared/validations/validation.service';

@Component({
  selector: 'aside-sec-container-field',
  templateUrl: './aside-secContainer.comp.html'
})
export class AsideSecContainerComponent {
  @Input() fieldData:SecContainerModel;
  @Input() addiData:any;
  @Input() indexPos:any;
  @Input() isInsideSec:boolean;
  sectionFieldFormGrp:any;

  public constructor( public asideService:AsideService, private commonsFieldsService:CommonsFieldsService,
                      public constants:Constants, private formBuilder: FormBuilder, public globalService:GlobalService) {
                        this.sectionFieldFormGrp = this.formBuilder.group({
                              'name': ['', [Validators.required, ValidationService.attributeValidator]],
                              'hidefield': ['',[]],
                              'reviewWidget': ['',[]],
                              'stickyButtonWidget': ['',[]]
                           });

                           // Below is added because widget inside the existing form is not updating when user change the widget properties.
                           this.sectionFieldFormGrp.valueChanges.subscribe(() => {
                           this.globalService.appData[this.globalService.selectedIndexPgArr][this.indexPos] = this.fieldData;
                          });
                      }
}
