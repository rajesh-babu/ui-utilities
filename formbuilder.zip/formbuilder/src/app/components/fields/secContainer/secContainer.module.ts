import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { SecContainerComponent } from './secContainer.comp';
import { AsideService} from '../../../services/AsideService';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';
import { CustomCommonsModule } from '../../../shared/customCommons.module';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule
  ],
  declarations: [
    SecContainerComponent
  ],
  providers: [AsideService, FieldsFactoryService],
  entryComponents: [  SecContainerComponent ],
})
export class SecContainerModule { }
