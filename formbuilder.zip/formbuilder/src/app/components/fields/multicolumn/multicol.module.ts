import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MulticolComponent} from './multicol.component';
import { AsideService} from '../../../services/AsideService';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';
import { CustomCommonsModule } from '../../../shared/customCommons.module';
import { DragulaModule} from 'ng2-dragula';


@NgModule({
  imports: [
    BrowserModule,
    CustomCommonsModule,
    DragulaModule
  ],
  declarations: [
    MulticolComponent
  ],
  exports:[MulticolComponent],
  providers: [AsideService, FieldsFactoryService],
  entryComponents: [ MulticolComponent ]
})
export class MulticolModule { }
