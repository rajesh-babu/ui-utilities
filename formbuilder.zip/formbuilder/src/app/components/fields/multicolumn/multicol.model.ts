declare var $:any;
export class MulticolModel {
  fieldsObj:any = {};
  componentName:string = 'Multi Column';
  public isConditional:boolean = false;
  public pgTopIndex:number;
  public type:string;
  public refId:number;
  constructor(v?:any) { if(v) { $.extend( this, v); }}
}
