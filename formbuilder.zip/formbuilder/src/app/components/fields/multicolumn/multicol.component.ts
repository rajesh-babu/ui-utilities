import { Component, AfterViewInit,ViewContainerRef, ViewChild , ComponentRef,
         ComponentFactoryResolver, OnInit} from '@angular/core';
import { AsideService} from '../../../services/AsideService';
import { UtilityService} from '../../../services/UtilityService';
import { FieldControlsComponent } from '../commons/fieldControls/fieldControls.component';
import { GlobalService } from '../../../services/GlobalService';
import { FieldControlsService } from '../../../services/FieldControlsService';
import { Constants } from '../../../services/Constants';
import { DragulaService } from 'ng2-dragula';
import { TextfieldComponent} from '../textfield/textfield.component';
import { MulticolModel } from './multicol.model';
import { FieldsFactoryService } from '../../../services/fields/FieldsFactory.service';

declare var $:any;

@Component({
  selector: 'multi-column',
  templateUrl:'./multicol.component.html'
})

export class MulticolComponent implements OnInit {

  @ViewChild('widgetMultiCol', {read: ViewContainerRef}) widgetMultiCol;
  cmpRef: ComponentRef<Component>;

  @ViewChild('widgetMultiCol2', {read: ViewContainerRef}) widgetMultiCol2;
  cmpRef2: ComponentRef<Component>;

  @ViewChild('widgetMultiCol3', {read: ViewContainerRef}) widgetMultiCol3;
  cmpRef3: ComponentRef<Component>;

  @ViewChild('widgetMultiCol4', {read: ViewContainerRef}) widgetMultiCol4;
  cmpRef4: ComponentRef<Component>;

  @ViewChild(FieldControlsComponent) fc:FieldControlsComponent;

  public multicolModel:MulticolModel = new MulticolModel();

  public added1:boolean;
  public added2:boolean;
  public added3:boolean;
  public added4:boolean;
  currentSelectedIndexPos:number;
  public className:string;

  constructor(private asideService:AsideService, private utilityService:UtilityService,
              public constants:Constants, private globalService:GlobalService,private componentFactoryResolver:ComponentFactoryResolver,
              private dragulaService:DragulaService, private fieldControlsService:FieldControlsService,
              private fieldsFactoryService:FieldsFactoryService) {
    this.multicolModel['type'] = this.constants.MULTICOL;
    this.multicolModel['refId'] = utilityService.timeasRefId();
 }

 ngOnInit() {
   this.fc.hideSettingsBut();
 }
 /*
  * This will be triggered upon loading the form and pre populating
  */
  public setAppData(_data:any, _index:number, isReLoadFields:boolean) {

    if(_data) { // If existing data
      this.multicolModel = _data;
      for (const key in this.multicolModel.fieldsObj) {
          // skip loop if the property is from prototype
          if (!this.multicolModel.fieldsObj.hasOwnProperty(key)) { continue; };
          const cobj = this.multicolModel.fieldsObj[key];
          this.createComponent(cobj['type'], _index, cobj['colIndex'], cobj, true);
      }
    }
    if(!isReLoadFields) { this.globalService.addappData(this.multicolModel, _index); }
  }
  /*
   * This will be triggered upon dropping the component in Group field
   */
  public setGrpFieldAppData(_data:any, _index:number, _grpRowIndex:number, isReLoadFields:boolean) {
    if(_data) { // If existing data
      this.multicolModel = _data;
    }
    this.multicolModel['grpRowIndex'] = _grpRowIndex;
    for (const key in this.multicolModel.fieldsObj) {
        // skip loop if the property is from prototype
        if (!this.multicolModel.fieldsObj.hasOwnProperty(key)) { continue; };
        const cobj = this.multicolModel.fieldsObj[key];
        this.createComponent(cobj['type'], _index, cobj['colIndex'], cobj, true);
    }

    if(!isReLoadFields) { this.globalService.addappData(this.multicolModel, _index, false, true); }
  }

 // It will be triggered when user deleting the field and get Column IndexPos as parameter. Destroy the corresponding component created.
 public onDelete(obj:any) {
   if(obj.colIndexPos === 0) {
     (this.widgetMultiCol.get(0)).destroy();
     this.added1 = false;
   }else if(obj.colIndexPos === 1) {
     (this.widgetMultiCol2.get(0)).destroy();
     this.added2 = false;
   }else if(obj.colIndexPos === 2) {
     (this.widgetMultiCol3.get(0)).destroy();
     this.added3 = false;
   }else if(obj.colIndexPos === 3) {
     (this.widgetMultiCol4.get(0)).destroy();
     this.added4 = false;
   }
   const isGrpField = (typeof(obj.grpIndexPos) !== 'undefined') ? true : false;
   const grpIndexPos = (typeof(obj.grpIndexPos) !== 'undefined') ? obj.grpIndexPos : null;

    // Delete the Global App data
    this.globalService.deleteappData(obj.indexPos, true, obj.colIndexPos, isGrpField, grpIndexPos);
 }

 // (0 - bagname, 1 - el, 2 - target, 3 - source, 4 - sibling)
 public onDrop(value) {
   if(!value[2] || !value[2].classList.contains('multiCol')) {
     return;
   }

   // Delete the soure field
   value[1].outerHTML = '';

   if(value[1].getAttribute('data-fieldname') === 'multiCol' && value[2].classList.contains('multiCol')) {

     // Dont allow if dropping multicolumn field within itself and Section
     return;
   }
   // Get the current row index
   const $selEle = $(value[2]).closest('.' + this.constants.DROPPEDITEM );
   if(!$selEle.length) { // Dont allow  non selected row
     return;
   }else {
     $selEle.addClass(this.constants.SELECTED);
   }
   const rowIndex = this.utilityService.getCompIndexPos($selEle.attr('class'));

  // Check if it's inside the group field, if so handle pass paramter to differtiate regular multi column and group field multicolumn
   const $grpFieldEle = $(value[2]).closest('.'+this.constants.droppedGrpItemCls);
   const isGroupField = ($grpFieldEle.length) ? true : false;
   let grpRowIndex;
   if($grpFieldEle.length) {
      grpRowIndex = this.utilityService.getCompIndexPos($grpFieldEle.attr('class'));
   }

   const fdName = value[1].getAttribute('data-fieldname');
   if(!value[4]) { // If field is dropped little below the placeholder
     if(value[2].children[0].classList.contains('col0')) {
       this.createComponent(fdName, rowIndex, 0, null, null, isGroupField, grpRowIndex);
     }else if(value[2].children[0].classList.contains('col1')) {
       this.createComponent(fdName, rowIndex, 1, null, null, isGroupField, grpRowIndex);
     }else if(value[2].children[0].classList.contains('col2')) {
       this.createComponent(fdName, rowIndex, 2, null, null, isGroupField, grpRowIndex);
     }else {
       this.createComponent(fdName, rowIndex, 3, null, null, isGroupField, grpRowIndex);
     }
   }else if(value[4].classList.contains('col0')) { // determine field is dropped which column
     this.createComponent(fdName, rowIndex, 0, null, null, isGroupField, grpRowIndex);
   }else if(value[4].classList.contains('col1')) { // determine field is dropped which column
     this.createComponent(fdName, rowIndex, 1, null, null, isGroupField, grpRowIndex);
   }else if(value[4].classList.contains('col2')) {
    this.createComponent(fdName, rowIndex, 2, null, null, isGroupField, grpRowIndex);
   }else {
    this.createComponent(fdName, rowIndex, 3, null, null, isGroupField, grpRowIndex);
   }
 }
 /*
  * It will create the fields to multicomponent
  */
 createComponent(fdName:string, _rowIndex:number, colIndex:number, obj?:any, isSecContainer?:boolean, isGroupField?:boolean, grpRowIndex?:number) {
   let factory;
   const cls:any = this.fieldsFactoryService.getComponent(fdName) ;
   factory = this.componentFactoryResolver.resolveComponentFactory(cls['type']);
   if(colIndex === 0) { // Place the component in cmpRef If Sibling element is inside the column 1
     this.cmpRef = this.widgetMultiCol.createComponent(factory);
     this.cmpRef['instance']['setMColAppData'](obj, _rowIndex, 0, isSecContainer, isGroupField, grpRowIndex);
     this.added1 = true;
     // Set subtype for Text area
     if(cls['subType']) {
       this.cmpRef['instance']['setSubType'](cls['subType']);
     }
   }else if(colIndex === 1) {
     this.cmpRef2 = this.widgetMultiCol2.createComponent(factory);
     this.cmpRef2['instance']['setMColAppData'](obj, _rowIndex, 1, isSecContainer, isGroupField, grpRowIndex);
      this.added2 = true;
     // Set subtype for Text area
     if(cls['subType']) {
       this.cmpRef2['instance']['setSubType'](cls['subType']);
     }
   }else if(colIndex === 2) {
     this.cmpRef3 = this.widgetMultiCol3.createComponent(factory);
     this.cmpRef3['instance']['setMColAppData'](obj, _rowIndex, 2, isSecContainer, isGroupField, grpRowIndex);
      this.added3 = true;
     // Set subtype for Text area
     if(cls['subType']) {
       this.cmpRef3['instance']['setSubType'](cls['subType']);
     }
   }else {
     this.cmpRef4 = this.widgetMultiCol4.createComponent(factory);
     this.cmpRef4['instance']['setMColAppData'](obj, _rowIndex, 3, isSecContainer, isGroupField, grpRowIndex);
      this.added4 = true;
     // Set subtype for Text area
     if(cls['subType']) {
       this.cmpRef4['instance']['setSubType'](cls['subType']);
     }
   }
 }

  itemClicked(e:Event) {
    const $currentEle = $(e.currentTarget),
      $ele = $currentEle.parent().parent().find('.' + this.constants.SELECTED);

    // remove class "select" to all existing elements except currently selected
    $ele.removeClass(this.constants.SELECTED);
    $currentEle.addClass(this.constants.SELECTED);
  }
}
