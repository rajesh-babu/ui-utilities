import { Component, ViewChild,  HostListener, OnInit, NgModule, ElementRef } from '@angular/core';

import { DragAndDropComponent} from './components/drag-and-drop/drag-drop.component';
import { PreviewComponent } from './components/pages/previewForm/preview-form.component';
import { SettingsPageComponent } from './components/pages/settings/settings-page.component';
import { AsideComponent } from './components/fields/aside.component';
import { Constants } from './services/Constants';
import { UtilityService } from './services/UtilityService';
import { GlobalService } from './services/GlobalService';
import { AsideService } from './services/AsideService';
import { FieldControlsService} from './services/FieldControlsService';
import { SecModalComponent} from './components/pages/modals/section/modal.comp';
import { FormSaveModalComponent } from './components/pages/modals/form/form-save.comp';
import { FormValidModalComponent } from './components/pages/modals/validation/form-valid.comp';
import { MulticolValidModalComponent } from './components/pages/modals/validation/multicol-valid.comp';
import { UpdateRefidModalComponent } from './components/pages/modals/refid/update-refid.comp';
import { ModalDirective } from 'ngx-bootstrap/modal';
import { ValidationService } from './shared/validations/validation.service';
import { NavService } from '../app/services/NavService';
import { Validators } from '@angular/forms';

declare var $:any;

@Component({
  // tslint:disable-next-line
  selector: 'body',
  templateUrl: './app.component.html'
})

export class AppComponent implements OnInit {

  @ViewChild('saveModal') saveModal: ElementRef;
  @ViewChild('formSaveModalComp') formSaveModalComp: FormSaveModalComponent;
  @ViewChild('formValidModalComp') formValidModalComp: FormValidModalComponent;
  @ViewChild('updateRefidModalComp') updateRefidModalComp: UpdateRefidModalComponent;
  @ViewChild('secModalComp') secModalComp: SecModalComponent;
  @ViewChild('validationModal') public validationModal:ModalDirective;
  @ViewChild('multicolValidModal') multicolValidModal: MulticolValidModalComponent;

  public disabled: boolean = false;
  public status: {isopen: boolean} = {isopen: false};
  public data_JSON_str:string = '';
  public previewBtnShow:boolean = false;

  public isSecNameContainerShow:boolean = true;
  public isSecNameInpFieldShow:boolean = true;
  public isCloseFieldSecShow:boolean = false;
  public statusMessageSec:string = '';
  public plsWaitMessageSec:string = '';
  public inputSecName:string = '';

  public constructor( private constants:Constants, public utilityService:UtilityService,
                      public globalService:GlobalService, private asideService:AsideService,
                      private fieldControlsService:FieldControlsService, public navService:NavService) { }

  public onPreviewClick(siteName:string): void {
      // this.globalService.selPage = 'previewForm';
      let domainStr:string = window.location.origin;
      domainStr = (domainStr.indexOf('localhost:4200') !== -1) ? this.utilityService.domainURL : '';
      let win;
      if(siteName == 'EVB') {
      win = window.open(domainStr+ this.utilityService.appContext + 'Satellite?d=&pagename='+ this.utilityService.siteName +'%2FTIAA_Form%2FTIAA_DFFForm%2F' + siteName + '%2FDefaultLayout&site=' + this.utilityService.siteName +
                              '&cid=' + this.globalService.appGlobalData.assetId + '&c=TIAA_Form', '_blank');
      } else if(siteName !== 'PublicRedesign') {
      win = window.open(domainStr+ this.utilityService.appContext + 'Satellite?d=&pagename=' + siteName + '%2FTIAA_Form%2FTIAA_DFFForm%2F' + siteName + '%2FDefaultLayout&site=' + this.utilityService.siteName +
                              '&cid=' + this.globalService.appGlobalData.assetId + '&c=TIAA_Form', '_blank');
      }else {
        win = window.open(domainStr+ this.utilityService.appContext + 'Satellite?d=&pagename=' + siteName + '%2FTIAA_Form%2FTIAA_DFFForm%2FDefaultLayout&rendermode=preview&site=' + this.utilityService.siteName +
                                '&cid=' + this.globalService.appGlobalData.assetId + '&c=TIAA_Form', '_blank');
      }
       win.focus();
      // $('.dragandDropSec').hide();
  }

  public updateRefId(): void {
    this.updateRefidModalComp['showModal']();
  }

  public previewBtnToggled():void {
    this.previewBtnShow = !this.previewBtnShow;
  }

  public toggleDropdown($event: MouseEvent): void {
    $event.preventDefault();
    $event.stopPropagation();
    this.status.isopen = !this.status.isopen;
  }
  ngOnInit(): void {
    this.globalService.selPage = 'dragandDrop';

    this.utilityService.setFormMode();

    // $('.nav-item').click(function(e) {
    //     e.preventDefault();
    //     const $that = $(this);
    //     if(!$that.find('.appBtn').hasClass('link')) {
    //       $that.parent().find('li').removeClass('selected');
    //       //$that.addClass('selected');
    //     }
    // });
  }
  /*
   * On clicking the 'Ok' menu, close tab
   */
  closeWindow():void {
      window.close();
  }

  /*
   * On clicking the 'SaveForm' menu, open popup
   */
  displaySaveModal():void {
    // Validate empty slots for multicolumn component before saving
    if(!this.globalService.validateMultiCol()) {
       this.multicolValidModal.showModal(this.constants.MULTICOL_PREVIEW_ERR_MSG);
       return;
    }

    this.globalService.saveSubmitted=true;
    this.isSecNameContainerShow = true;
    this.statusMessageSec = '';
    this.isCloseFieldSecShow = false;
    if(this.formValidModalComp['validateForm']()) {
      if(this.utilityService.formMode === 'Form') {
        this.formSaveModalComp['showModal']();
        this.globalService.storeJSON();
      }else {
        this.secModalComp['saveModalSection']['show']();
        this.secModalComp['setView']();
      }
    } else {
      this.formValidModalComp['showModal']();
    }
  }
}
