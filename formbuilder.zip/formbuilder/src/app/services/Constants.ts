import { Injectable } from '@angular/core';

@Injectable()
export class Constants {


  // UI Components
  public SECTION:string = 'section';
  public SEC_CONTAINER:string = 'secContainer';
  public MULTICOL:string = 'multiCol';
  public GROUP_FIELD:string = 'groupField';
  public TXT_FIELD:string = 'textfield';
  public TXT_AREA_FIELD:string = 'textAreafield';
  public CHECKBOX_FIELD:string = 'checkboxfield';
  public SELECT_FIELD:string = 'selectfield';
  public RADIO_FIELD:string = 'radiofield';
  public DATE_FIELD:string = 'datefield';
  public PHONE_FIELD:string = 'phonefield';
  public PARAGRAPH_FIELD:string = 'paragraphfield';
  public HEADER_FIELD:string = 'headerfield';
  public BUTTON_FIELD:string = 'buttonfield';
  public GRIDTABLE_FIELD:string = 'gridtablefield';
  public DIVIDER:string = 'dividerfield';
  public defaultSettingsPg:string = 'conditions';
  public SSN_FIELD:string = 'ssnfield';
  public pgTopIndexTopIconPos:number = 20;
  public pgTopIndexTitleText:string = 'Page';
  public TITLE_FIELD:string = 'titleField';
  public PAGE_FIELD:string = 'pagefield';

  public conditionsNew = {condIf:'',condState:'',showTarget:false,value:'',fieldType:[],ifRefId:'',ifSelectedIndex:-1,sourceRegex: '',
                          'condDo':[{dostate:'',dofield:[], targetRegex:''}]
                        };

  public cond:Array<Object> = [
                        {label:'Please Select State',value:'',fields:''},
                        {label:'Is Equal To',value:'equals',fields:this.CHECKBOX_FIELD+','+this.SELECT_FIELD+','+this.RADIO_FIELD},
                        {label:'Is Not Equal To',value:'notEquals',fields:this.SELECT_FIELD},
                        {label:'Is Empty',value:'isEmpty',fields:this.TXT_FIELD},
                        {label:'Is Filled',value:'isFilled',fields:this.TXT_FIELD},
                        {label:'Change',value:'change',fields:this.SELECT_FIELD}
                      ];

  public conditionDo:Array<Object> = [  {label:'Please Select Action',value:'',fields:''},
                                        {label:'Hide',value:'hide'},
                                        {label:'Show',value:'show'},
                                        {label:'Enable',value:'enable'},
                                        {label:'Disable',value:'disable'},
                                        {label:'Require',value:'require'},
                                        {label:'Require (OR)',value:'requireOr'},
                                        {label:'Unrequire',value:'unrequire'},
                                        {label:'Set',value:'set'}
                                    ];

  public formAttr:Array<Object> = [{
                                  'FormMethodType':'post',
                                  'FormType':'Generic',
                                  'FormLayoutType':'Vertical',
                                  'FormSectionAutoNumbering':'yes',
                                  'DCRS':'yes',
                                  'FormFieldRequired':'yes'
                                 }];

  // Drag and drop components
  public DROPPEDITEM_CLS:string = '.droppedItem';
  public droppedGrpItemCls:string = 'droppedGrpItem';
  public groupField_cls = 'groupField';
  public SEC_OUTER_CLS:string = '.secOuter';
  public DROPPEDITEM:string = 'droppedItem';
  public SELECTED:string = 'selected';
  public FW_CREATED_MESSAGE:string = 'Please save the form to proceed.';
  public FW_CREATE_BUTTON_CLS:string = '.formBuilderDButton';
  public FW_CREATE_BUTTON:string = '<span unselectable="on" class="formBuilderDButton dijit dijitReset dijitInline dijitButton fwButton dijitDisabled fwGreyButtonDisabled">'
  +'<span unselectable="on" class="dijitReset dijitInline dijitButtonNode"><span unselectable="on" class="dijitReset dijitInline fwButtonLeft"></span>'
  +'<span unselectable="on" class="dijitReset dijitStretch dijitButtonContents" tabindex="0"><span unselectable="on" class="dijitReset dijitInline dijitIcon"></span>'
  +'<span unselectable="on" class="dijitReset dijitToggleButtonIconChar"></span>'
  +'<span unselectable="on" class="dijitReset dijitInline dijitButtonText">Create New Form</span></span><span unselectable="on" class="dijitReset dijitInline fwButtonRight"></span></span></span>'
  +'<span class="form-label-text" style="color:#c74b33;">'+this.FW_CREATED_MESSAGE+'</span>';
  public FW_CREATE_BUTTON_TEXT:string = 'Create New Form';

  // Aside fields' description
  public DUPLICATE_TITLE:string = 'Duplicate';
  public DUPLICATE_BUTTON_LABEL:string = '+ DUPLICATE';
  public DUPLICATE_DESC:string = 'Duplicate this question with all saved settings.';

  public LABEL_TITLE:string = 'Label Text';
  public LABEL_DESC:string = 'Type your Label Text.';

  public REVIEW_LABEL_TITLE:string = 'Review Label Text';
  public REVIEW_LABEL_DESC:string = 'Type your Review Label Text.';

  public DEF_TITLE:string = 'Default Text';
  public DEF_DESC:string = 'Type your default Text.';

  public HEADER_TEXT_TITLE:string = 'Header Text';
  public HEADER_TEXT_DESC:string = 'Type your Header Text.';;

  public TITLE_TEXT:String = 'Section';
  public TIT_TXT_DESC:String = 'Type your section title.';

  public SEC_TYPE:String = 'Section Type';
  public SEC_TYPE_DESC:String = 'Select the section type.';

  public SUBLABEL_TITLE:string = 'Sub Label';
  public SUBLABEL_DESC:string = 'Type your Sub Label Text.';

  public ID_TITLE:string = 'ID';
  public ID_DESC:string = '"Id" attribute of the field.';

  public NAME_TITLE:string = 'Name';
  public NAME_DESC:string = '"Name" attribute of the field.';

  public CLASS_TITLE:string = 'Class';
  public CLASS_DESC:string = 'Add you custom class with comma(,) separated.';

  public TOKEN_TITLE:string = 'Token';
  public TOKEN_DESC:string = 'Secured token for the field';

  public REQUIRED_TITLE:string = 'Required';
  public REQUIRED_DESC:string = 'Prevent submission if this field is empty.';

  public DISABLED_TITLE:string = 'Disabled';
  public DISABLED_DESC:string = 'Field will be seen diabled in form.';

  public HIDE_TITLE:string = 'Hide Field';
  public HIDE_DESC:string = 'Hides the section in form.';

  public HIDE_CONTRACTS_MF:string = 'Hide mutual fund contracts';
  public HIDE_CONTRACTS_MF_DESC:string = 'Avoid mutual fund contracts.';

  public HIDE_CONTRACTS_BROK:string = 'Hide brokerage contracts';
  public HIDE_CONTRACTS_BROK_DESC:string = 'Avoid brokerage contracts.';

  public POPUP_TITLE:string = 'Is this popup?';
  public POPUP_DESC:string = 'Transform the Group Container to popup in form.';

  public POPUP_TITLE_ATTR:string = 'Popup Title Attribute';
  public POPUP_TITLE_ATTR_DESC:string = 'Specify the title text of the popup.';

  public POPUP_LIST_TITLE:string = 'Select popup';
  public POPUP_DELETE_TITLE:string = ' Popup container!';
  public POPUP_DELETE_MESSAGE:string = 'Please remove mapping from ';

  public POPUP_MULTICOL_TITLE:string = ' Multi column element!';
  public POPUP_GROUPFIELD_TITLE:string = ' Group field element!';
  public DELETE_POPUP_MESSAGE:string = 'Please remove all form elements in ';

  public HIDDEN_TITLE:string = 'Hidden Field';
  public HIDDEN_DESC:string = 'Element type as hidden field';

  public VALIDATION_TITLE:string = 'Validation';
  public VALIDATION_DESC:string = 'Check if the entry matches the selected format.';

  public ICON_TITLE:string = 'Icon Type';
  public ICON_DESC:string = 'Select the icon to be shown in text box.';

  public FIELD_STYLE_TITLE:string = 'Style';
  public FIELD_STYLE_DESC:string = 'Select the style.';

  public WIDTH_TYPE_TITLE:string = 'Width';
  public WIDTH_TYPE_DESC:string = 'Select a width.';

  public PHONE_TYPE_TITLE:string = 'Show Phone Type';
  public PHONE_TYPE_DESC:string = 'Show or Hide phone type.';

  public POPULATE_COUNTRY_TITLE:string = 'Populate with country names';
  public POPULATE_COUNTRY_DESC:string = 'Specify if dropdown to be populated with country names.';

  public USA_STATE_DROPDOWN_TITLE:string = 'State dropdown name';
  public USA_STATE_DROPDOWN_DESC:string = 'Specify state drop down name ( pre-populated ).';

  public POPULATE_USA_STATE_TITLE:string = 'Populate with USA state names';
  public POPULATE_USA_STATE_DESC:string = 'Specify if dropdown to be populated with USA state names.';

  public DATASOURCE_TITLE:string = 'DataSource Reference';
  public DATASOURCE_DESC:string = 'Specify the data source if any.';

  public FILTER_CONDITIONS_TITLE:string = 'Filters';
  public FILTER_CONDITIONS_DESC:string = 'Specify the filter conditions to filter. Ex: obj.Product=="D" && obj.ProductCode=="SRA"';

  public CATEGORY_TITLE:string = 'Category';
  public CATEGORY_DESC:string = 'Select the category (pre-defined filters).';

  public DISPLAYTYPE_TITLE:string = 'Display Type';
  public DISPLAYTYPE_DESC:string = 'Specify the size of the box.';

  public LINES_REQ:string = 'Number of Lines';
  public LINES_REQ_DESC:string = 'Specify the number of lines required';

  public SIZE_REQ:string = 'Size(width)';
  public SIZE_REQ_DESC:string = 'Specify the size required';

  public MAXCHAR_TITLE:string = 'Max Character';
  public MAXCHAR_DESC:string = 'Limit the maximum number of characters allowed for this field.';

  public MINCHAR_TITLE:string = 'Min Character';
  public MINCHAR_DESC:string = 'Limit the minimum number of characters required for this field.';

  public MAXVAL_TITLE:string = 'Max Value';
  public MAXVAL_DESC:string = 'Limit the maximum value allowed for this field.';

  public MINVAL_TITLE:string = 'Min Value';
  public MINVAL_DESC:string = 'Limit the minimum value required for this field.';

  public HELPTEXT_TITLE:string = 'Help Text';
  public HELPTEXT_DESC:string = 'Enter the hint text for this field.';

  public ADA_TITLE:string = 'Accessibility Attributes';
  public ADA_DESC:string = 'Enter the valid accessibility attributes (Ex. role="button") with comma separted';
  public ADA_DESC_PH:string = 'Ex. role="button"';

  public PLACEHOLDER_TITLE:string = 'PlaceHolder';
  public PLACEHOLDER_DESC:string = 'Add an example hint inside the field.';
  public PLACEHOLDERMULTIPLE_DESC:string = 'Separate with a comma for each text box.';

  public TITLE_TITLE:string = 'Section Title';
  public TITLE_DESC:string = 'Title for the section';

  public WIDGET_TITLE:string = 'Widget Title';
  public WIDGET_TITLE_DESC:string = 'Title for the widget';
  public WIDGET_TITLE_PLACEHOLDER = 'Enter Title Text';

  public ALIGNINLINE_TITLE:string = 'Align Inline';
  public ALIGNINLINE_DESC:string = 'Series of checkboxes/radios for controls that appear on the same line';

  public ALIGN_TITLE:string = 'Text Alignment';
  public ALIGN_DESC:string = 'Select how this heading is aligned horizontally.';

  public HEADER_SIZE_TITLE:string = 'Heading Size';
  public HEADER_SIZE_DESC:string = 'Select how big this heading is displayed.';

  public OPTION_TITLE:string = 'Options';
  public OPTION_DESC:string = 'Type your option and value.';

  public DIVIDER_BOTTOM_MARGIN_TITLE:String = 'Divider Bottom Margin';
  public DIVIDER_BOTTOM_MARGIN_DESC:String = 'Select a margin to bottom of divider.';

  public NUMBER_OF_FIELDS_TITLE:String = 'Number of fields';
  public NUMBER_OF_FIELDS_DESC:String = 'Select a number to split field into parts.';

  public AUTO_COMPLTE_PH:string = 'Enter or Select Names';
  public AUTO_COMPLTE_TO:string = 'Enter or Select Token';

  closeFormMsg:string = 'Do you want to close Form Builder?';
  public FORM_SAVE_CREATE:string = 'Please save the Form asset in Fatwire now. ' + this.closeFormMsg;
  public FORM_SAVE_EDIT:string = 'Your Form is updated. ' + this.closeFormMsg;

  public OVRRIDE:string = 'Override';
  public OVRRIDE_DESC:string = 'Override attribute of the above field.';

  public insideSecCls:string = 'insideSecCls'; // It's referred in '_overrideFields.scss'
  public isInsideSecContainer:string = 'isInsideSecContainer';

  public ERR_MSG_TITLE:string = 'Error Message';
  public ERR_MSG_DESC:string = 'Type a label to be shown in validation error messages.';

  public GRP_CATEGORY_TITLE:string = 'Category';
  public GRP_CATEGORY_DESC:string = 'Select the Group Category';

  public GRP_BGCOLOR_TITLE:string = 'Background Color';
  public GRP_BGCOLOR_DESC:string = 'Select the Background Color for this Group field';

  public REVIEW_WIDGET_TITLE:string = 'Review Widget';
  public REVIEW_WIDGET_DESC:string = 'Show this widget in Review Section';

  public CONFIRMATION_WIDGET_TITLE:string = 'Confirmation Widget';
  public CONFIRMATION_WIDGET_DESC:string = 'Show this widget in Confirmation Section';

  public REVIEW_WIDGET_RO_TITLE:string = 'Read Only';
  public REVIEW_WIDGET_RO_DESC:string = 'Show this Review widget in Read only mode';

  public STICKY_BUTTON_TITLE:string = 'Sticky Button Widget';
  public STICKY_BUTTON_DESC:string = 'Make this widget for Sticky Button';

  public PARATYPE_COMP_TITLE:string = 'Paragraph Type';
  public PARATYPE_COMP_DESC:string = 'Change this paragraph field for Help text or ToolTip';

  public HELPTEXT_BGCOLOR_TITLE:string = 'Help Text BG Color';
  public HELPTEXT_BGCOLOR_DESC:string = 'Select the Background color of Help Text';

  public TABLE_TYPE_TITLE:string = 'Table Type';
  public TABLE_TYPE_DESC:string = 'It will convert the table as Plans Table Format';

  public PLANNAME_TITLE:string = "PlanName's Name attribute";
  public PLANNAME_DESC:string = 'Enter the hidden field Name attribute for "PlanName" property.';

  public PLANNO_TITLE:string = "PlanNumber's Name attribute";
  public PLANNO_DESC:string = 'Enter the hidden field Name attribute for "PlanNumber" property.';

  public SUBPLANNAME_TITLE:string = "SubPlanName's Name attribute";
  public SUBPLANNAME_DESC:string = 'Enter the hidden field Name attribute for "SubPlanName" property.';

  public SUBPLANNO_TITLE:string = "SubPlanNumber's Name attribute";
  public SUBPLANNO_DESC:string = 'Enter the hidden field Name attribute for "SubPlanNumber" property.';

  public TIAANO_TITLE:string = "TiaaNumber's Name attribute";
  public TIAANO_DESC:string = 'Enter the hidden field Name attribute for "TiaaNumber" property.';

  public CREFNO_TITLE:string = "CrefNumber's Name attribute";
  public CREFNO_DESC:string = 'Enter the hidden field Name attribute for "CrefNumber property."';

  public ITDNO_TITLE:string = "ITD's Name attribute";
  public ITDNO_DESC:string = 'Enter the hidden field Name attribute for "ITD Number property."';

  public PRODUCTCODE_TITLE:string = "ProductCode's Name attribute";
  public PRODUCTCODE_DESC:string = 'Enter the hidden field Name attribute for "ProductCode property."';

  public BALANCE_TITLE:string = "Balance's Name attribute";
  public BALANCE_DESC:string = 'Enter the hidden field Name attribute for "Balance property."';

  public MINSELECT_TITLE:string = "MINIMUM Selection";
  public MINSELECT_DESC:string = 'Enter the mimimum selection required.';

  public MAXSELECT_TITLE:string = "MAXIMUM Selection";
  public MAXSELECT_DESC:string = 'Enter the maximum selection required.';

  public MAXLIMIT_TITLE:string = "MAXIMUM Limit";
  public MAXLIMIT_DESC:string = 'Enter the maximum Limit required.';

  public MINLIMIT_TITLE:string = "MINIMUM Limit";
  public MINLIMIT_DESC:string = 'Enter the Minmum Limit required. Enter 0 if not required';

  public PREF_CNT_TITLE:string = "Preferred Countries";
  public PREF_CNT_DESC:string = 'Select Preferred countries for dropdown.';

  public DEF_CNT_TITLE:string = "Default Country";
  public DEF_CNT_DESC:string = 'Select default country for dropdown.';

  public GROUP_FIELD_TITLE:string = 'Title';

  public UD_LABEL_TITLE:string = 'UD Label Text';
  public UD_LABEL_DESC:string = 'Type your Label Text.';

  public MULTICOL_DROP_ERR_MSG:string = 'Please Drop the component in the previous slot. No Empty slot is allowed between two fields of Multi Column component.';
  public MULTICOL_PREVIEW_ERR_MSG:string = 'No Empty slot is allowed between two fields of Multi Column component.';

  public INV_VARIATION_TITLE: string = 'Investment list variations';
  public INV_VARIATION_DESC: string = 'Select a varation.';

  public POPULATE_PLAN_SPONSER_DATA:string = 'Populate Plan Sponsor Data';
  public POPULATE_PLAN_SPONSER_DATA_DESC:string = 'Populate plan sponsor data.';

  public ADDRESS_1_NAME:string = 'Address 1 Name';
  public ADDRESS_1_DESC:string = '"Name" attribute of Address 1.';

  public ADDRESS_2_NAME:string = 'Address 2 Name';
  public ADDRESS_2_DESC:string = '"Name" attribute of Address 2.';

  public ADDRESS_3_NAME: string = 'Address 3 Name';
  public ADDRESS_3_DESC: string = '"Name" attribute of Address 3.';

  public CITY_NAME: string = 'City Name';
  public CITY_DESC: string = '"Name" attribute of City.';

  public PROVINCE_NAME: string = 'Province Name';
  public PROVINCE_DESC: string = '"Name" attribute of Province.';

  public POSTAL_CODE_NAME: string = 'PostalCode Name';
  public POSTAL_CODE_DESC: string = '"Name" attribute of PostalCode.';

  public ZIP_CODE_NAME: string = 'ZipCode Name';
  public ZIP_CODE_DESC: string = '"Name" attribute of ZipCode.';

  public STATE_NAME: string = 'State Name';
  public STATE_DESC: string = '"Name" attribute of State.';

  public COUNTRY_NAME: string = 'Country Name';
  public COUNTRY_DESC: string = '"Name" attribute of Country.';

  public POPULATE_PLAN_LOAN_NUMBER_PLAN_NAME: string = 'Populate Loan Number & Plan Name ';
  public POPULATE_PLAN_LOAN_NUMBER_PLAN_NAME_DESC: string = 'Populate Loan Number & Plan Name ';

  public LOAN_NUMBER_PLAN_NAME_DROPDOWN_NAME: string = 'LoanNumber / PlanName Name';
  public LOAN_NUMBER_PLAN_NAME_DROPDOWN_NAME_DESC: string = 'LoanNumber / PlanName Name';

  public countries:Array<object> =[
  {label:'Afghanistan',value:'af'},
  {label:'Aland Islands',value:'ax'},
  {label:'Albania',value:'al'},
  {label:'Algeria',value:'dz'},
  {label:'American Samoa',value:'as'},
  {label:'Andorra',value:'ad'},
  {label:'Angola',value:'ao'},
  {label:'Anguilla',value:'ai'},
  {label:'Antigua and Barbuda',value:'ag'},
  {label:'Argentina',value:'ar'},
  {label:'Armenia',value:'am'},
  {label:'Aruba',value:'aw'},
  {label:'Australia',value:'au'},
  {label:'Austria',value:'at'},
  {label:'Azerbaijan',value:'az'},
  {label:'Bahamas',value:'bs'},
  {label:'Bahrain',value:'bh'},
  {label:'Bangladesh',value:'bd'},
  {label:'Barbados',value:'bb'},
  {label:'Belarus',value:'by'},
  {label:'Belgium',value:'be'},
  {label:'Belize',value:'bz'},
  {label:'Benin',value:'bj'},
  {label:'Bermuda',value:'bm'},
  {label:'Bhutan',value:'bt'},
  {label:'Bolivia',value:'bo'},
  {label:'Bosnia and Herzegovina',value:'ba'},
  {label:'Botswana',value:'bw'},
  {label:'Brazil',value:'br'},
  {label:'British Indian Ocean Territory',value:'io'},
  {label:'British Virgin Islands',value:'vg'},
  {label:'Brunei',value:'bn'},
  {label:'Bulgaria',value:'bg'},
  {label:'Burkina Faso',value:'bf'},
  {label:'Burundi',value:'bi'},
  {label:'Cambodia',value:'kh'},
  {label:'Cameroon',value:'cm'},
  {label:'Canada',value:'ca'},
  {label:'Cape Verde',value:'cv'},
  {label:'Caribbean Netherlands',value:'bq'},
  {label:'Cayman Islands',value:'ky'},
  {label:'Central African Republic',value:'cf'},
  {label:'Chad',value:'td'},
  {label:'Chile',value:'cl'},
  {label:'China',value:'cn'},
  {label:'Christmas Island',value:'cx'},
  {label:'Cocos (Keeling) Islands',value:'cc'},
  {label:'Colombia',value:'co'},
  {label:'Comoros',value:'km'},
  {label:'Congo (DRC)',value:'cd'},
  {label:'Congo (Republic)',value:'cg'},
  {label:'Cook Islands',value:'ck'},
  {label:'Costa Rica',value:'cr'},
  {label:'Croatia',value:'hr'},
  {label:'Cuba',value:'cu'},
  {label:'Curacao',value:'cw'},
  {label:'Cyprus',value:'cy'},
  {label:'Czech Republic',value:'cz'},
  {label:'Denmark',value:'dk'},
  {label:'Djibouti',value:'dj'},
  {label:'Dominica',value:'dm'},
  {label:'Dominican Republic',value:'do'},
  {label:'Ecuador',value:'ec'},
  {label:'Egypt',value:'eg'},
  {label:'El Salvador',value:'sv'},
  {label:'Equatorial Guinea',value:'gq'},
  {label:'Eritrea',value:'er'},
  {label:'Estonia',value:'ee'},
  {label:'Ethiopia',value:'et'},
  {label:'Falkland Islands',value:'fk'},
  {label:'Faroe Islands',value:'fo'},
  {label:'Fiji',value:'fj'},
  {label:'Finland',value:'fi'},
  {label:'France',value:'fr'},
  {label:'French Guiana',value:'gf'},
  {label:'French Polynesia',value:'pf'},
  {label:'Gabon',value:'ga'},
  {label:'Gambia',value:'gm'},
  {label:'Georgia',value:'ge'},
  {label:'Germany',value:'de'},
  {label:'Ghana',value:'gh'},
  {label:'Gibraltar',value:'gi'},
  {label:'Greece',value:'gr'},
  {label:'Greenland',value:'gl'},
  {label:'Grenada',value:'gd'},
  {label:'Guadeloupe',value:'gp'},
  {label:'Guam',value:'gu'},
  {label:'Guatemala',value:'gt'},
  {label:'Guernsey',value:'gg'},
  {label:'Guinea',value:'gn'},
  {label:'Guinea-Bissau',value:'gw'},
  {label:'Guyana',value:'gy'},
  {label:'Haiti',value:'ht'},
  {label:'Honduras',value:'hn'},
  {label:'Hong Kong',value:'hk'},
  {label:'Hungary',value:'hu'},
  {label:'Iceland',value:'is'},
  {label:'India',value:'in'},
  {label:'Indonesia',value:'id'},
  {label:'Iran',value:'ir'},
  {label:'Iraq',value:'iq'},
  {label:'Ireland',value:'ie'},
  {label:'Isle of Man',value:'im'},
  {label:'Israel',value:'il'},
  {label:'Italy',value:'it'},
  {label:'Ivory Coast',value:'ci'},
  {label:'Jamaica',value:'jm'},
  {label:'Japan',value:'jp'},
  {label:'Jersey',value:'je'},
  {label:'Jordan',value:'jo'},
  {label:'Kazakhstan',value:'kz'},
  {label:'Kenya',value:'ke'},
  {label:'Kiribati',value:'ki'},
  {label:'Kuwait',value:'kw'},
  {label:'Kyrgyzstan',value:'kg'},
  {label:'Laos',value:'la'},
  {label:'Latvia',value:'lv'},
  {label:'Lebanon',value:'lb'},
  {label:'Lesotho',value:'ls'},
  {label:'Liberia',value:'lr'},
  {label:'Libya',value:'ly'},
  {label:'Liechtenstein',value:'li'},
  {label:'Lithuania',value:'lt'},
  {label:'Luxembourg',value:'lu'},
  {label:'Macau',value:'mo'},
  {label:'Macedonia',value:'mk'},
  {label:'Madagascar',value:'mg'},
  {label:'Malawi',value:'mw'},
  {label:'Malaysia',value:'my'},
  {label:'Maldives',value:'mv'},
  {label:'Mali',value:'ml'},
  {label:'Malta',value:'mt'},
  {label:'Marshall Islands',value:'mh'},
  {label:'Martinique',value:'mq'},
  {label:'Mauritania',value:'mr'},
  {label:'Mauritius',value:'mu'},
  {label:'Mayotte',value:'yt'},
  {label:'Mexico',value:'mx'},
  {label:'Micronesia',value:'fm'},
  {label:'Moldova',value:'md'},
  {label:'Monaco',value:'mc'},
  {label:'Mongolia',value:'mn'},
  {label:'Montenegro',value:'me'},
  {label:'Montserrat',value:'ms'},
  {label:'Morocco',value:'ma'},
  {label:'Mozambique',value:'mz'},
  {label:'Myanmar (Burma)',value:'mm'},
  {label:'Namibia',value:'na'},
  {label:'Nauru',value:'nr'},
  {label:'Nepal',value:'np'},
  {label:'Netherlands',value:'nl'},
  {label:'New Caledonia',value:'nc'},
  {label:'New Zealand',value:'nz'},
  {label:'Nicaragua',value:'ni'},
  {label:'Niger',value:'ne'},
  {label:'Nigeria',value:'ng'},
  {label:'Niue',value:'nu'},
  {label:'Norfolk Island',value:'nf'},
  {label:'North Korea',value:'kp'},
  {label:'Northern Mariana Islands',value:'mp'},
  {label:'Norway',value:'no'},
  {label:'Oman',value:'om'},
  {label:'Pakistan',value:'pk'},
  {label:'Palau',value:'pw'},
  {label:'Palestine',value:'ps'},
  {label:'Panama',value:'pa'},
  {label:'Papua New Guinea',value:'pg'},
  {label:'Paraguay',value:'py'},
  {label:'Peru',value:'pe'},
  {label:'Philippines',value:'ph'},
  {label:'Poland',value:'pl'},
  {label:'Portugal',value:'pt'},
  {label:'Puerto Rico',value:'pr'},
  {label:'Qatar',value:'qa'},
  {label:'Reunion',value:'re'},
  {label:'Romania',value:'ro'},
  {label:'Russia',value:'ru'},
  {label:'Rwanda',value:'rw'},
  {label:'Saint Barthelemy',value:'bl'},
  {label:'Saint Helena',value:'sh'},
  {label:'Saint Kitts and Nevis',value:'kn'},
  {label:'Saint Lucia',value:'lc'},
  {label:'Saint Martin',value:'mf'},
  {label:'Saint Pierre and Miquelon',value:'pm'},
  {label:'Saint Vincent and the Grenadines',value:'vc'},
  {label:'Samoa',value:'ws'},
  {label:'San Marino',value:'sm'},
  {label:'Sao Tome and Principe',value:'st'},
  {label:'Saudi Arabia',value:'sa'},
  {label:'Senegal',value:'sn'},
  {label:'Serbia',value:'rs'},
  {label:'Seychelles',value:'sc'},
  {label:'Sierra Leone',value:'sl'},
  {label:'Singapore',value:'sg'},
  {label:'Sint Maarten',value:'sx'},
  {label:'Slovakia',value:'sk'},
  {label:'Slovenia',value:'si'},
  {label:'Solomon Islands',value:'sb'},
  {label:'Somalia',value:'so'},
  {label:'South Africa',value:'za'},
  {label:'South Korea',value:'kr'},
  {label:'South Sudan',value:'ss'},
  {label:'Spain',value:'es'},
  {label:'Sri Lanka',value:'lk'},
  {label:'Sudan',value:'sd'},
  {label:'Suriname',value:'sr'},
  {label:'Svalbard and Jan Mayen',value:'sj'},
  {label:'Swaziland',value:'sz'},
  {label:'Sweden',value:'se'},
  {label:'Switzerland',value:'ch'},
  {label:'Syria',value:'sy'},
  {label:'Taiwan',value:'tw'},
  {label:'Tajikistan',value:'tj'},
  {label:'Tanzania',value:'tz'},
  {label:'Thailand',value:'th'},
  {label:'Timor-Leste',value:'tl'},
  {label:'Togo',value:'tg'},
  {label:'Tokelau',value:'tk'},
  {label:'Tonga',value:'to'},
  {label:'Trinidad and Tobago',value:'tt'},
  {label:'Tunisia',value:'tn'},
  {label:'Turkey',value:'tr'},
  {label:'Turkmenistan',value:'tm'},
  {label:'Turks and Caicos Islands',value:'tc'},
  {label:'Tuvalu',value:'tv'},
  {label:'U.S. Virgin Islands',value:'vi'},
  {label:'Uganda',value:'ug'},
  {label:'Ukraine',value:'ua'},
  {label:'United Arab Emirates',value:'ae'},
  {label:'United Kingdom',value:'gb'},
  {label:'United States',value:'us'},
  {label:'Uruguay',value:'uy'},
  {label:'Uzbekistan',value:'uz'},
  {label:'Vanuatu',value:'vu'},
  {label:'Vatican City',value:'va'},
  {label:'Venezuela',value:'ve'},
  {label:'Vietnam',value:'vn'},
  {label:'Wallis and Futuna',value:'wf'},
  {label:'Western Sahara',value:'eh'},
  {label:'Yemen',value:'ye'},
  {label:'Zambia',value:'zm'},
  {label:'Zimbabwe',value:'zw'}
];
}
export class AppGlobalDataModel {
  public pages:Array<any>;
  public settings:any = {
    pages:[],
    form:new Object()
  };
  public assetId:string;
  public assetType:string;
  public type:string; // secContainer
  // public secFieldsArr:Array<any>;
}
