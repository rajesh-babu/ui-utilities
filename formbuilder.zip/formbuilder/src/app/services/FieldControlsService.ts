import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
@Injectable()
export class FieldControlsService {
  // Observable string sources
  private onRemoveSource = new Subject<any>();
  private onRemoveActionSource = new Subject<any>();
  private multiColOnRemoveSrc = new Subject<any>();
  private grpFieldOnRemoveSrc = new Subject<any>();
  private onRemoveOutsideSource = new Subject<any>();
  private onsaveFormattrSource = new Subject<any>();

  // Observable string streams
  onRemove$ = this.onRemoveSource.asObservable();
  onRemoveAction$ = this.onRemoveActionSource.asObservable();
  onRemoveOutside$ = this.onRemoveOutsideSource.asObservable();
  onsaveFormattr$ = this.onsaveFormattrSource.asObservable();
  multiColOnRemove$ = this.multiColOnRemoveSrc.asObservable();
  grpFieldOnRemove$ = this.grpFieldOnRemoveSrc.asObservable();

  // Service message commands
  onRemove(obj: any) {
    this.onRemoveSource.next(obj);
  }
  onRemoveAction(obj: any) {
    this.onRemoveActionSource.next(obj);
  }
  onRemoveOutside(obj: any) {
    this.onRemoveOutsideSource.next(obj);
  }
  onsaveFormattr(obj: any) {
    this.onsaveFormattrSource.next(obj);
  }
  // Service message commands
  onMultiColRemove(obj: any) {
    this.multiColOnRemoveSrc.next(obj);
  }
  // Service message commands
  onGrpFieldRemove(obj: any) {
    this.grpFieldOnRemoveSrc.next(obj);
  }
}
