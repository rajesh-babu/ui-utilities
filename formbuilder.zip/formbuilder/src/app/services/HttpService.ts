import { Injectable } from '@angular/core';
import { Http, Response, Jsonp, Headers, RequestOptions, URLSearchParams  } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/observable/throw';

import { UtilityService} from './UtilityService';

@Injectable()
export class HttpService {

  cb:string = '&callback=JSONP_CALLBACK';
  getAllSectionsURL;
  getSectionURL;
  domainStr:string = window.location.origin;

  constructor (private http: Http, private jsonp: Jsonp, private utilityService:UtilityService) {

    // While running the app in localhost mode, set the target Domain URL based on query paramter 'env'
    this.utilityService.setFormMode();
    this.domainStr = (this.domainStr.indexOf('localhost:4200') !== -1) ? utilityService.domainURL : this.domainStr;
    this.getAllSectionsURL = this.utilityService.appContext + 'ContentServer?d=&pagename=TIAA/DFF/Section/GetAllSections';
    this.getSectionURL = this.utilityService.appContext + 'ContentServer?d=&pagename=TIAA/DFF/Section/GetSection';
  }
  /*
   * Get the List of Sections from server side
   */
  public getSectionsList() {
    return this.jsonp.request(this.domainStr + this.getAllSectionsURL + this.utilityService.siteNameQry + this.cb)
      // this.getAbsoluteURL() + 'assets/json/sections-data.json'
      .map((res: Response)=> {
        const body = res.json();
        return body.sections || { };
      })
      .catch(this.handleError);
  }
  /*
   * Get the sections by id from server side
   */
  public getSectionDet(secObj:any) {
    return this.jsonp.request(this.domainStr + this.getSectionURL + '&assetId='+secObj.assetId+'&assetType='+ secObj.assetType +
            this.utilityService.siteNameQry + this.cb)
    // return this.http.get(this.getAbsoluteURL() + 'assets/json/sec-'+secObj.assetId+'.json')
    .map((res: Response)=> {
      return this.utilityService.decodeJSONParse(JSON.stringify(res.json()));
    })
      .catch(this.handleError);
  }

  /*
   * Save the Section
   */
  public createSection(dt:any, secName:string):Promise<any> {
    const headers = new Headers({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    const options = new RequestOptions({
      headers: headers
    });
     const body = new URLSearchParams();
     body.append('sectionJson', this.utilityService.encodeJSONStringify(dt) );
     body.append('sectionName', secName);
     body.append('siteName', this.utilityService.siteName);
    return this.http.post(window.location.origin + this.utilityService.appContext + 'ContentServer?d=&pagename=TIAA/DFF/Section/CreateSection'+
           this.cb, body, options)
           .toPromise()
           .then(this.extractData)
           .catch(this.handlePromiseError);
  }
  /*
   * Save the Section
   */
  public updateSection(dt:any, updateSecObj:any):Promise<any> {
    const headers = new Headers({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    const options = new RequestOptions({
      headers: headers
    });
     const body = new URLSearchParams();
     body.append('sectionJson', this.utilityService.encodeJSONStringify(dt));
     body.append('assetId', updateSecObj.assetId);
     body.append('assetType', updateSecObj.assetType);
     body.append('siteName', this.utilityService.siteName);
    return this.http.post(this.domainStr + this.utilityService.appContext + 'ContentServer?d=&pagename=TIAA/DFF/Section/UpdateSection'+
           this.cb, body, options)
           .toPromise()
           .then(this.extractData)
           .catch(this.handlePromiseError);
  }
  /*
   * Update the Form
   */
  public updateForm(dt:any):Promise<any> {
    const headers = new Headers({
      'Content-Type': 'application/x-www-form-urlencoded'
    });
    const options = new RequestOptions({
      headers: headers
    });
     const body = new URLSearchParams();
     body.append('formJson', this.utilityService.encodeJSONStringify(dt));
     body.append('assetId', dt.assetId);
     body.append('assetType', dt.assetType);
     body.append('siteName', this.utilityService.siteName);
    return this.http.post(this.domainStr + this.utilityService.appContext + 'ContentServer?d=&pagename=TIAA/DFF/Form/UpdateForm'+
           this.cb, body, options)
           .toPromise()
           .then(this.extractData)
           .catch(this.handlePromiseError);
  }

  private extractData(res: Response) {
      const resultStr:string = res['_body'],
        startIndex = resultStr.indexOf('('),
        endIndex = resultStr.indexOf(')');
       const objStr = resultStr.substring(startIndex+1 , endIndex-1);
       return JSON.parse(objStr);
  }
  private handlePromiseError (error: Response | any) {
    // In a real world app, we might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Promise.reject(errMsg);
  }
  private handleError (error: Response | any) {
    // In a real world app, you might use a remote logging infrastructure
    let errMsg: string;
    if (error instanceof Response) {
      const body = error.json() || '';
      const err = body.error || JSON.stringify(body);
      errMsg = `${error.status} - ${error.statusText || ''} ${err}`;
    } else {
      errMsg = error.message ? error.message : error.toString();
    }
    console.error(errMsg);
    return Observable.throw(errMsg);
  }
  /*
   * This will return the Full URL
   */
  private getAbsoluteURL() {
    const urlPath:any = window.location, org:any = urlPath.origin;
    let finalPath:string = '';
    const pName = urlPath.pathname.split('/');
    for(let i=0;i<pName.length-1;i++) {
      const temp = pName[i] + '/';
      finalPath += temp;
    }
    return org + finalPath;
  }

}
