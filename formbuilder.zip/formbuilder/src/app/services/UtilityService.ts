import { Injectable } from '@angular/core';
declare var $:any;

@Injectable()
export class UtilityService {
   public formMode:string = 'Form';
   public siteNameQry:string;
   public siteName:string;
   public uniqueEleId:number = 1;
   public appAction:string; // default value
   public domainURL:string;
   public assetId:string;
   public appContext = '/cs/';
  /*
   * Returns the index position of widget container where dropped element to be created
   */
   getCompIndexPos( classNamesStr:string) {
    const classes:any = classNamesStr.split(' ');
    let result: number;
    for (let i = 0; i < classes.length; i++) {
      const matches = /^comp_(.+)/.exec(classes[i]);
      if (matches != null) {
        result = Number(matches[1]);
      }
    }
    return result;
  }

  setFormMode() {
    const queries = {};
    $.each(document.location.search.substr(1).split('&'),function(c,q){
      if(q) {
        const i = q.split('=');
        queries[i[0].toString()] = i[1].toString();
      }
    });
    if(queries['mode']) {
      this.formMode = queries['mode'];
    }

    // siteName needed for all ajax calls
    if(queries['siteName']) {
      this.siteNameQry = '&siteName=' + queries['siteName'];
      this.siteName = queries['siteName'];
    }

    // siteName needed for all ajax calls
    if(queries['appAction']) {
      this.appAction = queries['appAction'];
    }

    if(queries['assetId']) {
      this.assetId = queries['assetId'];
    }

    if (queries['appContext']) {
      this.appContext = queries['appContext'];
    }

    // While running the app in localhost mode, set the target Domain URL based on query paramter 'env'
    if(queries['env']) {
      if(queries['env'] === 'DEV') {
        this.domainURL = 'http://www-mgmt-dev.test.tiaa-cref.org';
      }else if(queries['env'] === 'IT') {
        this.domainURL = 'http://www-mgmt-it2.test.tiaa-cref.org';
      }
    }
  }

  getUniqueElementId():number {

    const todaysDate = new Date();
    return todaysDate.getTime();
  }
  /*
   * Encode the special characters
   */
  encodeJSONStringify(dt) {

    // As single quote breaks JSON data, substitute the '|#*' instead of single quote
    return JSON.stringify(dt).replace(/'/g, '|#*');
  }
  /*
   * Decode the special characters
   */
  decodeJSONParse(dt) {

    // As single quote breaks JSON data, substitute the '|#*' instead of single quote
    return JSON.parse(dt.split("|#*").join("'"));
  }
  /*
  * Return timestamp as reference id, which would be unique to each form element.
  * With which, we will able to depend on to identify form elements aside field changes
  */
  timeasRefId () {
    const todaysDate = new Date();
    return todaysDate.getTime();
  }
  /*
   * Find the values in nested deep array and objects
   */
  findValueInArray(arr:any, keys:Array<any>, value:any) {
   const foundArr = [];
   this._inArray(arr, keys,value, foundArr);
   return (foundArr.length) ? true : false;
  }
  private _inArray(arrObject:any, key:Array<any>, value:string, foundArr:Array<any>) {
     let result = false;
     if( arrObject instanceof Array) {
       for(let i = 0; i < arrObject.length; i++) {
           result = this._inArray(arrObject[i], key, value, foundArr);
       }
     }else {
         for(const prop in arrObject) {
            if(arrObject.hasOwnProperty(prop)) {
               for(let i=0;i<key.length;i++) {
                 if(prop === key[i]) {
                   if(arrObject[prop] === value) {
                     foundArr.push(i);
                      return true;
                   }
                }
               }
             if(arrObject[prop] instanceof Object || arrObject[prop] instanceof Array) {
               result = this._inArray(arrObject[prop],key, value, foundArr);
             }
           }
         }
     }
     return result;
  }
  /*
   * Generate the Java script string based on the dataSourceReference, filter condition and random number to use it in commons.js
   */
  public genearteJSPreviewMode(stringWithDots, filterConditions, randomNumber) {
    const regex =  new RegExp(/\[(\w+)\]/g);
    if(!filterConditions || filterConditions === '') {
      filterConditions = true;
    }
    let scrStr = " var stringWithDots = '"+stringWithDots+"';";
    scrStr+= "   var propArr = stringWithDots.split('.');";
    scrStr+= "   var fieldArr = convertStrDotToJSON(stringWithDots),";
    scrStr+= "   fieldName = propArr[propArr.length-1],";
    scrStr+= "   arrName = propArr.join('')+'"+randomNumber+"';";
    scrStr+= "   if(!fieldArr){ console.error('There is a contributtion issue for Datasource Reference property. Please fix it in Form builder App.'); }";
    scrStr+= "   window[arrName] = [];";
    scrStr+= "   if(fieldName !== null && fieldArr) {";
    scrStr+= "   if(!$.isArray(fieldArr)){fieldArr = fieldArr[fieldName]; }";
    scrStr+= "     for(var j=0;j<fieldArr.length;j++) {";
    scrStr+= "       var obj = fieldArr[j];";
    scrStr+= "       if("+filterConditions+") {";
    scrStr+= "         if(fieldArr[j][fieldName]) {";
    scrStr+= "           window[arrName].push(fieldArr[j][fieldName]);";
    scrStr+= "         }else {";
    scrStr+= "          window[arrName].push(fieldArr[j]);";
    scrStr+= "       }";
    scrStr+= "     }";
    scrStr+= "   }";
    scrStr+= "  }";
    return scrStr.replace(/\+/g, '*#|');
  }
  /*
   * Generate the Java script string based on the dataSourceReference, filter condition and random number to use it in commons.js
   */
  public geneartePlansJSPreviewMode( filterConditions, varName) {

    if(!filterConditions || filterConditions === '') {
      filterConditions = true;
    }
    let scrStr = "if(window.contractInfoJSON) {";
    scrStr+= "    var tempVar = JSON.parse(window.contractInfoJSON),";
    scrStr+= "      "+varName+" = [];";
    scrStr+= "    if(tempVar.Parents) {";
    scrStr+= "     for(var j=0;j<tempVar.Parents.length;j++) {";
    scrStr+= "       var obj = tempVar.Parents[j];";
    scrStr+= "       if("+filterConditions+") {";
    scrStr+= "         "+varName+".push(obj);";
    scrStr+= "       }";
    scrStr+= "     }";
    scrStr+= "   }";
    scrStr+= "}";

    // As there is an issue with rendering '+' symbol, Replace it with '*#|', so that fw team will change it accordingly
    return scrStr.replace(/\+/g, '*#|');
  }
}
