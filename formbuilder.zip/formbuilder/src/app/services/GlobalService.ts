import { Injectable } from '@angular/core';
import { TextFieldModel } from '../components/fields/textfield/textfield.model';
import { ButtonFieldModel } from '../components/fields/buttonfield/buttonfield.model';
import { CheckboxFieldModel } from '../components/fields/checkbox/checkboxfield.model';
import { DateFieldModel } from '../components/fields/datefield/datefield.model';
import { HeaderFieldModel } from '../components/fields/headerfield/headerfield.model';
import { ParagraphFieldModel } from '../components/fields/paragraphfield/paragraphfield.model';
import { PhoneFieldModel } from '../components/fields/phonefield/phonefield.model';
import { RadioFieldModel } from '../components/fields/radiofield/radiofield.model';
import { SectionModel } from '../components/fields/section/section.model';
import { SelectFieldModel } from '../components/fields/selectfield/selectfield.model';
import { Constants, AppGlobalDataModel } from './Constants';
import { UtilityService } from './UtilityService';
import { HttpService} from './HttpService';
import { MulticolModel} from '../components/fields/multicolumn/multicol.model';
import { GridTableFieldModel } from '../components/fields/gridtablefield/gridtablefield.model';
import { DividerModel } from '../components/fields/divider/divider-field.model';
import { SecContainerModel } from '../components/fields/secContainer/secContainer.model';
import { SsnFieldModel } from '../components/fields/ssnfield/ssnfield.model';
import { GroupFieldModel } from '../components/fields/groupfield/groupfield.model';
import { TitleModel } from '../components/fields/titlefield/title-field.model';
import { PageFieldModel } from '../components/fields/pagefield/pagefield.model';

declare var $:any;
declare var additionalFwDt: any;

@Injectable()
export class GlobalService {

  // Array to hold the overall app JSON data
  appData:any = [];

  appGlobalData:AppGlobalDataModel = new AppGlobalDataModel();

  // Additional data from FW
  additionalFwDt:any = additionalFwDt;

  // Current selected index of appPagesArr
  selectedIndexPgArr:number = 0;

  // Selected Page
  selPage = 'dragandDrop';

  // Selected Page
  selSettings = 'conditions';

  // Section's Asset Id and type
  currentAssetType:string;
  currentAssetId:string;
  conditions:any;

  saveSubmitted:boolean;

  constructor(private constants:Constants, private utilityService:UtilityService, private httpService:HttpService) {}
  /*
   * Add the JSON for corresponding field to Global Array
   */
  addappData(obj:any, index:number, isMultiCol?:boolean, isGrpField?:boolean) {

    if(isMultiCol) {
      this.setMultiColObj(obj, index, isGrpField);
      return;
    }

    // Set the data for field which is in group fields
    if(isGrpField) {
      this.setGrpFieldObj(obj, index);
      return;
    }

    if(this.appData.length) {
      // Insert or add fields into array
      const selPg = this.appData[this.selectedIndexPgArr];
      selPg.splice(index, 0, obj);
      this.appData[this.selectedIndexPgArr] = selPg;
    }else {
      this.appData.push([obj]);
    }

  }
  /*
   * This will add the properties based on appAction suchas 'Form' and 'Section'
   */
  addActionType() {
    if(this.utilityService.formMode === 'Form') {
        // localStorage.setItem('formsData', JSON.stringify(this.appData));
      }else {
        // localStorage.setItem('sectionsData', JSON.stringify(this.appData));
      }
  }
  showData() {
    localStorage.removeItem('formsData');
    // debugger;
  }
  /*
   * Reset the Array
   */
  resetappData() {
    this.appData = [];
  }

  /*
   * Return the multi column object - 1st create child fields and create the "MULTICOL" field then
   */
  private setMultiColObj(obj:any, index:number, isGrpField?:boolean) {
    const mmodel:MulticolModel = new MulticolModel();
    mmodel['type'] = this.constants.MULTICOL;
    if(this.appData.length) {
      const tarObj = this.appData[this.selectedIndexPgArr][index];
      if(tarObj) {
        if(!isGrpField) {
          tarObj['fieldsObj']['col'+obj['colIndex']] = obj;
        }else {
          const mcObj = tarObj['groupFields'][obj['grpRowIndex']];
          mcObj['fieldsObj']['col'+obj['colIndex']] = obj;
        }
      }
    }
  }
  /*
   * Set the data for field which is in group fields
   */
  private setGrpFieldObj(obj:any, index:number) {

    if(this.appData.length) {
      const tarObj = this.appData[this.selectedIndexPgArr][index];
      if(tarObj) {
        tarObj['groupFields'].splice(obj['grpRowIndex'], 0, obj);
      }
    }
  }

  /*
   * Delete the JSON for corresponding field to Global Array for the specified index position. \
   * Delete the column If delete needed for multicolum
   */
  deleteappData(index:number, isMultiCol?:boolean, colIndex?:number, isGrpField?:boolean, grpIndexPos?:number) {
    if(isMultiCol) {
      if(!isGrpField) {
        const multiColArr:MulticolModel = this.appData[this.selectedIndexPgArr][index];
        delete multiColArr.fieldsObj['col'+colIndex];
      }else {
        const tarObj = this.appData[this.selectedIndexPgArr][index];
        const mcObj = tarObj['groupFields'][grpIndexPos];
        delete mcObj['fieldsObj']['col'+colIndex];
      }
    }else {
      this.appData[this.selectedIndexPgArr].splice(index, 1);
    }
  }
  deleteGrpFieldappData(index:number, grpFieldIndex:number) {
    const groupFieldModel:GroupFieldModel = this.appData[this.selectedIndexPgArr][index];
    groupFieldModel.groupFields.splice(grpFieldIndex, 1);
  }

  /*
   * Delete Array element by index position
   */
  deleteAppDtByIndex(index:number) {
    this.appData.splice(index, 1);
  }

  /*
   * Get the JSON for by index position
   */
  getappData(index:number):any {
    return this.appData[this.selectedIndexPgArr][index];
  }

  /*
   * This is rearrange the index while sorting the component
   */
   appJSONRearrange(fromIndex:number, toIndex:number):void {
     const selPg = this.appData[this.selectedIndexPgArr];
     const element = selPg[fromIndex];
     selPg.splice(fromIndex, 1);
     selPg.splice(toIndex, 0, element);
     this.appData[this.selectedIndexPgArr] = selPg;
   }

 /*
  * Generate the JSON data based on dropped item
  */
 generateJSON():string {
   const _data: any = [];
   for(let i=0;i<this.appData.length;i++) {
     _data.push({field:this.appData[i].type, values:this.appData[i]});
   }
   return JSON.stringify(_data);
 }
 /*
  * Convert the appData to typed fields
  */
 convertAppData(_data):any {

   let _dataArr:any;
   this.appData = [];

   if(_data.assetId && _data.assetType) {
     this.appGlobalData.assetId = _data.assetId;
     this.appGlobalData.assetType= _data.assetType;
   }

   _dataArr = _data.pages;
   /*
   if(this.utilityService.formMode === 'Form') {

   }else { // For Section, Get the inner array to make it editable
     _dataArr = [_data.secFieldsArr];
   } */

   if(_dataArr) {
    // Insert Page Field at 1st position of each page if it's not there, ToDo delete the below 2 for loops after couple of months
    const pgIndexArr = [];
    for(let ii=0;ii<_dataArr.length;ii++) {
      for(let jj=0;jj<_dataArr[ii].length;jj++) {
        if(jj===0 && _dataArr[ii][jj].type !== this.constants.PAGE_FIELD) {
          pgIndexArr.push(ii);
        }
      }
    }
    for(let kk=0;kk<pgIndexArr.length;kk++) {
      const pageFieldModel:PageFieldModel = new PageFieldModel();
      pageFieldModel.refId = this.utilityService.timeasRefId() + kk;
      pageFieldModel.isConfirmationPage = false;
      _dataArr[pgIndexArr[kk]].splice(0, 0, pageFieldModel);
    }

    for(let i=0;i<_dataArr.length;i++) {
      _dataArr[i] = $.map( _dataArr[i] , (obj) => {
        return this.getModelClsInstance(obj);
      });
      this.appData.push(_dataArr[i]);
    }
   }

   if(_data && _data.settings) {
     this.appGlobalData.settings = _data.settings;
   }
   this.appGlobalData.pages = this.appData;
   if(this.utilityService.formMode === 'Section') {
     this.appGlobalData.type = 'secContainer';
   }
 }

 getPageCount():number {
   let dt, result;
   if(this.utilityService.formMode === 'Form') {
     dt = localStorage.getItem('formsData');
     if(dt !== '') {result = JSON.parse(dt).length;}
   }
   return result;
 }
 /*
  * This will get the JSOn data and set it to AppData array
  */
 getJSONSetAppDataArr() {
   let _dataArr;
   if(this.utilityService.formMode === 'Form') {
     _dataArr = JSON.parse(localStorage.getItem('formsData'));
   }else {
     _dataArr = JSON.parse(localStorage.getItem('sectionsData'));
   }
   if(_dataArr) {this.appData = _dataArr; };

 }
 /*
  * It will be triggered when clicking the save button
  */
 storeJSON():void {
   this.updateConditionalData();
   if(this.utilityService.formMode === 'Form') {

   }else if(this.utilityService.formMode === 'Section') {
     if(this.utilityService.appAction === 'Create') {
       return;
     }
   }
   // Set json to the parent window div
   if( window.opener && window.opener.hasOwnProperty('$')) {
     const jsonEle = window.opener.$('#editFormInput_' + this.utilityService.assetId);
     if(jsonEle.length) {
       jsonEle.val(this.utilityService.encodeJSONStringify(this.appGlobalData));
       const fw_button_text = $.trim(jsonEle.siblings().find("#addBtn_label").text());
       if(fw_button_text===this.constants.FW_CREATE_BUTTON_TEXT) {
         jsonEle.siblings().hide();
         if(jsonEle.siblings(this.constants.FW_CREATE_BUTTON_CLS).length < 1) {
           jsonEle.parent().append(this.constants.FW_CREATE_BUTTON);
         } else {
           jsonEle.siblings(this.constants.FW_CREATE_BUTTON_CLS).show();
         }
       }
     }
   }
 }

 /*
  * It will be triggered upon save a new section and editing the existing section. We need to call Ajax to save & edit a section.
  */
 createEditSectionFW(isCreate:boolean, secName:string, updateSecObj:any): Promise<any> {
   if(isCreate) {
    return this.httpService.createSection(this.appGlobalData, secName);
  }else {
    return this.httpService.updateSection(this.appGlobalData, updateSecObj);
  }
 }
 /*
  * It will remove any null properties in json, if needed...
  */
 removeJSON_null_properties(obj) {
     Object.keys(obj).forEach(key => {
      if (obj[key] && typeof obj[key] === 'object') {
        this.removeJSON_null_properties(obj[key]);
      }else if (obj[key] == null) {
        delete obj[key];
      }
    });
    return obj;
  }

 /*
  * Get the Model class based on type
  */
 getModelClsInstance(obj:any) {
   let selectedComp:any;
   switch(obj['type']) {
     case this.constants.SECTION:
         selectedComp = new SectionModel(obj);
         break;
     case this.constants.TXT_FIELD:
         selectedComp = new TextFieldModel(obj);
         break;
     case this.constants.TXT_AREA_FIELD:
         selectedComp = new TextFieldModel(obj);
         break;
     case this.constants.CHECKBOX_FIELD:
         selectedComp = new CheckboxFieldModel(obj);
         break;
     case this.constants.SELECT_FIELD:
         selectedComp = new SelectFieldModel(obj);
         break;
     case this.constants.RADIO_FIELD:
         selectedComp = new RadioFieldModel(obj);
         break;
    case this.constants.DATE_FIELD:
         selectedComp = new DateFieldModel(obj);
         break;
    case this.constants.PHONE_FIELD:
         selectedComp = new PhoneFieldModel(obj);
         break;
    case this.constants.PARAGRAPH_FIELD:
         selectedComp = new ParagraphFieldModel(obj);
         break;
   case this.constants.HEADER_FIELD:
        selectedComp = new HeaderFieldModel(obj);
        break;
    case this.constants.BUTTON_FIELD:
         selectedComp = new ButtonFieldModel(obj);
         break;
   case this.constants.MULTICOL:
        selectedComp = new MulticolModel(obj);
        break;
    case this.constants.GRIDTABLE_FIELD:
        selectedComp = new GridTableFieldModel(obj);
        break;
    case this.constants.DIVIDER:
        selectedComp = new DividerModel(obj);
        break;
    case this.constants.SEC_CONTAINER:
        selectedComp = new SecContainerModel(obj);
        break;
    case this.constants.SSN_FIELD:
        selectedComp = new SsnFieldModel(obj);
        break;
    case this.constants.GROUP_FIELD:
        selectedComp = new GroupFieldModel(obj);
        break;
    case this.constants.TITLE_FIELD:
         selectedComp = new TitleModel(obj);
        break;
    case this.constants.PAGE_FIELD:
         selectedComp = new PageFieldModel(obj);
        break;
    }

    return selectedComp;
 }
 /*
  * Compare the RefId in conditional data with globalAppSata and set the 'isConditional' property to fields if found.
  */
  setConditionalDtToFields(formBuilderChanges) {
   const pgArr:Array<any> = this.appGlobalData.pages;
   for(let k=0;k<pgArr.length;k++) {
     for(let l=0;l<pgArr[k].length;l++) {
       if((pgArr[k][l]).hasOwnProperty("buttons")) {
         const buttons = pgArr[k][l]['buttons'];
         let isButtoninCondition = false;
         for (let i = 0; i < buttons.length; i++) {
             if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],buttons[i]['buttonRefId'])) {
               isButtoninCondition=true;
             }
         }
         if(isButtoninCondition) {
           pgArr[k][l]['isConditional'] = true;
         }
       } else if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages, ['ifRefId','refId'],pgArr[k][l]['refId'])) {
         pgArr[k][l]['isConditional'] = true;
       } else {
         if(formBuilderChanges) {
           pgArr[k][l]['isConditional'] = false;
         }
       }
       if((pgArr[k][l]).hasOwnProperty("groupFields")) {
         this.checkFieldsInGroup(pgArr[k][l],formBuilderChanges);
       }

       if(pgArr[k][l].type === this.constants.SEC_CONTAINER) {
         this.checkFieldsInSection(pgArr[k][l],formBuilderChanges);
       }
       if(pgArr[k][l].type===this.constants.MULTICOL) {
         for(let m=0;m<4;m++) {
           if(typeof pgArr[k][l].fieldsObj['col'+m] !=="undefined") {
             const multiColFields = pgArr[k][l].fieldsObj['col'+m];

             if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
               multiColFields['isConditional'] = true;
             }else {
               if(formBuilderChanges) {
                 multiColFields['isConditional'] = false;
               }
             }
           }
         }
       }
       if (pgArr[k][l].type === this.constants.GRIDTABLE_FIELD) {
         let conditionInTableColumn=false;
         for(let m=0; m<pgArr[k][l].columns.length; m++) {
           let columnRefId;
           if(pgArr[k][l].columns[m].rowFieldConf.name) {
             columnRefId=pgArr[k][l].columns[m].rowFieldConf.refIdName;
           }
           if(pgArr[k][l].columns[m].rowFieldConf.radioName) {
             columnRefId=pgArr[k][l].columns[m].rowFieldConf.refIdRadioName;
           }
           if(pgArr[k][l].columns[m].rowFieldConf.textName) {
             columnRefId=pgArr[k][l].columns[m].rowFieldConf.refIdTextName;
           }

           if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],columnRefId)) {
             conditionInTableColumn = true;
           }
         }
         if(conditionInTableColumn) {
           pgArr[k][l]['isConditional'] = true;
         }else {
           if(formBuilderChanges) {
             pgArr[k][l]['isConditional'] = false;
           }
         }
       }
     }
   }
 }

 public checkFieldsInSection(section,formBuilderChanges) {
   const sectionPages = section.pages;
   for (let k = 0; k < sectionPages.length; k++) {
     const sectionField = sectionPages[k];
     for (let l = 0; l < sectionField.length; l++) {
       if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],sectionField[l]['refId'])) {
         sectionField[l]['isConditional'] = true;
       }else {
         if(formBuilderChanges) {
           sectionField[l]['isConditional'] = false;
         }
       }
       // Multi column in Group
       if(sectionField[l].type===this.constants.MULTICOL) {
         for(let m=0;m<4;m++) {
           if(typeof sectionField[l].fieldsObj['col'+m] !=="undefined") {
             const multiColFields = sectionField[l].fieldsObj['col'+m];

             if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
               multiColFields['isConditional'] = true;
             }else {
               if(formBuilderChanges) {
                 multiColFields['isConditional'] = false;
               }
             }
           }
         }
       } else if (sectionField[l].type === this.constants.GRIDTABLE_FIELD) {
         let conditionInTableColumn=false;
         for(let m=0; m<sectionField[l].columns.length; m++) {
           let columnRefId;
           if(sectionField[l].columns[m].rowFieldConf.name) {
             columnRefId=sectionField[l].columns[m].rowFieldConf.refIdName;
           }
           if(sectionField[l].columns[m].rowFieldConf.radioName) {
             columnRefId=sectionField[l].columns[m].rowFieldConf.refIdRadioName;
           }
           if(sectionField[l].columns[m].rowFieldConf.textName) {
             columnRefId=sectionField[l].columns[m].rowFieldConf.refIdTextName;
           }

           if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],columnRefId)) {
             conditionInTableColumn = true;
           }
         }
         if(conditionInTableColumn) {
           sectionField[l]['isConditional'] = true;
         }else {
           if(formBuilderChanges) {
             sectionField[l]['isConditional'] = false;
           }
         }
       } else if((sectionField[l]).hasOwnProperty("groupFields")) {
         this.checkFieldsInGroup(sectionField[l],formBuilderChanges);
       }
     }
   }
 }

 public checkFieldsInGroup(groupField,formBuilderChanges) {
   const groupFields = groupField['groupFields'];
   for (let i = 0; i < groupFields.length; i++) {
     if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],groupFields[i]['refId'])) {
       groupFields[i]['isConditional'] = true;
     }else {
       if(formBuilderChanges) {
         groupFields[i]['isConditional'] = false;
       }
     }
     // Multi column in Group
     if(groupFields[i].type===this.constants.MULTICOL) {
       for(let k=0;k<4;k++) {
         if(typeof groupFields[i].fieldsObj['col'+k] !=="undefined") {
           const multiColFields = groupFields[i].fieldsObj['col'+k];

           if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],multiColFields['refId'])) {
             multiColFields['isConditional'] = true;
           }else {
             if(formBuilderChanges) {
               multiColFields['isConditional'] = false;
             }
           }
         }
       }
     } else if (groupFields[i].type === this.constants.GRIDTABLE_FIELD) {
         let conditionInTableColumn=false;
         for(let k=0; k<groupFields[i].columns.length; k++) {
           let columnRefId;
           if(groupFields[i].columns[k].rowFieldConf.name) {
             columnRefId=groupFields[i].columns[k].rowFieldConf.refIdName;
           }
           if(groupFields[i].columns[k].rowFieldConf.radioName) {
             columnRefId=groupFields[i].columns[k].rowFieldConf.refIdRadioName;
           }
           if(groupFields[i].columns[k].rowFieldConf.textName) {
             columnRefId=groupFields[i].columns[k].rowFieldConf.refIdTextName;
           }

           if(this.utilityService.findValueInArray(this.appGlobalData.settings.pages,['ifRefId','refId'],columnRefId)) {
             conditionInTableColumn = true;
           }
         }
         if(conditionInTableColumn) {
           groupFields[i]['isConditional'] = true;
         }else {
           if(formBuilderChanges) {
             groupFields[i]['isConditional'] = false;
           }
         }
     }
   }
 }

 public updateConditions(field) {
   for(let i=0;i<this.appGlobalData.settings.pages.length;i++) {
     const conditions = this.appGlobalData.settings.pages[i];
     // Check the name, radioName and textName for Grid table field
     if(field.hasOwnProperty('columns')) {
       for(let l=0;l<field.columns.length;l++) {
         if(conditions.ifRefId === field.columns[l].rowFieldConf.refIdName) {
           conditions.if = field.columns[l].rowFieldConf.name;
         }
         if(conditions.ifRefId === field.columns[l].rowFieldConf.refIdRadioName) {
           conditions.if = field.columns[l].rowFieldConf.radioName;
           if(conditions.optionRefId && field.columns[l].hasOwnProperty('radioOptions')) {
             // conditions.value=field.columns[l]['radioOptions'][conditions.ifSelectedIndex].value;
             for(let z=0;z<field.columns[l].radioOptions.length;z++) {
               if(conditions.optionRefId === field.columns[l]['radioOptions'][z].optionRefId) {
                 conditions.value = field.columns[l]['radioOptions'][z].value;
               }
             }
           }
         }
         if(conditions.ifRefId === field.columns[l].rowFieldConf.refIdTextName) {
           conditions.if = field.columns[l].rowFieldConf.textName;
         }
       }
     } else {
       if(conditions.ifRefId === field.refId) {
         if(field['name']) {
           conditions.if = field['name'];
         }
         if(conditions.optionRefId && field.hasOwnProperty('options')) {
           // conditions.value=field['options'][conditions.ifSelectedIndex].value;
           for(let z=0;z<field.options.length;z++) {
             if(conditions.optionRefId === field['options'][z].optionRefId) {
               conditions.value = field['options'][z].value;
             }
           }
         }
       }
     }
     if(conditions.condDo) {
       for(let l=0;l<conditions.condDo.length;l++) {
         for(let m=0;m<conditions.condDo[l]['dofield'].length;m++) {
           if(field.hasOwnProperty('buttons')) {
              for(let q=0; q<field.buttons.length; q++) {
               if(conditions.condDo[l]['dofield'][m].refId === field.buttons[q].buttonRefId) {
                 conditions.condDo[l]['dofield'][m]['name'] = field.buttons[q].name;
               }
              }
           } else if(field.hasOwnProperty('columns')) {
              for(let q=0;q<field.columns.length;q++) {
                if(conditions.condDo[l]['dofield'][m].refId === field.columns[q].rowFieldConf.refIdName) {
                  conditions.condDo[l]['dofield'][m]['name'] = field.columns[q].rowFieldConf.name;
                }
                if(conditions.condDo[l]['dofield'][m].refId === field.columns[q].rowFieldConf.refIdRadioName) {
                  conditions.condDo[l]['dofield'][m]['name'] = field.columns[q].rowFieldConf.radioName;
                }
                if(conditions.condDo[l]['dofield'][m].refId === field.columns[q].rowFieldConf.refIdTextName) {
                  conditions.condDo[l]['dofield'][m]['name'] = field.columns[q].rowFieldConf.textName;
                }
              }
            } else {
              if(conditions.condDo[l]['dofield'][m].refId === field.refId) {
                // If property 'refIdIndex' found, it should be Button, SSN or Account number
                if(conditions.condDo[l]['dofield'][m].hasOwnProperty('refIdIndex')) {
                  const refIdIndex = conditions.condDo[l]['dofield'][m]['refIdIndex'];
                  // If Component is Buttton, check it inside the button array to get the corresponding nth name property
                  if(field['name'+(refIdIndex+1)]) { conditions.condDo[l]['dofield'][m]['name'] = field['name'+(refIdIndex+1)]; }
                } else { // fields except the Button, Account number and SSN fields
                  if(field.name) {
                    conditions.condDo[l]['dofield'][m]['name'] = field.name;
                  }
                }
              }
            }
         }
       }
     }
   }
 }

 /*
  * This function will generate the new refId for all fields and retuns the object with generated refIds.
  */
 public generateRefIds(values:any) {
   values['refId'] = this.utilityService.timeasRefId();
   values['isConditional'] = false;
   if(values.buttons) {
     for (let i = 0; i < values.buttons.length; i++) {
         values.buttons[i]['buttonRefId'] = this.utilityService.timeasRefId() + i;
     }
   }else if(values.columns) {
     const thisRef = this;
     for (let i = 0; i < values.columns.length; i++) {
       setTimeout(function(){ values.columns[i]['rowFieldConf']['refIdName'] = thisRef.utilityService.timeasRefId(); }, 10);
       setTimeout(function(){ values.columns[i]['rowFieldConf']['refIdRadioName'] = thisRef.utilityService.timeasRefId(); }, 10);
       setTimeout(function(){ values.columns[i]['rowFieldConf']['refIdTextName'] = thisRef.utilityService.timeasRefId(); }, 10);
     }
   }
   return values;
 }
 /*
  * This will add or update the group index position and its parent index position
  */
 public addUpdateAllIndexPos() {
   const currentPgIndex = this.selectedIndexPgArr;
   let fieldObj;
   for(let i=0;i<this.appData[currentPgIndex].length;i++) {
     fieldObj = this.appData[currentPgIndex][i];
     fieldObj['indexPos'] = i;
     if(fieldObj['type'] === this.constants.GROUP_FIELD) {
       for(let j=0;j<fieldObj['groupFields'].length;j++) {
         fieldObj['groupFields'][j]['grpRowIndex'] = j;
         fieldObj['groupFields'][j]['indexPos'] = i;
       }
     }
   }
 }

 public updateConditionalData() {
   for(let j=0;j<this.appGlobalData.pages.length;j++) {
     for(let k=0;k<this.appGlobalData.pages[j].length;k++) {
       const field = this.appGlobalData.pages[j][k];
       // For all fields
       this.updateConditions(field);

       if(field.hasOwnProperty('groupFields')) { // For Group Fields
         for(let l=0; l<Object.keys(field.groupFields).length; l++) {
           this.updateConditions(field.groupFields[l]);
         }
       } else if(field.hasOwnProperty('fieldsObj')) { // For Multi Column
         for(let l=0; l<Object.keys(field.fieldsObj).length; l++) {
           this.updateConditions(field.fieldsObj['col'+l]);
         }
       }
     }
   }
 }

 /**
  * Validation for multi column component
  * No Empty slot is allowed between two fields of Multi Column component.
  */
  public validateMultiCol():boolean {
    let isValid: boolean = true;
    let multiColComps: MulticolModel[]= [];
    for(const data of this.appGlobalData.pages) {
      const pageData: any[] = data;
      multiColComps = this.getMultiColumnComponentsFromPage(pageData);
      // Iterate through all multicol componenents and check for empty column
      multiColComps.forEach( (obj:MulticolModel, index:number) => {
        let fieldIndex:number = 0;
        // If user deletes any field in multicolumn and drops the field again then
        // the field obj order gets altered. So to avoid this sort the field objects
        const fields = this.sortMultiColFields(obj.fieldsObj);
        for(const field of fields) {
          if(fieldIndex!== field['key']) {
            isValid = false;
            break;
          }
          fieldIndex++;
        }
      });
    }
  
    return isValid;
   }
  
   private getMultiColumnComponentsFromPage(components:Array<any>): MulticolModel[] {
      let multiCols: MulticolModel[]= [];
      components.forEach(obj => {
        if(obj.type === this.constants.MULTICOL) {
          multiCols.push(obj);
        } else if(obj.type === this.constants.GROUP_FIELD) {
          this.getMultiColumnComponentsFromGroup(obj.groupFields, multiCols);
        }
      });
      return multiCols;
   }
  
   private getMultiColumnComponentsFromGroup(components:Array<any>, multiCols: MulticolModel[]): void {
    components.forEach(obj => {
      if(obj.type === this.constants.MULTICOL) {
        multiCols.push(obj);
      }
    });
   }
  
   /**
    * Sort multicolumn fields based on key value
    * @return arr { Array } - sorted array
    */
   private sortMultiColFields(fieldComponent:any):any[] {
      let arr = [];
      for (const prop in fieldComponent) {
          if (fieldComponent.hasOwnProperty(prop)) {
              arr.push({
                  'key': parseInt(prop.split('col')[1]),
                  'value': fieldComponent[prop]
              });
          }
      }
      arr.sort(function(a, b) {
          return a.key - b.key;
      });
    return arr; // returns array
   }

}
