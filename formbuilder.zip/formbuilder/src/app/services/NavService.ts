import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { Constants } from './Constants';
import { GlobalService } from './GlobalService';
import { AsideService } from './AsideService';
declare var $:any;

@Injectable()
export class NavService {
  // Observable string sources
  private loadFormSource = new Subject<any>();

  // Observable string streams
  loadForm$ = this.loadFormSource.asObservable();

  constructor(private constants:Constants, private globalService:GlobalService,
              private asideService:AsideService) {}

  // Service message commands
  loadForm(obj: any) {
    this.loadFormSource.next(obj);
  }

  onNavItemClick(clsSelector:string):void {
    const $navEle = $('ul.navbar-nav');
    $navEle.find('li.selected').removeClass('selected');
    $navEle.find('.' + clsSelector).addClass('selected');
  }

  /*
   * On clicking the 'settings' menu, Remove the drag and drop area
   */
  openSettingsPage(multicolValidModal:any):void {
    if(this.globalService.validateMultiCol()) {
      this.globalService.selPage = 'settings';
      this.globalService.selSettings = this.constants.defaultSettingsPg;
      this.onNavItemClick('settingsBtn');
      $('.dragandDropSec').hide();
      this.asideService.closeAside({});
    } else {
      multicolValidModal.showModal(this.constants.MULTICOL_PREVIEW_ERR_MSG);
    }
  }
  /*
   * On clicking the 'build' menu, shows the drag and drop area
   */
  openFormPage():void {
    this.globalService.selPage = 'dragandDrop';
    this.onNavItemClick('formBtn');
    $('.dragandDropSec').show();
  }
}
