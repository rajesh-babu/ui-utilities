import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';

@Injectable()
export class CommonsFieldsService {
  // Observable string sources
  private commonFieldSource = new Subject();
  private conditionalAssoErrorSource = new Subject();
  private duplicateGrpFieldSource = new Subject();

  // Observable string streams
  onDuplicateField$ = this.commonFieldSource.asObservable();
  onConditionalAssoError$ = this.conditionalAssoErrorSource.asObservable();
  onDuplicateGrpField$ = this.duplicateGrpFieldSource.asObservable();

  // Service message commands
  duplicateField(obj: any) {
    this.commonFieldSource.next(obj);
  }

  onConditionalAssoError(obj: any) {
    this.conditionalAssoErrorSource.next(obj);
  }

  onDuplicateGrpField(obj: any) {
    this.duplicateGrpFieldSource.next(obj);
  }

}
