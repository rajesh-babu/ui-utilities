import { Injectable } from '@angular/core';
import { SectionComponent} from '../../components/fields/section/section.component';
import { TextfieldComponent} from '../../components/fields/textfield/textfield.component';
import { CheckboxfieldComponent} from '../../components/fields/checkbox/checkboxfield.component';
import { SelectfieldComponent} from '../../components/fields/selectfield/selectfield.component';
import { RadiofieldComponent} from '../../components/fields/radiofield/radiofield.component';
import { DatefieldComponent} from '../../components/fields/datefield/datefield.component';
import { PhonefieldComponent} from '../../components/fields/phonefield/phonefield.component';
import { ButtonfieldComponent} from '../../components/fields/buttonfield/buttonfield.component';
import { ParagraphfieldComponent} from '../../components/fields/paragraphfield/paragraphfield.component';
import { HeaderfieldComponent} from '../../components/fields/headerfield/headerfield.component';
import { MulticolComponent } from '../../components/fields/multicolumn/multicol.component';
import { GridTablefieldComponent } from '../../components/fields/gridtablefield/gridtablefield.component';
import { GroupFieldComponent } from '../../components/fields/groupfield/groupfield.component';
import { DividerComponent } from '../../components/fields/divider/divider-field.component';
import { SecContainerComponent } from '../../components/fields/secContainer/secContainer.comp';
import { SsnfieldComponent} from '../../components/fields/ssnfield/ssnfield.component';
import { TitleComponent} from '../../components/fields/titlefield/title-field.component';
import { PageFieldComponent} from '../../components/fields/pagefield/pagefield.component';

import { Constants } from '../Constants';

@Injectable()
export class FieldsFactoryService {
  constructor(private constants:Constants) {}
   public getComponent(fieldName: string) {
     const selectedComp = {};
     switch(fieldName) {
       case this.constants.MULTICOL:
           selectedComp['type'] = MulticolComponent;
           break;
       case this.constants.SECTION:
           selectedComp['type'] = SectionComponent;
           break;
       case this.constants.TXT_FIELD:
           selectedComp['type'] = TextfieldComponent;
           break;
       case this.constants.TXT_AREA_FIELD:
           selectedComp['type'] = TextfieldComponent;
           selectedComp['subType'] = TextfieldComponent;
           break;
       case this.constants.CHECKBOX_FIELD:
           selectedComp['type'] = CheckboxfieldComponent;
           break;
       case this.constants.SELECT_FIELD:
           selectedComp['type'] = SelectfieldComponent;
           break;
       case this.constants.RADIO_FIELD:
           selectedComp['type'] = RadiofieldComponent;
           break;
      case this.constants.DATE_FIELD:
           selectedComp['type'] = DatefieldComponent;
           break;
      case this.constants.PHONE_FIELD:
           selectedComp['type'] = PhonefieldComponent;
           break;
      case this.constants.PARAGRAPH_FIELD:
           selectedComp['type'] = ParagraphfieldComponent;
           break;
     case this.constants.HEADER_FIELD:
           selectedComp['type'] = HeaderfieldComponent;
           break;
      case this.constants.BUTTON_FIELD:
           selectedComp['type'] = ButtonfieldComponent;
           break;
      case this.constants.GRIDTABLE_FIELD:
           selectedComp['type'] = GridTablefieldComponent;
           break;
     case this.constants.GROUP_FIELD:
          selectedComp['type'] = GroupFieldComponent;
          break;
      case this.constants.DIVIDER:
           selectedComp['type'] = DividerComponent;
           break;
      case this.constants.SEC_CONTAINER:
           selectedComp['type'] = SecContainerComponent;
          break;
      case this.constants.SSN_FIELD:
           selectedComp['type'] = SsnfieldComponent;
          break;
      case this.constants.TITLE_FIELD:
           selectedComp['type'] = TitleComponent;
          break;
      case this.constants.PAGE_FIELD:
           selectedComp['type'] = PageFieldComponent;
          break;
     }
     return selectedComp;
   }
}
