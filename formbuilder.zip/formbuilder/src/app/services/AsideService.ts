import { Injectable } from '@angular/core';
import { Subject } from 'rxjs/Subject';
declare var $:any;
@Injectable()
export class AsideService {
  // Observable string sources
  private asideSource = new Subject<any>();
  private asideCloseSource = new Subject<Boolean>();
  private asideAccordionSource = new Subject<any>();
  private updateViewSource = new Subject<any>();

  // Observable string streams
  asideOpen$ = this.asideSource.asObservable();
  asideClose$ = this.asideCloseSource.asObservable();
  asideAccordion$ = this.asideAccordionSource.asObservable();
  updateView$ = this.updateViewSource.asObservable();

  // Service message commands
  openAside(obj: any) {
    this.asideSource.next(obj);
    this.initAccordion(0);
  }
  closeAside(obj: any) {
    this.asideCloseSource.next(obj);
  }
  initAccordion(index) {
    this.asideAccordionSource.next(index);
  }
  destroyAccordion() {
    if($(".accordion-component").hasClass("ui-accordion")) {
      $(".accordion-component").accordion("destroy");
    }
  }
  updateView() {
    this.updateViewSource.next();
  }
}
