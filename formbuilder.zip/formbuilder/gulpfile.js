"use strict";

// Configuration
var pkg = require('./package.json');
var jsonModify = require('gulp-json-modify');
var gulpPrompt = require('gulp-prompt');
var config = pkg.buildConfig;

// References
var gulp = require('gulp');
var gulpHeader = require('gulp-header');

// Default
gulp.task("default",  function(){
  gulp.start('generateTimeStamp');
});

// Generate the TimeStamp
gulp.task("generateTimeStamp", function(cb){
  var d = new Date();
  var headerComment = '/* Fatwire Form Builder, Branch: ' +config.branch+', Version: '+ pkg.version+', Generated on: ' + d + ' */ ';
  gulp.src(config.destPath + '*.{js,css}')
    .pipe(gulpHeader(headerComment))
    .pipe(gulp.dest(config.destPath));
});

// This task will be triggered from package.json when executing the 'npm run build'
gulp.task('getBuildDetails', function(cb){
  gulp.src('gulpfile.js')
  	.pipe(gulpPrompt.prompt([{
  		type: 'input',
  		name: 'branch',
  		message: 'Please provide the Branch name (Ex."2017-10")?'
  	},
  	{
  		type: 'input',
  		name: 'version',
  		message: 'Please provide the Version No (Ex."17.10.1")?'
  	}], function(res){
      gulp.src([ './package.json' ])
        .pipe(jsonModify({
          key: 'buildConfig.branch',
          value: res.branch
        }))
        .pipe(jsonModify({
          key: 'version',
          value: res.version
        }))
        .pipe(gulp.dest('./'));
      cb();
  	}));
});
