"use strict";

// Configuration
var pkg = require('./package.json');
var config = pkg.buildConfig;

// References
var gulp = require('gulp');
var gulpSequence = require('gulp-sequence');
var del = require('del');
var path = require("path");
var gulpHeader = require('gulp-header');
var rjs = require('requirejs');
var browserSync = require('browser-sync');
var merge = require('merge-stream');
var concat = require('gulp-concat');
var sourcemaps = require('gulp-sourcemaps');
var versionNo = pkg.version;
var initHeader;

// Default
gulp.task("default", function(cb){

  gulp.watch('./src/**/*.js', { interval: 500 },
    [ 'build-form-output', browserSync.reload]);
    gulpSequence('build-footer-js', 'build-header-js', cb);
});

gulp.task("build-form-output", function(cb){
  gulpSequence('build-footer-js', cb);
});

// When session starts
gulp.task("session-start", function(cb) {
	gulpSequence('build', 'browser-sync', cb);
});

// Browser-sync
gulp.task('browser-sync', function() {
  return browserSync({
    server: {
      baseDir: './dist/form-output',
      directory: true
    }
  });
});
// Default
gulp.task('build', function(cb){
  setTimeout(function () {
        gulpSequence(
		    ['clean-all'],
		    ['build-footer-js'],
		    cb);
    }, 500);

});

// Deploy build
gulp.task('build-deploy', function(cb){
  gulpSequence(
    ['clean-all'],
    'build-footer-js-deploy',
    cb);
});

// Clean up tasks
gulp.task('clean-all', function(cb) { del(['./dist/form-output/**/*.*'], cb); });

// Generate header JS. Header JS files should be minified in advance so only concat files together
gulp.task('build-header-js', function() {
  var data = config.headerJS;
  var files = data.files;
  var streams = [];
  for (var d=0;d<files.length;d++) {
    streams.push(gulp.src(files[d], { cwd: path.resolve(data.basePath) }));
  }

  var d = new Date();
  var headerComment = '/* Generated on: ' + d + ' */';
  return merge(streams)
    .pipe(concat(data.outputFile))
    .pipe(gulpHeader(headerComment))
    .pipe(gulp.dest(config.destPath));
});


// Generate footer js from AMD
gulp.task('build-footer-js', function(done) {
  var data = config.footerJS;

  rjs.optimize({
    "mainConfigFile": path.join(config.basePath,data.configFile+'.js'),
    "baseUrl": path.resolve(config.basePath),
    "name": data.almondFile,
    "include": [ data.configFile],
    "wrap": true,
    "out": path.join(config.destPath, data.outputFile),
    "optimize": "none",
    "generateSourceMaps": true,
    "preserveLicenseComments": false,
    "wrapShim": false,
    "normalizeDirDefines": 'skip',
    "skipDirOptimize": false
  }, function () {
    var d = new Date();
    var headerComment = '/* Version: '+ pkg.version+', Generated on: ' + d + ' */';
    var stream = gulp.src(path.join(config.destPath, data.outputFile))
      .pipe(gulpHeader(headerComment))
      .pipe(gulp.dest(config.destPath ));
    stream.on('end',function(){ done(); });
  }, done);
});

// Generate footer js from AMD and minify for deploy
gulp.task('build-footer-js-deploy', function(done) {
  var data = config.footerJS;

  rjs.optimize({
    "mainConfigFile": path.join(config.basePath,data.configFile+'.js'),
    "baseUrl": path.resolve(config.basePath),
    "name": data.almondFile,
    "include": [ data.configFile],
    "wrap": true,
    "out": path.join(config.destPath, data.outputFile),
    "optimize": "uglify",
    "generateSourceMaps": false,
    "preserveLicenseComments": false,
    "wrapShim": false,
    "normalizeDirDefines": 'skip',
    "skipDirOptimize": false
  }, function () {
    var d = new Date();
    var headerComment = '/*  Version: ' + versionNo + ', Generated on: ' + d + ' */';
    var stream = gulp.src(path.join(config.destPath, data.outputFile))
      .pipe(gulpHeader(headerComment))
      .pipe(gulp.dest(config.destPath));
    stream.on('end',function(){ done(); });
  }, done);
});




/*
// Generate CSS from SASS
gulp.task('build-css', function() {
  var data = config.globalCSS;
  var patterns = data.patterns;
  var streams = [];
  var d = new Date();
  var headerComment = '// Generated on: ' + d + ' ';
  for (var d=0;d<patterns.length;d++) {
    streams.push(
      gulp.src(patterns[d], { cwd: path.resolve(config.basePath) })
        .pipe(sourcemaps.init())
        .pipe(concat(data.outputFile))
    );
  }
  return merge(streams)
    .pipe(concat(data.outputFile))
    .pipe(sass({
        errLogToConsole: true,
        includePaths : [
            config.basePath + '/tiaa-web-vendor-bootstrap/assets/scss'
        ]
    }))
    .pipe(sourcemaps.write())
    .pipe(gulpHeader(headerComment))
    .pipe(gulp.dest(config.destPath + data.dest));
});


*/