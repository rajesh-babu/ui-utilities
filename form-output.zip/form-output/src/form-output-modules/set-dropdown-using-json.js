/**
 * Set Drop down using the JSON, dataSourceReference, Filter Condition and Settings data
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 */
define(['jquery', 'Constants'], function($, constants) {

  var COMMON_SET_DROPDOWN_JSON = {
    // Defaults
    defaults: {

    },

    /*
     * Public API - Set the Dropdown options based on 'dataSourceReference' property using the given JSON
     *
     */
     setDefaultDropDownUsingJSON : function() {
       var my = this;
       if(constants.appGlobalData && constants.appGlobalData.settings.hasOwnProperty('regexData') && constants.appGlobalData.settings.regexData.items.length){
         for(var i=0;i<constants.appGlobalData.settings.regexData.items.length;i++) {
           var $tarEle= $('.' + constants.appGlobalData.settings.regexData.items[i].name),
             stringWithDots = constants.appGlobalData.settings.regexData.items[i].dataSourceReference,
             dataSourceReferenceVar = constants.appGlobalData.settings.regexData.items[i].dataSourceReferenceVar;

           if(stringWithDots){
             var propArr = stringWithDots.split('.');

             // Get the property name
             var fieldName = propArr[propArr.length-1];

             // Don't set the drop down value if user doesn't give 'dataSourceReference' in form builder
             if(fieldName !== null && window[dataSourceReferenceVar]) {

               // As per requirement, Get the first value of array and set it to hidden element If target element is hidden.
               if($tarEle.attr('type') ==='hidden') {
                 if(window[dataSourceReferenceVar].length) {
                   if($tarEle.val() === ''){ $tarEle.val(window[dataSourceReferenceVar][0]); }
                 }
               }else {
                 for(var j=0;j<window[dataSourceReferenceVar].length;j++) {
                     if(window[dataSourceReferenceVar][j][fieldName]) {
                       $tarEle.append('<option value="'+window[dataSourceReferenceVar][j][fieldName]+'">'+window[dataSourceReferenceVar][j][fieldName]+'</option>');
                     }else{

                       // If no 'fieldName' property means, it's a plain array
                       $tarEle.append('<option value="'+window[dataSourceReferenceVar][j]+'">'+window[dataSourceReferenceVar][j]+'</option>');
                     }
                 }
               }
             }
           }
         }
       }
    }
  };
  return COMMON_SET_DROPDOWN_JSON;
});
