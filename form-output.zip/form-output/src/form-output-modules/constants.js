/**
 * form-output Constants
 * @name Constants
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 * Add child classes as dependencies
 */
define(['jquery'],function($) {

  /*
   * Get the JSON which Form builder App generated
   */
  var val = $('#formBuilderOutput').val();
  function getGlobaldata() {
    if(val) {
      return JSON.parse(val);
    }
  }
  /*
  * Get the Contract Info JSON
  */
 var contractInfoJson = [];
 if(window.contractInfoJSON){
    contractInfoJson = JSON.parse(window.contractInfoJSON);
 }
 function getContractInfoJSON() {
   if(!contractInfoJson.hasOwnProperty('Parents') || contractInfoJson.Parents.length === 0){
     contractInfoJson.Parents = [];
   }
   return contractInfoJson;
 }

   // Public APIs
  return {
    appGlobalData:                    getGlobaldata(),
    contractInfoJSON:                 getContractInfoJSON(),
    enable:                           'enable',
    disable:                          'disable',
    disabled:                         'disabled',
    show:                             'show',
    hide:                             'hide',
    set:                              'set',
    dostate:                          'dostate',
    state:                            'condState',
    dofield:                          'dofield',
    equals:                           'equals',
    closedCls:                        'closed',
    hasparentAttr:                    'data-hasparent',
    parentClsName:                    'lblFieldPair',
    parentDivSelector:                '.lblFieldPair',
    iwcParentClsName:                 'row',
    require:                          'require',
    requireOr:                        'requireOr',
    dataValidationOrAttr:             'data-validation-or',
    unrequire:                        'unrequire',
    isFilled:                         'isFilled',
    isEmpty:                          'isEmpty',
    skipPage:                         'skip-page',
    resetStateAttr:                   'data-reset-state',
    dataFormatAttr:                   'data-dateformat',
    dataRequiredAttr:                 'data-required',
    dataRuleRequiredAttr:             'data-rule-required',
    dataValidationAttr:               'data-validation',
    dataMinAttr:                      'data-min',
    dataMaxAttr:                      'data-max',
    dataMinValAttr:                   'data-minval',
    dataMaxValAttr:                   'data-maxval',
    dataMinEntryAttr:                 'data-min-entry',
    dataMaxEntryAttr:                 'data-max-entry',
    dataErrAttr:                      'data-errmsg',
    requiredAsteriskEle:              '<span class="required w10">*</span>',
    requiredErrMsg:                   'Please enter value for ',
    nonumbervalidationErrMsg:         'Please enter only letters for ',
    alphaapostropheErrMsg:            'Please enter only letters and apostrophe for ',
    alphahyphenErrMsg:                'Please enter only letters and hyphen for ',
    alphanumericErrMsg:               'Please enter only letters and digits for ',
    alphasplexpErrMsg:                'Please enter only letters and/or special characters for ',
    alphaaposperiodErrMsg:            'Please enter only letters, apostrophe and period for ',
    alphahyphenspaErrMsg:             'Please enter only letters, space and/or hyphen for ',
    alphanumericapostropheErrMsg:     'Please enter only letters, digits and apostrophe for ',
    alphanumerichyphenErrMsg:         'Please enter only letters, digits and hyphen for ',
    alphanumericsplexpErrMsg:         'Please enter only letters, digits and special character for ',
    currencyvalidationErrMsg:         'Please enter only digits or decimal point or comma or hyphen or parenthesis for ',
    decimalvalidationErrMsg:          'Please enter only digits and decimal point for ',
    numerichyphenErrMsg:              'Please enter only digits and hyphen for ',
    validErrMsg:                      'Please enter valid ',
    numbervalidationErrMsg:           'Please enter only digits for ',
    lengthValidationErrMsg:           'Please enter {{l}} digits for ',
    dateValidationErrMsg:             'Please enter valid date in MM/DD/YYYY format for ',
    dateValidationDDMMYYYYErrMsg:     'Please enter valid date in DD/MM/YYYY format for ',
    dateValidationYYYYMMDDErrMsg:     'Please enter valid date in YYYY/MM/DD format for ',
    dateValidationMMYYYYErrMsg:       'Please enter valid date in MM/YYYY format for ',
    futureDateErrMsg:                 'Please enter only future date for ',
    futureAndTodayDateErrMsg:         'Please enter current or future date for ',
    prevAndTodayDateErrMsg:           'Please enter current or previous date for ',
    prevDateErrMsg:                   'Please enter only previous date for ',
    minLengthErrMsg:                  'Please enter minimum ',
    minValueErrMsg:                   ' value cannot be less than ',
    maxValueErrMsg:                   ' value cannot exceed   ',
    minEntryErrMsg:                   'Please select minimum ',
    maxEntryErrMsg:                   'Please select maximum ',
    stateChange:                      'change',
    plansTableBalanceClsName:         'plansTableBalance',
    plansTableClsName:                'plansTable', // It should match with Form builder - Grid table's table type drop down value
    IAPlansTableClsName:              'IAPlansTable', // It should match with Form builder - Grid table's table type drop down value
    ITDPlansTableClsName:             'ITDPlansTable',// It should match with Form builder - Grid table's table type drop down value
    RetirementPlansTableClsName:      'RetirementPlansTable',// It should match with Form builder - Grid table's table type drop down value
    noPlansClsName:                   'noPlans',
    iwcMinLengthErrMsg:               'Minimum characters ',
    iwcMinValueErrMsg:                'Minimum value ',
    iwcMaxValueErrMsg:                'Maximum value ',
    iwcRequiredErrMsg:                'This field is required',
    iwcNoNumberErrMsg:                'Enter only alphabets',
    iwcAlphaapostropheErrMsg:         'Enter only letters and apostrophe',
    iwcAlphahyphenErrMsg:             'Enter only letters and hyphen',
    iwcAlphanumericErrMsg:            'Enter only letters and digits',
    iwcAlphasplexpErrMsg:             'Enter only letters and/or special characters',
    iwcAlphaaposperiodErrMsg:         'Enter only letters, apostrophe and period',
    iwcAlphahyphenspaErrMsg:          'Enter only letters, space and/or hyphen',
    iwcAlphanumericapostropheErrMsg:  'Enter only letters, digits and apostrophe',
    iwcAlphanumerichyphenErrMsg:      'Enter only letters, digits and hyphen',
    iwcAlphanumericsplexpErrMsg:      'Enter only letters, digits and special character',
    iwcCurrencyvalidationErrMsg:      'Enter only digits or decimal point or comma or hyphen or parenthesis',
    iwcDecimalvalidationErrMsg:       'Enter only digits and decimal point',
    iwcNumerichyphenErrMsg:           'Enter only digits and hyphen',
    iwcDateValidationErrMsg:          'Enter valid date in MM/DD/YYYY format',
    iwcFutureDateErrMsg:              'Enter only future date',
    iwcFutureAndTodayDateErrMsg:      'Enter current or future date ',
    iwcPrevAndTodayDateErrMsg:        'Enter current or previous date',
    iwcPrevDateErrMsg:                'Enter only previous date',
    iwcValidErrMsg:                   'Not valid ',
    iwcNumbervalidationErrMsg:        'Enter only digits',
    iwcLengthValidationErrMsg:        'Enter {{l}} digits',
    iwcSsnLengthValidationErrMsg:     'Enter 11 digits',
    iwcGetLoanDetailsForPlansURL:     '/private/formsfactory/getloandetailsforplans',
    udGetLoanDetailsForPlansURL:      '/ud/formsfactory/getloandetailsforplans'
  }
});
