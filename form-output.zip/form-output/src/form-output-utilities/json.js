/**
 * form-output  Utilities - JSON
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 */
define(function() {

  // Component
  return {

    // Methods

    /**
     * Get the Array or Object using the given String Dot notation
     * @function
     * @return {object or Array} name value pairs
     */
    convertStrDotToJSON: function(s) {
      s = s.replace(/\[(\w+)\]/g, '.$1'); // convert indexes to properties
      var a = s.split('.'), result;
      if(window[a[0]]){
        result = JSON.parse(window[a[0]]);
        for (var i = 1, n = a.length-1; i < n; ++i) {
            var k = a[i];
            if (result && k in result) {
                result = result[k];
            } else {
                return;
            }
        }
      }
      return result;
    }
  }
});
