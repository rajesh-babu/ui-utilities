/**
 * Javascript code related to Formatting the text or number
 * @name public-fw-formatting
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 */
define(function() {

  // Component
  return {

    /**
     * This function will format the phone number
     * @function
     * @param {String} oldValue
     * @returns {String} formatted string
     */
    formatPhoneNumber: function(oldValue) {
      var formattedPhonNumber = '',
        phoneNumber;

      // Removing non numeric characters
      oldValue = oldValue.replace(/\D/g, '');

      // If number starts with 1, we consider that as country code. Removing first character and starting the formatted number with (1)
      if (oldValue.charAt(0) === '1') {
        oldValue = oldValue.slice(1);
        formattedPhonNumber = '(1) ';
      }

      // If number is more than 10 characters, we are splitting first 10 chars as number and others as extn.Else we will take entire vale as single number
     phoneNumber = (oldValue.length > 10) ? oldValue.substring(0, 10) : oldValue;

      // Adding - after three characters for phone number formatting and return formatted phone number
      return formattedPhonNumber + phoneNumber.substring(0, 3) + '-' + phoneNumber.substring(3, 6) + '-' + phoneNumber.substring(6);
    }
  };
});
