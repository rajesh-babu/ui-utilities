/**
 * Add child classes as dependencies
 */
define(['utilities/web', 'utilities/formatting', 'utilities/json', 'utilities/object'],function(_web, _format, _json, _object) {
   // Component
  return {

    // Classes
    web: _web,
    formatting: _format,
    json: _json,
    object:_object
  }
});
