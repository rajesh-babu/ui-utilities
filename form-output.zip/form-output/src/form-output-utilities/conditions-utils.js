/**
 * Conditions - Utils
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery'],function($) {

    /*
     * Determine the conditional operator based the input JSON
     */
    function _dynamicOperator(name,operator, value) {
      switch (operator) {
        case '===': return name === value;
        case '!==': return name !== value;
      }
    }

   // Public APIs
  return {
    dynamicOperator:  _dynamicOperator
  };
});
