define(function() {

  // Component
  return {

    // Methods

    /**
     * Parse the URL for vars
     * @function
     * @return {object} name value pairs
     */
    getUrlVars: function() {
      var vars = [],
        hash;
      var hashes = window.location.search.substring(1).split('&');
      for (var i = 0; i < hashes.length; i++) {
        hash = hashes[i].split('=');
        vars.push(hash[0]);
        vars[hash[0]] = hash[1];
      }
      return vars;
    },

     /**
     * Get URL Query string parameters
     * @param { string } name parameter key
     * @param { string } url URL
     * @return { string } parameter value
     */
    getParameterByName: function(name, url) {
      if (!url) url = window.location.href;
      name = name.replace(/[\[\]]/g, "\\$&");
      var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
          results = regex.exec(url);
      if (!results) return null;
      if (!results[2]) return '';
      return decodeURIComponent(results[2].replace(/\+/g, " "));
    }

  }

});
