/**
 * form-output Javascript code related to Object Utilities
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 */
define(function() {
    
      // Component
      return {
    
        /**
         * This function will check the existence of nested properties and return the value
         * @param {Object, String} 
         * @returns {value} 
         */
        getNestedObject: function(obj, key) {
            return key.split(".").reduce(function(o, x) {
                return (typeof o == "undefined" || o === null) ? o : o[x];
            }, obj);
        }
      };
    });
    