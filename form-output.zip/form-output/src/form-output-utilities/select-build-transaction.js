define(['jquery', 'utilities/web-url'], function($, _webUrl) {

    var BUILD_TRANSACTIONS = {

        bundleDataJson: null,  // List of forms present in the transaction bundle
        bundleFormHtmlMapJSON: null, 
        action: '',

        defaults: {
           trxnBundleCount: '.bundleCount',
           capapbilityFilterEle: '#dashboardTableId #selTransCapability',
           successAlertMessage: '.successModule,.noticeModule',
           bundleAddedFilterMsg: '.noticeModule.bundleAddedFilter',
           addedToBundleAlertMsg: '.successModule.bundleAdded'

        },

          // Initialize
        init: function(elem, options, i) {
            var my = this;
            my.options = $.extend({}, my.defaults, options);
            if(typeof(bundleDataJson) != 'undefined') {
                my.bundleDataJson  = bundleDataJson ;
                this.setBundleForms();
                this.setCapabilityFilter();
            }

            if (typeof(bundleFormHtmlMapJSON) !== 'undefined') {
                my.bundleFormHtmlMapJSON = bundleFormHtmlMapJSON;

                if (my.bundleFormHtmlMapJSON !== null && my.bundleFormHtmlMapJSON !== '') {
                    my.action = my.bundleFormHtmlMapJSON['Action'] && my.bundleFormHtmlMapJSON['Action'][0];
                    my.showBundleMessage();
                }
            }
            this.attachEvents();
        },

        setBundleForms: function() {
            var my = this;
            var bundleCount = my.bundleDataJson.length;
            if (my.bundleDataJson && bundleCount >= 0) {
               // Update transaction bundle count
               $(my.defaults.trxnBundleCount).text(bundleCount);

               // Add * on bundled forms
               if (typeof(dashboardTableSort) !== 'undefined' && dashboardTableSort.sortTable.length > 0) {
                    my.bundleDataJson.forEach(function(form) {
                        dashboardTableSort.sortTable.map(function(row) {
                           if (form.formId && (row[0] === form.formId)) {
                                $('#'+row[0]).find('td:first').attr('data-sortvalue', row[0] + ' (*)');
                                $('#'+row[0]).find('td:first').html(row[0] + ' (*)');
                                row[0] = row[0] + '(*)';
                           }
                           return row;
                        });
                    });
               }
            } else {
                my.disableElements();
            }
        },

        /**
         * Set Capapbility Filter if there are forms present in the
         * transaction bundle and set the filter if user is navigating from Add another button 
         * from the bundle transaction page (view: txnbundle)
         */
        setCapabilityFilter: function() {
            var my = this;
            var bundleCount = my.bundleDataJson.length;
            var view = _webUrl.getParameterByName('view', window.location.href);
            if (bundleCount > 0 || view === 'txnbundle') {
                var capabilityEle$ = $(my.defaults.capapbilityFilterEle);
                if (capabilityEle$.length > 0) {
                    $(my.defaults.capapbilityFilterEle).val('+').trigger('change');
                }

                my.showMessage();
            }
        },

        attachEvents: function() {
            var my = this, closeBtn$;
            closeBtn$ = $(my.defaults.successAlertMessage).find('.closeLink');
            if(closeBtn$.length) {
                $(my.defaults.successAlertMessage).find('.closeLink').bind('click', function() {
                    $(this).parent().removeClass('visible')
                                    .addClass('hidden');        
                });
            }
        },

        /**
         * Display message when 'Add another' button is clicked from the bundle
         * transaction page
         */
        showMessage: function() {
           var my = this, bundleAddedFilter$;
           bundleAddedFilter$ = $(my.defaults.bundleAddedFilterMsg);
           bundleAddedFilter$.removeClass('hidden')
                                              .addClass('visible');
           bundleAddedFilter$.find('#clearFilter').bind('click', function() {
            $(bundleAddedFilter$).addClass('hidden').removeClass('visible');
            $(my.defaults.capapbilityFilterEle).val('').trigger('change');
           });
        },

        /**
         * Display message when 'Bundle & Add another' button is clicked from the
         * form-output 
         */
        showBundleMessage: function() {
            var my = this, addedToBundleAlertMsg$, formName = '';
            addedToBundleAlertMsg$ =  $(my.defaults.addedToBundleAlertMsg);
            if (my.action && (my.action === 'bundleaddanother' || my.action == 'savebundleaddanother')) {
                formName = my.bundleFormHtmlMapJSON['DisplayFormName'];
                $(addedToBundleAlertMsg$).find('.successFormName').html(formName[0]);
                $(addedToBundleAlertMsg$).removeClass('hidden')
                                                  .addClass('visible');
                // Display Notice message
                my.showMessage();
            }

        },

        /**
         * Disable elements if bundle is empty
         */
        disableElements: function() {
            var my = this;
            $(my.defaults.trxnBundleCount).parent().attr('href', 'javascript:void(0);');
        }

    };


    return BUILD_TRANSACTIONS;


});