define(['utilities/web-cookie', 'utilities/web-url','utilities/web-ajax'],
  function(_cookie, _url, _ajax) {

     // Component
    return {

      // Classes
      cookie: _cookie,
      url: _url,
      ajax: _ajax

    };

  }
);
