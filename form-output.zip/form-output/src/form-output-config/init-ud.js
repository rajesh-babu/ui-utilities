/**
 * JS loader specifications
 * @requires attachJQ_Public, jquery and public JS
 * @return attachJQ_Public, jquery and public JS
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 */
 (function(){
   $(function(){
     $(window).load(function(){ this._dffCommonsLoaded=true; });
   });
 })(jQuery);
define('jquery', function(){
  return jQuery;
});
// Load all libraries
require([
  'attachJQ_FO',
  'Constants',
  'jquery',
  'dffUD',
  'utilities/main'
  ], function(
    attachJQ_FO,
    Constants,
    jquery,
    dffUD,
    utilities
  ) {
    // Attach functions
    var $window = $(window);
    var $document = $(document);
    var $body = $('body');
    window.fw = utilities;

    // Attach regular components to DOM elements
    // This may be called again if code injection happens
    function attachJQComponents(){
      $document.attachJQ_FO(dffUD, 'dffUD');
    }
    attachJQComponents();
    // Fire any functions that need a window.load event
    // Because of how require.js works, window.load may have
    // already fired, so this makes sure those setup steps
    // can happen
    function loadReady() {
      $window.trigger('dffCommonsLoaded');
    }
    if (window._dffCommonsLoaded) loadReady();
    else $(window).load(loadReady);
  }
);
