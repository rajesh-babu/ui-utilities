/**
 * JS lists
 * @requires Path of all modules
 * @contrib Rajesh Thoghuluvasd
 * @version 1.0.0
 */
// Configurations
require.config({
  baseUrl: './src',

  paths: {
    // Vendor libraries
    // Internal libraries
    'attachJQ_FO':                          'form-output-config/attachJQ_FO',
    'Constants':                            'form-output-modules/constants',
    'conditions':                           'dff-ud/conditions',
    'conditionsActions':                    'dff-ud/conditions-actions',
    'conditionsCheckboxRadio':              'dff-ud/conditions-checkbox-radio',
    'conditionsDropdowns':                  'dff-ud/conditions-dropdowns',
    'conditionsTextbox':                    'dff-ud/conditions-textbox',
    'clearActions':                         'dff-ud/clear-actions',
    'previewSection':                       'dff-ud/preview-section',
    'validationActions':                    'dff-ud/validations/validation-actions',
    'setDefault':                           'dff-ud/set-default',
    'attributeValidation':                  'dff-ud/validations/attribute-validation',
    'phoneValidation':                      'dff-ud/validations/phone-validation',
    'dateValidation':                       'dff-ud/validations/date-validation',
    'dropDownUsingJSON':                    'dff-ud/set-dropdown-using-json',
    'errorMsgUtilities':                    'dff-ud/validations/error-message-utilities',
    'jquery':                               'empty:',
    'dffUD':                                'dff-ud/dff-ud',
    'commonsDropDownModule':                'form-output-modules/set-dropdown-using-json',
    'utilities':                            'form-output-utilities',
    'conditionsUtils':                      'form-output-utilities/conditions-utils'
  },
  // Wrap non-AMD libraries
  shim: {

  },
  map: {
      '*': {
        css: '../node_modules/require-css/css'
      }
  },
  // Load init
  /*START-UPDATE DEPS HERE BY GULP*/deps: [ 'form-output-config/init-ud.js' ]/*END UPDATE DEPS HERE BY GULP*/

});
