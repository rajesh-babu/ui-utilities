/**
 * Conditions - Checkbox and Radio Actions
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants','conditionsActions'],function($, constants, _conditionsActions) {

  var CONDITIONS_CHECKRADIO = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },
    /*
     * Public API - Listener for Radio and Checkboxes
     */
     handleCheckandRadio: function(conditions){
      var my = this;
      $('input[type=radio],input[type=checkbox]').on('change', function(e) {
        if($(this).is(":checked")) {
          my._doCheckedActions(conditions, $(this) );
        }
      });
    },
    /*
     * Action for Radio and Checkboxes
     */
    _doCheckedActions: function(conditions, srcEle$) {
      var namePostfixArr = srcEle$.attr('name').split('__');
      var namePostfix = (namePostfixArr.length >1) ? ('__'+namePostfixArr[1]) : '';
      var conditionMet=false;

        for(var i=0;i<conditions.length;i++) {
          if((conditions[i]['condIf'] + namePostfix) === srcEle$.attr('name')) {

            // if STATE is equal to - conditions value and selected value should be same
            // if STATE is NOT equal to - conditions value and selected value should NOT be same
            conditionMet=false;
            if(conditions[i][constants.state] === constants.equals) {
              if(conditions[i]['value'] === srcEle$.attr('value')){
                conditionMet=true;
              }
            } else if(conditions[i][constants.state] !== constants.equals) {
              if(conditions[i]['value'] !== srcEle$.attr('value')){
                conditionMet=true;
              }
            }
            if(conditionMet) {
              for(var j=0;j<conditions[i]['condDo'].length;j++) {
                var op = conditions[i]['condDo'][j];
                for(var k=0;k<op[constants.dofield].length;k++) {
                    var tarEle$;
                    if(op[constants.dofield][k].type === 'pagefield') {
                      tarEle$ = $('.ref-id-' + op[constants.dofield][k].refId);
                    } else if(op[constants.dofield][k].type === 'secContainer') {
                      if($('.one_third').find('.' + op[constants.dofield][k].name + namePostfix).length > 0) {
                        tarEle$ = $('.one_third').find('.' + op[constants.dofield][k].name + namePostfix)
                      }
                    } else {
                      tarEle$ = $('.' + op[constants.dofield][k].name + namePostfix)
                    }
                    if(tarEle$.length > 0){
                    switch(op[constants.dostate]) {
                      case constants.enable:
                      case constants.disable:
                        _conditionsActions.enableDisableFields(conditions[i][constants.state], op[constants.dostate], tarEle$);
                        break;
                      case constants.show:
                      case constants.hide:
                        _conditionsActions.showHideFields(conditions[i][constants.state], op[constants.dostate], tarEle$,op[constants.dofield][k].type);
                        break;
                      case constants.require:
                      case constants.unrequire:
                        _conditionsActions.requireUnrequireFields(conditions[i][constants.state], op[constants.dostate], tarEle$);
                        break;
                    }
                  }
                }
              }
            }
          }
        }
      }
 };
  return CONDITIONS_CHECKRADIO;
});
