/**
 * Clear link - Actions
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants'],function($, constants) {

  var CLEAR_ACTIONS = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    /*
     * Public API - Reset the sibling elements
     */
     clearAction: function() {
       var my = this;

      // Get the 'Clear' link element
      $('a.clear').on('click', function(){

        //Iterate the previous sibling elements
        $(this).parent().prevAll().each(function() {

          // Skip the loop once you reached the element with class '.bsep'
          if($(this).hasClass('bsep')) { return false; }

          // Find the radio and checkboxes and reset it.
          $(this).find('input[type=radio],input[type=checkbox]').not(':disabled').prop('checked', false);

          // Reset all Text fields
          $(this).find('input[type=text]').not(':disabled').val('');

          //Reset all Select fields
          var $selectEle = $(this).find('select').not(':disabled');
          $selectEle.val($selectEle.find('option:first').val()).change();

          // Remove fields with class 'retAccHiddenInp', except total-selected. Reset value of total-selected to zero
          $(this).find('.retAccHiddenInp.total-selected').val("0");
          $(this).find('.retAccHiddenInp').not('.total-selected').remove();

          //Change the value to previous state using the attribute "data-reset-state"
          my._changeToPrevState($(this));

          // For table, find element with attribute "data-reset-state" and Change the value to previous state.
          $(this).find('*['+constants.resetStateAttr+']').each(function(){
            var $currentEle = $(this);
            my._changeToPrevState($currentEle);
          });
        });
      });

      // Register the listener for Clear All button
      my._clearAll();
    },
    _changeToPrevState: function($ele){
      switch($ele.attr(constants.resetStateAttr)){
        case constants.show:
          $ele.removeClass(constants.closedCls);
          break;
        case constants.hide:
          $ele.addClass(constants.closedCls);
          break;
        case constants.require:
          $ele.removeAttr(constants.dataRequiredAttr, true);
          break;
        case constants.unrequire:
          $ele.removeAttr(constants.dataRequiredAttr, false);
          break;
        case constants.enable:
          $ele.removeAttr(constants.disabled);
          break;
        case constants.disable:
          $ele.attr(constants.disabled, true);
          break;
      }
    },
    /*
     * Refresh the page to reset all the fields
     */
    _clearAll: function() {

      $('button[data-method=clearAll]').on('click', function(){
        location.reload(true);
      });
    }
  };

  return CLEAR_ACTIONS;
});
