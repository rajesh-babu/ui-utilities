/**
 * Set the Dropdown options based on Contract info JSON
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants', 'utilities/main'],function($,constants, utilities) {

  var CONTRACTINFO_JSON = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },
  
    /*
     * Public API -Below drop down values will be filled based on conditional data.
     *
     */
     setDropDownOptions : function(sourceRegex, targetRegex, $srcEle, $tarEle) {
       var my = this;
        // Remove existing options
        if($tarEle.find('option').first().val() === '') {
         $tarEle.find("option:not(:first)").remove();
       }else {
         $tarEle.find("option").remove();
       }

       for(var j=0;j<constants.contractInfoJSON.Parents.length;j++) {
         if($srcEle.val() === constants.contractInfoJSON.Parents[j][sourceRegex]) {
           $tarEle.append('<option value="'+constants.contractInfoJSON.Parents[j][targetRegex]+'">'+constants.contractInfoJSON.Parents[j][targetRegex]+'</option>');
         }
       }
    },
    /*
     * Public API - Set the text value based on drop down selection and contract info JSON
     */
    setText: function(sourceRegex, targetRegex, $srcEle, $tarEle) {

      if(sourceRegex && targetRegex){
        var propArrSrcRegexArr = sourceRegex.split('.'),
          propArrTargetRegexArr = targetRegex.split('.');

        // It will extract the string notation and get the corresponding array from JSON
        var fieldArr = utilities.json.convertStrDotToJSON(sourceRegex),
          srcFieldName = propArrSrcRegexArr[propArrSrcRegexArr.length-1],
          targetFieldName = propArrTargetRegexArr[propArrTargetRegexArr.length-1];

        // Don't set the drop down value if user doesn't give 'dataSourceReference' in form builder
        if(srcFieldName !== null && targetFieldName !== null && fieldArr){

          // Reset it text field if no value
          if($srcEle.val() === '') {$tarEle.val(''); }

          for(var j=0;j<fieldArr.length;j++) {
            if($srcEle.val() === fieldArr[j][srcFieldName]) {
              $tarEle.val(fieldArr[j][targetFieldName]);
            }
          }
        }
      }
    }
  };

   // Public APIs
  return CONTRACTINFO_JSON;
});
