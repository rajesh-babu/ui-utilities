/**
 * Conditions - Actions
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants', 'conditionsUtils','validationActions','previewSection'],function($, constants, _conditionsUtils,_validationActions,_previewSection) {

  var CONDITIONS_ACTIONS = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },
    /*
     * Public API - Enable or Disable the target fields
     */
     enableDisableFields: function(state, doState, tarEle$) {
      var checkOperator = (state === constants.equals) ? '===' : '!==';
      if(doState===constants.enable) {

        // Dont do anything if it's not disabled
        if(!tarEle$.attr(constants.disabled)) { return false; }

        tarEle$.removeAttr(constants.disabled);

        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clicking the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, constants.disable);
        }
      }
      if(doState===constants.disable) {

        // Dont do anything if it's not disabled
        if(tarEle$.attr(constants.disabled)) { return false; }

        tarEle$.attr(constants.disabled, true);

        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clikcing the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, constants.enable);
        }
      }

      _previewSection.setPreviewSectionDataFromProcess();
    },
    /*
     * Public API - Show or Hide the target fields
     */
    showHideFields: function(state, doState, tarEle$,fieldType) {
      var checkOperator = (state === constants.equals) ? '===' : '!==',
          hasParent = tarEle$.attr(constants.hasparentAttr);
      if(doState===constants.show) {

        // If 'data-hasparent' attribute is true, Traverse till "lblFieldPair" class and remove the 'closed' class.
        if(hasParent && hasParent ==='true') {
            tarEle$ = tarEle$.closest('.' + constants.parentClsName);
        }

        //Dont do anything if 'closed' class not there
        // if(!tarEle$.hasClass(constants.closedCls)) { return false; }

        //Remove the 'closed' class to make it visible
        if(fieldType === 'pagefield' || fieldType === 'secContainer') {
          tarEle$.next(".mt").removeClass(constants.closedCls);
          tarEle$.next(".mt").next(".clear").removeClass(constants.closedCls);
        }
        tarEle$.removeClass(constants.closedCls);

        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clikcing the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, 'hide');
        }
        // Apply attribute validation  for visible fields
        _validationActions.formSettingsOnLoad();

      }
      if(doState===constants.hide) {

        // If 'data-hasparent' attribute is true, Traverse till "lblFieldPair" class and add the 'closed' class.
        if(hasParent && hasParent ==='true') {
            tarEle$ = tarEle$.closest('.' + constants.parentClsName);
        }

        //Dont do anything if 'closed' class is already there
        // if(tarEle$.hasClass(constants.closedCls)) { return false; }

        if(fieldType === 'pagefield' || fieldType === 'secContainer') {
          tarEle$.next(".mt").addClass(constants.closedCls);
          tarEle$.next(".mt").next(".clear").addClass(constants.closedCls);
        }
        tarEle$.addClass(constants.closedCls);

        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clikcing the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, 'show');
        }
      }

      _previewSection.setPreviewSectionDataFromProcess();
    },
    /*
     * Public API - Make mandatory or Non mandatory the target fields
     */
    requireUnrequireFields: function(state, doState, tarEle$){
      var checkOperator = (state === constants.equals) ? '===' : '!==';
      if(doState===constants.require) {

        //Dont do anything if 'data-required' attribute is true already
        if(tarEle$.attr(constants.dataRequiredAttr) ) { return false; }

        // Set the attribute "data-required" to make it mandatory and <span> tag for '*'
        tarEle$.attr(constants.dataRequiredAttr, true);
        tarEle$.closest(constants.parentDivSelector).find('.lbl label').prepend(constants.requiredAsteriskEle);


        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clicking the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, constants.unrequire);
        }
      }
      if(doState===constants.unrequire) {

        //Dont do anything if 'data-required' attribute is not there
        if(!tarEle$.attr(constants.dataRequiredAttr)) { return false; }

        // Remove the attribute "data-required" to make it non mandatory and <span> tag for '*'
        tarEle$.removeAttr(constants.dataRequiredAttr);
        tarEle$.closest(constants.parentDivSelector).find('.lbl span.required').remove();

        // Dont set the reset if it's already exist
        if(!tarEle$.attr(constants.resetStateAttr)) {

          // set the reset value to reset it when clikcing the 'Clear' button
          tarEle$.attr(constants.resetStateAttr, constants.require);
        }
      }

      _previewSection.setPreviewSectionDataFromProcess();
    },

    /*
     * Public API - Hide a option in a dropdown based on sourceRegex and targetRegex
     */
    hideDropDownOption: function(sourceRegex, targetRegex, $srcEle, $tarEle) {
      if($srcEle.find('option:selected').text() === sourceRegex) {
         $tarEle.find('option').filter(function () {
          if ($(this).html() == targetRegex) {
            $(this).hide();
          }
        });
        //$tarEle.find('option[value='+targetVal+']').remove();
      }else {
        $tarEle.find('option').show();
      }

      _previewSection.setPreviewSectionDataFromProcess();
    }
  };

   // Public APIs
  return CONDITIONS_ACTIONS;
});
