define(['jquery',
        'attachJQ_FO',
        'conditions',
        'clearActions',
        'previewSection',
        'validationActions',
        'setDefault',
        'phoneValidation',
        'dateValidation'
      ], function($,
          attachJQ_FO,
         _conditions,
         _clearActions,
         _previewSection,
         _validationActions,
         _setDefault,
         _phoneValidation,
         _dateValidation
        ) {
  var FOUTPUT = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);

      // Initialize money out widget - bank accounts
      _udMoneyOutModule.attachBankEvents();

      //my.$elem = $(elem);
      my._processConditions();
      _setDefault.setDefaultValues(elem);

      // Preview Page scripts
      _previewSection.setPreviewSectionData();


      // Hide state drop down, if country selected is not USA
      _commonsOvrrideDrpDnModule.showHideStateDropDown();
    },

    /*
     * Get the conditions and set the properties accordingly
     */
    _processConditions: function() {

      var my = this;

      // Process Conditional logic
      if(_constants.appGlobalData.settings.pages && _constants.appGlobalData.settings.pages.length){ _conditions.processConditions(_constants.appGlobalData.settings.pages);}

      // Process Clear link's Actions
      _clearActions.clearAction();

      // Set default maxlength for Phone fields
      _phoneValidation.phoneOnLoad();

      // Set default data range for date calender
      _dateValidation.dateOnLoad();

      // Validation scripts
      _validationActions.validateForm();

    }


  };
  return FOUTPUT;
});
