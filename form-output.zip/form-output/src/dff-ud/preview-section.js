/**
 * Preview Section
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants'],function($, constants) {

  var PREVIEW_SEC = {
    // Defaults
    defaults: {
      previewSecSelector:            '#tabsOne',
      previewFieldSlector:           'div.lblfield',
      srcFieldAttr:                  'data-src-field',
      updateFormBtnSelector:         'button[data-method=updateForm]',
      targetFieldParentSelector:     '.lblFieldPair',
      hiddenFieldClass:              'phoneActual' // International Phone hidden field
    },

    // Initialize
    init: function(elem, options, i) {

      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    /*
     * In Preview Section, Get the source element's name through attribute 'data-src-field' and check any text or selection, if so set the value accordingly
     */
    showUpdatePreviewSection: function() {
      var my = this,
         checkBoxArr = [];
      // Reset the existing table values
      $('#tabsOne table.fieldTable .lblfield').text('');

      $(my.defaults.previewSecSelector).find(my.defaults.previewFieldSlector).each(function(){
        var srcName = $(this).attr(my.defaults.srcFieldAttr), $targetField;

        if(srcName) {
          $targetField = $(this);
          $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);

          // Use class selector as name will be assigned to class as well
          $('.' + srcName).each(function() {

            var _this$ = $(this), val, $tableEle, tableInputValArr;
              if(_this$.is(':visible')){
                  // If source elment is Select
                  if(_this$.is('select')){
                    val = _this$.val(),
                        ddText = _this$.find('option:selected').text();

                    // If the source element is hidden or no value, hide the corrosponding element in review page.
                    if(_this$.closest('.lblFieldPair').hasClass(constants.closedCls) || !val) {
                      $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                    } else {
                      $targetField.text($(this).find('option:selected').text());
                      $targetField.closest(my.defaults.targetFieldParentSelector).removeClass(constants.closedCls);
                    }

                  }else if(_this$.attr('type') === 'text'){ // If source elment is text field
                    val = _this$.val();

                    // If the source element is hidden or no value, hide the corrosponding element in review page.
                    if(_this$.closest('.lblFieldPair').hasClass(constants.closedCls) || val === '') {

                      //Before setting the class 'closed', Check whether it's inside a table and one of the <td> in the table has value
                      $tableEle = $targetField.closest('table.fieldTable');
                      tableInputValArr = [];
                      $tableEle.find('.lblfield').each(function() {
                        if(_this$.text() !==''){
                          tableInputValArr.push('1');
                        }
                      });
                      if(!tableInputValArr.length) {
                        $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                      }
                    }else{

                      //Remove the 'closed' class to make it visible
                      $targetField.closest(my.defaults.targetFieldParentSelector).removeClass(constants.closedCls);
                      $targetField.text(val);
                    }

                  }else if(_this$.attr('type') === 'radio'){ // If source element is Radio or Checkbox

                      // If the source element is hidden or no value, hide the corrosponding element in review page.
                      if(_this$.closest('.lblFieldPair').hasClass(constants.closedCls)) {
                        $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                      }else if(_this$.prop('checked') === true) {
                        $targetField.text(_this$.next().text());

                        //Remove the 'closed' class to make it visible
                        $targetField.closest(my.defaults.targetFieldParentSelector).removeClass(constants.closedCls);
                        return false; //skip rest of the elements
                      }else{

                        //Before setting the class 'closed', Check whether it's inside a table and one of the <td> in the table has value
                        $tableEle = $targetField.closest('table.fieldTable');
                        tableInputValArr = [];
                        $tableEle.find('.lblfield').each(function() {
                          if($(this).text() !==''){
                            tableInputValArr.push('1');
                          }
                        });
                        if(!tableInputValArr.length) {
                          $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                        }
                      }
                  }else if(_this$.attr('type') === 'checkbox'){

                      // If source element is Radio or Checkbox
                      if(_this$.prop('checked') === true) {
                        my.addCheckBoxsArr(checkBoxArr, $targetField, _this$.next().text());
                        //$targetField.text($chkEle.next().text());
                      }
                      // If the source element is hidden or no value, hide the corrosponding element in review page.
                      if(_this$.closest('.lblFieldPair').hasClass(constants.closedCls)) {

                        $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                      }else if(checkBoxArr.length) {

                        //Remove the 'closed' class to make it visible
                        $targetField.closest(my.defaults.targetFieldParentSelector).removeClass(constants.closedCls);
                      }else{

                        // Hide the element and Skip the iteration if no value
                        $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                      }
                  }
                } else{
                  // check for International phone hidden field
                  if(_this$.attr('type') === 'hidden' && _this$.hasClass(my.defaults.hiddenFieldClass)) {
                    val = _this$.val();
                    if(_this$.closest('.lblFieldPair').hasClass(constants.closedCls) || !val) {
                      $targetField.closest(my.defaults.targetFieldParentSelector).addClass(constants.closedCls);
                    } else {
                      $targetField.text($(this).val());
                      $targetField.closest(my.defaults.targetFieldParentSelector).removeClass(constants.closedCls);
                    }
                  }
                }
              });

            }
          });
      for(j=0;j<checkBoxArr.length;j++) {
        checkBoxArr[j].targetFd.html(checkBoxArr[j].values.join('<br>'));
      }
    },

    // Create Array of array to hold the checkbox target elements and it's value for checked items
    addCheckBoxsArr: function(checkBoxArr_, $targetField_, value){
      var my = this;
      if(checkBoxArr_.length){
          for(var i=0;i<checkBoxArr_.length;i++){
            if(checkBoxArr_[i].targetFd === $targetField_){
              checkBoxArr_[i].values.push(value);
            }else{
              checkBoxArr_.push({targetFd:$targetField_, values:[value]});
            }
          }
      }else{
        checkBoxArr_.push({targetFd:$targetField_, values:[value]});
      }
    },
    // show the form values in condensed preview section and Register the Update form button listner
    setPreviewSectionData: function(){
      var my = this;
      my.showUpdatePreviewSection();
      $(my.defaults.updateFormBtnSelector).on('click', function(){
        my.showUpdatePreviewSection();
      });

    },
    // show the form values in condensed preview section and Register the Update form button listner
    setPreviewSectionDataFromProcess: function(){
      var my = this;
      my.showUpdatePreviewSection();
    }
  };

  return PREVIEW_SEC;
});
