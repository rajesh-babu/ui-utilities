/**
 * Conditions - Textbox
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants','conditionsActions'],function($, constants, _conditionsActions) {

  var CONDITIONS_TEXTBOX = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },
    /*
     * Public API - Listener for Text boxes
     */
     handleTextbox: function(conditions){
      var my = this;
      $('input[type=text]').on('blur', function(e) {
        my._doTextChangeActions(conditions, $(this) );
      });
    },
    /*
     * Action for Textboxes
     */
    _doTextChangeActions: function(conditions, srcEle$) {
        for(var i=0;i<conditions.length;i++) {

          // ToDO - Change the delimiter '_' to someother character both FW and UI
          var namePostfixArr = srcEle$.attr('name').split('__');
          var namePostfix = (namePostfixArr.length >1) ? ('__'+namePostfixArr[1]) : '';
          if((conditions[i]['condIf'] + namePostfix)  === srcEle$.attr('name')  && conditions[i][constants.state] === constants.isFilled) {

            for(var j=0;j<conditions[i]['condDo'].length;j++) {
              var op = conditions[i]['condDo'][j];
              for(var k=0;k<op[constants.dofield].length;k++) {
                var tarEle$;
                if(op[constants.dofield][k].type === 'pagefield') {
                  tarEle$ = $('.ref-id-' + op[constants.dofield][k].refId);
                } else if(op[constants.dofield][k].type === 'secContainer') {
                  if($('.one_third').find('.' + op[constants.dofield][k].name + namePostfix).length > 0) {
                    tarEle$ = $('.one_third').find('.' + op[constants.dofield][k].name + namePostfix)
                  }
                } else {
                  tarEle$ = $('.' + op[constants.dofield][k].name + namePostfix)
                }

                  if(tarEle$.length > 0){

                  switch(op[constants.dostate]) {
                    case constants.requireOr:
                      if(srcEle$.val() !== '') {
                       tarEle$.attr('data-validation-or', true);
                     }else {
                       tarEle$.removeAttr('data-validation-or');
                     }
                      break;
                    case constants.require:
                      if(srcEle$.val() !== '') {
                       tarEle$.attr('data-required', true);
                     }else {
                       tarEle$.removeAttr('data-required');
                     }
                     break;
                     case constants.disable:
                       if(srcEle$.val() !== '') {
                        tarEle$.attr('disabled', true);
                        tarEle$.attr(constants.resetStateAttr, constants.enable);
                      }else {
                        tarEle$.removeAttr('disabled');
                      }
                      break;
                      case constants.show:
                          _conditionsActions.showHideFields(conditions[i][constants.state], op[constants.dostate], tarEle$,op[constants.dofield][k].type);
                      break;
                      case constants.hide:
                        _conditionsActions.showHideFields(conditions[i][constants.state], op[constants.dostate], tarEle$,op[constants.dofield][k].type);
                      break;
                  }
                }
              }
            }
          }
        }
      }
 };
  return CONDITIONS_TEXTBOX;
});
