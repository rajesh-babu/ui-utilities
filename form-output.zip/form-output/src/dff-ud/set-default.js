/**
 * Set default values for all fields
 */
define(['jquery','Constants', 'commonsDropDownModule'],function($, constants, _commonsDropDownModule) {

  var SET_DEFAULT = {
    // Defaults
    defaults: {
      dropdownSelector:         "select",                   // dropdown selector
      checkboxSelector:         "input[type='checkbox']",   // checkbox selector
      radioSelector:            "input[type='radio']",      // radio selector
      orchestrationIDSelector : 'input[name="OrchestrationID"]'
    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    /*
     * Public API - Reset the sibling elements
     */
     setDefaultValues: function(obj) {
       var my = this;

       // select all dropdown elements
       $dropdownEle = $(obj).find(my.defaults.dropdownSelector);

       // Set the Dropdown options based on 'dataSourceReference' property using the Contract info JSON
       _commonsDropDownModule.setDefaultDropDownUsingJSON();

       // select all checkbox elements
       $checkboxEle = $(obj).find(my.defaults.checkboxSelector);

       // select all radio elements
       $radioEle = $(obj).find(my.defaults.radioSelector);

       // loop all checkbox elements and set checked property if data-selected attribute is available
       $checkboxEle.each(function(){
         var $this = $(this);
         if($this.attr('data-selected')) {
           if($this.attr('data-selected') == $this.val()) {
             $this.prop('checked', true);
           } else {
             $this.prop('checked', false);
           }
           setTimeout(function(){ $this.change(); }, 100);
         }
       });

       // loop all radio elements and set checked property if data-selected attribute is available
       $radioEle.each(function(){
         var $this = $(this);
         if($this.attr('data-selected')) {
           if($this.attr('data-selected') == $this.val()) {
             $this.prop('checked', true);
           } else {
             $this.prop('checked', false);
           }
           setTimeout(function(){ $this.change(); }, 100);
         }
       });

       // loop all dropdown elements and set default value if data-selected attribute is available
       $dropdownEle.each(function(){
         var $this = $(this);
         if ($this.attr('data-selected')) {
           $this.val($this.attr('data-selected'));
           setTimeout(function(){ $this.change(); }, 100);
         }
       });

       // Hide the Delete button if there is no  <input> with name="OrchestrationID" has no value
       var orchEle = $(my.defaults.orchestrationIDSelector);
       if(orchEle.val() === '') {
         $('button[data-method="delete"]').hide();
       }
    }

  };

  return SET_DEFAULT;
});
