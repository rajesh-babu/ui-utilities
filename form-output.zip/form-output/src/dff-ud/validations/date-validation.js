/**
 * Set default values for all fields
 */
define(['jquery','Constants','errorMsgUtilities'],function($,constants,_errorMsgUtilities) {

  var DATE_VALIDATION = {
    // Defaults
    defaults: {
      dateClassName:    'inputDate',
      validateFormat: {
        'mm-dd-yyyy':{
           regEx:[
              /^((0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01])[- /.](19|20)?[0-9]{2})*$/,
              /(0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])[- \/.](20|19)\d\d/
           ],
           validationMsg: constants.dateValidationErrMsg
        },
        'dd-mm-yyyy':{
           regEx:[
             /^((0?[1-9]|[12][0-9]|3[01])[- /.](0?[1-9]|1[012])[- /.](19|20)?[0-9]{2})*$/,
             /(0[1-9]|[12][0-9]|3[01])[- \/.](0[1-9]|1[012])[- \/.](20|19)\d\d/
           ],
           validationMsg: constants.dateValidationDDMMYYYYErrMsg
        },
        'yyyy-mm-dd':{
           regEx:[
            /^((19|20)?[0-9]{2}[- /.](0?[1-9]|1[012])[- /.](0?[1-9]|[12][0-9]|3[01]))*$/,
            /(20|19)\d\d[- \/.](0[1-9]|1[012])[- \/.](0[1-9]|[12][0-9]|3[01])/
           ],
           validationMsg: constants.dateValidationYYYYMMDDErrMsg
        },
        'mm-yyyy':{
           regEx:[
            /^((0?[1-9]|1[012])[- /.](19|20)?[0-9]{2})*$/,
            /(0[1-9]|1[012])[- \/.](20|19)\d\d/
           ],
           validationMsg: constants.dateValidationMMYYYYErrMsg
        }
      }
    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    // Set calender selection range based on the data-validation attribute on load
    dateOnLoad: function() {
      var my = this;
       $('.'+my.defaults.dateClassName).filter(":not([readonly])").each(function() {
         var $this = $(this),
          options = {},
          opts = $.extend({}, {
           constrainInput: true,
           changeMonth: true,
           changeYear: true
          });

       if(($this.attr(constants.dataFormatAttr))|| ($this.attr(constants.dataValidationAttr))) {
         if($this.attr(constants.dataValidationAttr)) {
           if($this.attr(constants.dataValidationAttr) == "onlyPreviousDate") {
             options = $.extend({}, {
               min: '+1',
               maxDate: '-1',
               yearRange: '2000:+1',
               minDate: new Date(2000, 1 - 1, 1)
             }, opts);
           } else if($this.attr(constants.dataValidationAttr) == "todayAndPrevDate") {
              options = $.extend({}, {
                min: '+1',
                maxDate: '0',
                yearRange: '2000:+1',
                minDate: new Date(2000, 1 - 1, 1)
              }, opts);
            } else if($this.attr(constants.dataValidationAttr) == "onlyFutureDate") {
             options = $.extend({}, {
               min: '+1',
               minDate: '1'
              }, opts);
           } else if($this.attr(constants.dataValidationAttr) == "todayAndFutureDate") {
             options = $.extend({}, {
               min: '+1',
               minDate: '0'
              }, opts);
           }
         }

        if($this.attr(constants.dataFormatAttr)) {
          if($this.attr(constants.dataFormatAttr) == "mm-yyyy") {
            options = $.extend({}, {
              dateFormat: 'mm/yy',
              // On Select Event for datePicker to get the selected Day as
              // selected day is not available on select
              onSelect: function(curDate, instance){
                $this.attr("selectedDay",instance.selectedDay);
              }
            }, opts,options);
          }
          else if($this.attr(constants.dataFormatAttr) == "mm-dd-yyyy") {
            options = $.extend({}, {
              dateFormat: 'mm/dd/yy'
            }, opts,options);
          }
          else if($this.attr(constants.dataFormatAttr) == "dd-mm-yyyy") {
            options = $.extend({}, {
              dateFormat: 'dd/mm/yy'
            }, opts,options);
          }
          else if($this.attr(constants.dataFormatAttr) == "yyyy-mm-dd") {
            options = $.extend({}, {
              dateFormat: 'yy/mm/dd'
            }, opts,options);
          }
        }

        $this.datepicker(options);
        $this.datepicker("destroy");
      }
    });
  },

    dateValidation: function(field, validationMy) {
      var my = this,
      dateFormat = (typeof field.attr(constants.dataFormatAttr) !='undefined')?field.attr(constants.dataFormatAttr):'',
      $errMsg = '';

      // Phone Required Validation
      if(field.attr(constants.dataRequiredAttr)) {
        if(!field.val()) {
          validationMy.addHighlight(field);
          $errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.requiredErrMsg);
        }
      }

      if(field.val()) {

        $errMsg = my.validateDateFormat(field, dateFormat, validationMy);

        if(field.attr(constants.dataValidationAttr) && $errMsg == "") {
          $errMsg = my.dateAttrValidation(field);
          if($errMsg) {
            validationMy.addHighlight(field);
          }
        }
      }

      if($errMsg == '') { // Passing Validation
        validationMy.removeHighlight(field);
      }

      return $errMsg;
    },

    /**
     * Validate Date based on DateFormat
     * @param field (Date) --> Selected Date
     * @param dateFormat (String) --> date format in 'MM/DD/YYYY' Or 'DD/MM/YYYY'
     * @param validationMy (object) --> Parent Caller object
     * @return $errMsg (String) --> Return Error message
     */
    validateDateFormat: function(field, dateFormat, validationMy){
      var my = this, $errMsg= '', $month, $year, $day;
      // Get validator object based on dateformat
      var fieldValidator = my.defaults.validateFormat[dateFormat];

      $month = my.getMonthYearDate(field, dateFormat)[0];
      $day   = my.getMonthYearDate(field, dateFormat)[1];
      $year  = my.getMonthYearDate(field, dateFormat)[2];

      if(fieldValidator !== undefined &&  fieldValidator !== null){
        fieldValidator.regEx.forEach(function(regEx){
          if (!(field.val().match(regEx))) {
            // Date format validation
            validationMy.addHighlight(field);
            $errMsg = _errorMsgUtilities.generateErrorMsg(field, fieldValidator.validationMsg);
          }
        });

        // Skip 31 Days and 29th Day validation for 'mm-yyyy' format
        if(dateFormat !== 'mm-yyyy'){
          if (($month == "04" || $month == "06" || $month == "09" || $month == "11") && $day == "31") {
            // 31 days validation validation
            validationMy.addHighlight(field);
            $errMsg = _errorMsgUtilities.generateErrorMsg(field, fieldValidator.validationMsg);
          } else if ($month == "02") {
            // check for february 29th
            var isleap = (parseFloat($year) % parseFloat("04") == 0 && (parseFloat($year) % parseFloat("100") != 0 || parseFloat($year) % parseFloat("400") == 0));
            if (parseFloat($day) > parseFloat("29") || (parseFloat($day) == parseFloat("29") && !isleap)) {
              validationMy.addHighlight(field);
              $errMsg = _errorMsgUtilities.generateErrorMsg(field, fieldValidator.validationMsg);
            }
          }
        }
      }
      return $errMsg;
    },

    /**
     * Get Month, Year and Day from selected Date
     * @param field (Date) --> Selected Date
     * @param dateFormat (String) --> Date Format
     * @param return (Array) --> Array of moth, year and Day
     */
    getMonthYearDate: function(field, dateFormat){
      var $month, $day, $year;
      if(dateFormat=='' || dateFormat =='mm-dd-yyyy') {
        $month = (field.val()).substring(0, 2);
        $day = (field.val()).substring(3, 5);
        $year = (field.val()).substring(6, 10);
      } else if(dateFormat =='dd-mm-yyyy') {
        $day = (field.val()).substring(0, 2);
        $month = (field.val()).substring(3, 5);
        $year = (field.val()).substring(6, 10);
      } else if(dateFormat =='yyyy-mm-dd') {
        $year = (field.val()).substring(0, 4);
        $month = (field.val()).substring(5, 7);
        $day = (field.val()).substring(8, 10);
      }else if(dateFormat =='mm-yyyy') {
        $year = (field.val()).substring(3, 7);
        $month = (field.val()).substring(0, 2);
      }
      return [$month, $day, $year];
    },

    dateAttrValidation: function(field) {
      var dateFormat = (typeof field.attr(constants.dataFormatAttr) !='undefined')?field.attr(constants.dataFormatAttr):'';
      var my = this;
      if(dateFormat !=='' && dateFormat === 'mm-yyyy') {
        var $month = my.getMonthYearDate(field, 'mm-yyyy')[0];
        var $year = my.getMonthYearDate(field, 'mm-yyyy')[2];
        // Check SelectedDay attr for mm-yyyy format only as day is not available
        if(field.attr("selectedDay")!== undefined && field.attr("selectedDay") !== '' ){
          $filledDate = new Date($month+'-'+ field.attr("selectedDay") + '-'+ $year);
        }else{
          $filledDate = new Date($month+'-'+ "01" + '-'+ $year);
        }
      }else{
        $filledDate = field.datepicker("getDate");
      }

      $todayDate = new Date();
      $yesDate = new Date();
      $todayDateP = new Date();
      $todayDateinSec = $todayDate.getTime();
      $yesDate.setDate($yesDate.getDate() - 1);
      $yesDateinSec = $yesDate.getTime();
      $filledDateinSec = $filledDate.getTime();
      $todayDateP = $todayDate;
      $todayDateP.setHours(0);
      $todayDateP.setMinutes(0);
      $todayDateP.setSeconds(0);
      $todayDateP.setMilliseconds(0);
      $todayDatePinSec = $todayDateP.getTime();
      $dateErrMsg = '';
      $dataValidation = field.attr(constants.dataValidationAttr);

      switch ($dataValidation) {
        case 'onlyFutureDate':
          if($filledDateinSec <= $todayDateinSec) {
            $dateErrMsg = _errorMsgUtilities.generateErrorMsg(field, constants.futureDateErrMsg);
          }
          break;
        case 'todayAndFutureDate':
          if($filledDateinSec <= $yesDateinSec) {
            $dateErrMsg = _errorMsgUtilities.generateErrorMsg(field, constants.futureAndTodayDateErrMsg);
          }
          break;
        case 'todayAndPrevDate':
          if($filledDateinSec > $todayDateinSec) {
            $dateErrMsg = _errorMsgUtilities.generateErrorMsg(field, constants.prevAndTodayDateErrMsg);
          }
          break;
        case 'onlyPreviousDate':
          if($filledDateinSec >= $todayDatePinSec) {
            $dateErrMsg = _errorMsgUtilities.generateErrorMsg(field, constants.prevDateErrMsg);
          }
          break;
        default:
          break;
      }

      return $dateErrMsg;

    }




  };

  return DATE_VALIDATION;
});
