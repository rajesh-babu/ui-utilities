/**
 * Validation Actions
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants','attributeValidation', 'phoneValidation', 'errorMsgUtilities','dateValidation', 'utilities/web-url'],
      function($, constants, _attributeValidation, phoneValidation, _errorMsgUtilities,dateValidation, _webUrl) {

  var VALIDATION_ACTIONS= {
    // Defaults
    defaults: {
      btnValidationSelector:      'button[data-validation="true"]',
      btnSelector:                'button[data-method]',
      validationAttribute:        'data-validation',
      alertHighlightClassName:    'alertHighlight',
      selectInpRequiredSelector:  'select:visible, input:visible, textarea, table',
      alertContainerSelector:     '.alertModule',
      visibleClsName:             'visible',
      ssnClassName:               'ssn1',
      phoneClassName:             'phoneField1',
      intlPhoneClassName:         'phoneSuffix',
      anClassName:                'accountnumber1',
      dateClassName:              'inputDate',
      inputTextSelector:          'input:visible',
      buttonMethodAttribute:      'data-method',
      buttonActionAttribute:      'data-action',
      buttonPopupAttribute:       'data-popup',
      buttonbehaviourAttribute:   'data-behavior',
      buttonAliasPopupAttribute:  'data-alias-popup',
      btnValidPopupSelector:      'button[data-validation="true"][data-popup]',
      send2mytcHiddenField:       'input[name="send2mytc"]',
      actionHiddenField:          'input[name="Action"]',
      communicationsEventName:    'input[name="communicationsEventName"]',
      communicationsRqstApp:      'input[name="communicationsRqstApp"]',
      workflowIndField:           'input[name="workflowInd"]',
      multichannelField:          'input[name="Multichannel"]',
      orchestrationIdField:       'input[name="OrchestrationID"]',
      reforchestrationIdField:    'input[name="ReferenceOrchestrationID"]',
      submitButtonC:              '[data-method="c"]',
      formSelector:               '.digitalTransactionForm',
      plansBalanceTable:          'plansbalance-table',
      tableClassName:             'accountlist-table',
      overallMinPlansClass:       'overallMinPlans',
      overallMaxPlansClass:       'overallMaxPlans',
      investmentListGroup:        '.investmentListGroup',
      beneficiaryListGroup:        '.beneficiaryListGroup',
      bundleField:                'input[name="Bundle"]',
      formRowNumberHiddenField:   'input[name="bundleFormRowNumber"]',
      bundleActionHiddenField:    'input[name="bundleAction"]'
    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    formSettingsOnLoad: function() {
      var my = this,
          $inputEle = $(my.defaults.inputTextSelector);

      my.form = $(my.defaults.formSelector);

      // Set maxlength for all fields if data-max attribute is there
      $inputEle.each(function(){
        if($(this).attr(constants.dataMaxAttr)) {
          $(this).prop('maxlength',$(this).attr(constants.dataMaxAttr));
        }
      });

      // Rename data-popup, data-behaviour to avoid opening of popup before form is valid to submit
      $(my.defaults.btnSelector).each(function(){
        if($(this).attr(my.defaults.buttonPopupAttribute)) {
          $(this).attr(my.defaults.buttonAliasPopupAttribute,$(this).attr(my.defaults.buttonPopupAttribute));
          $(this).addClass("popupAfterValid");
          $(this).removeAttr(my.defaults.buttonPopupAttribute);
          $(this).removeAttr(my.defaults.buttonbehaviourAttribute);
          $(this).unbind("click");
        }
      });
    },

    // Public API to validate the form.
    validateForm: function() {
      var my = this;
      my.$alertContainer = $(my.defaults.alertContainerSelector);

      my.send2mytc = $(my.defaults.send2mytcHiddenField);
      my.actionField = $(my.defaults.actionHiddenField);
      my.communicationsEventName = $(my.defaults.communicationsEventName);
      my.communicationsRqstApp = $(my.defaults.communicationsRqstApp);
      my.workflowIndField = $(my.defaults.workflowIndField);
      my.multichannelField = $(my.defaults.multichannelField);
      my.submitButtonC = $(my.defaults.submitButtonC);
      my.bundleField = $(my.defaults.bundleField);
      my.orchestrationIdField = $(my.defaults.orchestrationIdField);
      my.refOrchestrationIdField = $(my.defaults.reforchestrationIdField);
      my.formRowNumber = $(my.defaults.formRowNumberHiddenField);
      my.bundleAction = $(my.defaults.bundleActionHiddenField);

      my.formSettingsOnLoad();

      // setTimeout(function(){ my.getPDF() }, 2000);
     /**
       * Moved mail, download & save buttons to "Additional Actions" Dropdown
       * actions implemented in bundle-txn-validation-action.js file
       */
      $(my.defaults.btnValidationSelector).on('click', function() {

        my.selectedButtonPopup = my.selectedButtonAction = my.selectedButton = "";

        // Store method and action of clicked button - required while form is posted
        if($(this).attr(my.defaults.buttonMethodAttribute)) {
          my.selectedButtonEle$ = $(this);
          my.selectedButton = my.selectedButtonEle$.attr(my.defaults.buttonMethodAttribute);
        }
        if($(this).attr(my.defaults.buttonActionAttribute)) {
          my.selectedButtonAction = $(this).attr(my.defaults.buttonActionAttribute);
        }
        if($(this).attr(my.defaults.buttonAliasPopupAttribute)) {
          my.selectedButtonPopup = $(this).attr(my.defaults.buttonAliasPopupAttribute);
        }

        // Reset the existing highlighted item
        $('.alertHighlight').removeClass('alertHighlight');
        $('.alertModule ul li').remove();

        my.errorCounter = 0;
        my.$errorMsgList = $('<ul></ul>');

        // Highlight and show alert module If selected value in Drop down is empty
        var $selectInputEle = $(my.defaults.selectInpRequiredSelector);

        // Looping through all form fields
        $selectInputEle.filter(":not([readonly])").filter(":not([disabled])").each(function() {
          var $this = $(this),
           $parent = $this.closest(constants.parentDivSelector),
           $errMsg = '';
           if($this.hasClass(my.defaults.phoneClassName)){
             $errMsg = phoneValidation.phoneValidation($this,my);
             if($errMsg) {
               my.$errorMsgList.append($errMsg);
               my.errorCounter++;
               $errMsg = '';
             }
           } else if($this.hasClass(my.defaults.dateClassName)){
             $errMsg = dateValidation.dateValidation($this,my);
             if($errMsg) {
               my.$errorMsgList.append($errMsg);
               my.errorCounter++;
               $errMsg = '';
             }
           } else if($this.attr(constants.dataRequiredAttr)) { // Required validation based on data-required attribute
             my.required($this);
           } else if($this.attr(constants.dataValidationOrAttr)) { // Required Or Validation based on 'data-validation-or'
            my.requiredOr($this);
           }

          // Attribute validation based on data-validation attribute. Mostly used for textboxes
          // refer code in attribute-validation.js
          if($this.attr(constants.dataValidationAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            $errMsg = _attributeValidation.attrValidation($this,$this.attr(constants.dataValidationAttr),my);
            if($errMsg) {
              my.$errorMsgList.append($errMsg);
              my.errorCounter++;
              $errMsg = '';
            }
          }

          // Minimum Length vaidation based on data-min attribute
          if($this.attr(constants.dataMinAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            my.minLengthValidation($this, $this.attr(constants.dataMinAttr));
          }

          // Minimum value validation based on data-minval attribute
          if($this.attr(constants.dataMinValAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            my.minValueValidation($this, $this.attr(constants.dataMinValAttr));
          }

          // Maximum value validation based on data-maxval attribute
          if($this.attr(constants.dataMaxValAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            my.maxValueValidation($this, $this.attr(constants.dataMaxValAttr));
          }

          // Minimum selection validation for checkbox
          if($this.attr(constants.dataMinEntryAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            my.minEntryValidation($this, $this.attr(constants.dataMinEntryAttr));
          }

          // Maximum selection validation for checkbox
          if($this.attr(constants.dataMaxEntryAttr) && $this.val() && !$parent.hasClass(my.defaults.alertHighlightClassName)) {
            my.maxEntryValidation($this, $this.attr(constants.dataMaxEntryAttr));
          }

        });

        // Calling show error message to show error message based on error counters
        my.showErrorMsg();

      });

      /**
       * Moved mail, download & save buttons to "Additional Actions" Dropdown
       * actions implemented in bundle-txn-validation-action.js file
       */
      $(my.defaults.btnSelector).on('click', function() {
        if((typeof ($(this).attr(my.defaults.validationAttribute)) === "undefined") || $(this).attr(my.defaults.validationAttribute) === "false") {
          my.selectedButtonPopup = my.selectedButtonAction = my.selectedButton = "";

          // Store method and action of clicked button - required while form is posted
          if($(this).attr(my.defaults.buttonMethodAttribute)) {
            my.selectedButtonEle$ = $(this);
            my.selectedButton = my.selectedButtonEle$.attr(my.defaults.buttonMethodAttribute);
          }
          if($(this).attr(my.defaults.buttonActionAttribute)) {
            my.selectedButtonAction = $(this).attr(my.defaults.buttonActionAttribute);
          }
          if($(this).attr(my.defaults.buttonAliasPopupAttribute)) {
            my.selectedButtonPopup = $(this).attr(my.defaults.buttonAliasPopupAttribute);
          }

          // Rename data-popup, data-behaviour to avoid opening of popup before form is valid to submit
          if(my.selectedButtonPopup !== '') {
            $("#"+my.selectedButtonPopup).dialog("open");
          } else if(my.selectedButtonAction !=='' && my.selectedButton !== ''){
            my.onFormValid();
          }
        }
      });
    },

    // Required validation based on data-required attribute
    required: function(field) {
      var my = this;

      if(field.attr('type') == 'checkbox' || field.attr('type') == 'radio') {
        if(field.parents('ul.lblSelectPair').first().find('li > input').filter(":enabled").is(':checked')) {
          my.removeHighlight(field);
        } else {
          my.addHighlight(field);
          _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.requiredErrMsg);
          my.errorCounter++;
        }
      } else if(field.val()) {
        my.removeHighlight(field);
      } else {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.requiredErrMsg);
        my.errorCounter++;
      }
    },

    // Required validation based on data-required attribute
    requiredOr: function(field) {
      var my = this,
          validArr = [],
          $eleOr = field.closest('tr').find('input['+constants.dataValidationOrAttr+'="true"]');
      $eleOr.each(function(){
        if($(this).attr('type') == 'radio') {
          if($(this).is(':checked')) {
            validArr.push('valid');
          }
        } else if($(this).attr('type') == 'text') {
          if($(this).val() !== '') {
            validArr.push('valid');
          }
        }
      });
      // If Array is empty, then none of the fields filled or checked
      if(!validArr.length) {
        my.addHighlight($eleOr);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.requiredErrMsg);
        my.errorCounter++;
      }else{
        my.removeHighlight($eleOr);
      }
    },

    // Minimum Length vaidation based on data-min attribute
    minLengthValidation: function(field, length) {
      var my = this;
      if (field.val().length >= length) {
        my.removeHighlight(field);
      } else {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.minLengthErrMsg, length);
        my.errorCounter++;
      }
    },

    // Minimum Value validation based on data0maz attribute
    minValueValidation: function(field, value) {
      var my = this;
      if (parseFloat(field.val()) >= parseFloat(value)) {
        my.removeHighlight(field);
      } else {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.minValueErrMsg, value, 'maxminvalue');
        my.errorCounter++;
      }
    },

    // Maximum Value validation based on data-max attribute
    maxValueValidation: function(field, value) {
      var my = this;
      if (parseFloat(field.val()) <= parseFloat(value)) {
        my.removeHighlight(field);
      } else {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.maxValueErrMsg, value, 'maxminvalue');
        my.errorCounter++;
      }
    },

    // Maximum Value validation based on data-max attribute
    minEntryValidation: function(field, value) {
      var my = this;
      if(field.parents('ul.lblSelectPair').first().find('li > input:checked').filter(":enabled").length < value) {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.minEntryErrMsg, value, 'maxminselection');
        my.errorCounter++;
      } else {
        my.removeHighlight(field);
      }
    },

    // Maximum Value validation based on data-max attribute
    maxEntryValidation: function(field, value) {
      var my = this;
      if(field.parents('ul.lblSelectPair').first().find('li > input:checked').filter(":enabled").length > value) {
        my.addHighlight(field);
        _errorMsgUtilities.appendErrorMsg(field, my.$errorMsgList, constants.maxEntryErrMsg, value, 'maxminselection');
        my.errorCounter++;
      } else {
        my.removeHighlight(field);
      }
    },

    // Common method to highlight field in case of errors
    addHighlight: function(field) {
      var my = this;
      field.closest(constants.parentDivSelector).addClass(my.defaults.alertHighlightClassName);
    },

    // common method to remove highlight in case of no errors
    removeHighlight: function(field) {
      var my = this;
      field.closest(constants.parentDivSelector).removeClass(my.defaults.alertHighlightClassName);
    },

    // common method to show/hide error message based on the error counter.
    showErrorMsg: function() {
      var my = this;
      if(my.errorCounter) {
        my.$alertContainer.html(my.$errorMsgList);
        my.$alertContainer.addClass(my.defaults.visibleClsName);

      } else {
        my.$alertContainer.removeClass(my.defaults.visibleClsName);

        // Rename data-popup, data-behaviour to avoid opening of popup before form is valid to submit
        if(my.selectedButtonPopup !== '') {
          $("#"+my.selectedButtonPopup).dialog("open");
        } else if(my.selectedButton == 'updateForm' && my.selectedButtonAction !== '') {

          // To Generate the PDF in PDF tab, Call an Ajax to get PDF byte Array
          // my.getPDF();
        }else if(my.selectedButtonAction !== '' && my.selectedButton !== ''){
          my.onFormValid();
        }
      }
    },
    // Get the PDF byte array and set it.
    getPDF: function() {
      var my = this;
      my.actionField.val("V");
      my.multichannelField.val("ud");
      my.send2mytc.val("no");
      if(my.selectedButtonEle$){
        my.selectedButtonEle$.attr('disabled', true);
      }

      $(".inlineReadOnlyPdf").text('Retrieving PDF from server, Please wait...');
      $.ajax({
        type:	'POST',
        // foreSend: function (request)
        //
        // equest.setRequestHeader("_AUTH_HEADER_", "");
        //
        url :   'submitForm', //my.selectedButtonAction, //https://ud-st2.test.tiaa-cref.org/ud/formsfactory/submitForm
        data:	my.form.serialize(),
        ///headers:	{"_AUTH_HEADER_": ""},
        success: function(result) {
          if(result && result !== ''){
            $(".inlineReadOnlyPdf").html('<object data="data:application/pdf;base64,'+result+'" width="600" height="800"></object>');
            my.selectedButtonEle$.removeAttr('disabled');
          }else {
            $(".inlineReadOnlyPdf").text('There was a problem while getting the PDF from Server, Please try again later! ');
          }
        },
        error: function(response,status,xhr){
          console.log("Error while calling the SubmitForm for PDF byte Array!");
          $(".inlineReadOnlyPdf").text('There was a problem while getting the PDF from Server, Please try again later! ');
          if(my.selectedButtonEle$){
            my.selectedButtonEle$.removeAttr('disabled');
          }
        }
      });
    },

    // Form validation success handler
    onFormValid: function() {
      var my = this;

      // Cancel action
      if(my.selectedButton === 'cancel' && my.selectedButtonAction !== ''){
        window.location.href= my.selectedButtonAction; // './dashboard?pin=1070247';
        return;
      }

      // SET DEFAULT values for hidden fields

        my.send2mytc.val("no");
        my.actionField.val("");
        my.communicationsEventName.val("");
        my.communicationsRqstApp.val("");
        my.workflowIndField.val("N");
        my.multichannelField.val("");

      /* Supported buttons
       * Deliver Online,
       */
      if(my.selectedButton) {
        if (my.selectedButton == "deliverOnline") {
            my.send2mytc.val("yes");
            my.actionField.val("EMAIL");
            my.multichannelField.val("iwc");
            my.communicationsEventName.val('');
            my.communicationsRqstApp.val('');

            // Perform sameaction for Resend online button
            // add new reference orchestration Id and empty existing orchestration Id
            if ($(my.selectedButtonEle$).attr('name') === 'resendOnline') {
              var orchId = $(my.orchestrationIdField).val();
              $(my.refOrchestrationIdField).val(orchId);
              $(my.orchestrationIdField).val('');
            }
        } else if (my.selectedButton == "c") {

            my.workflowIndField.val("Y");
            my.actionField.val("C");
            my.submitButtonC.prop("disabled",true);

        } else if (my.selectedButton == "save") {

            my.actionField.val("SAVE");
            my.send2mytc.val("no");
            my.multichannelField.val("iwc");
            my.communicationsEventName.val("CCP_RS_STD_ECONFIRMATION");
            my.communicationsRqstApp.val("DCRS");
            my.addAdditionalHiddenFields();
             

        } else if (my.selectedButton == "submit") {

            my.workflowIndField.val("Y");
            my.actionField.val("C");

        } else if (my.selectedButton == "print") {

            my.multichannelField.val("ud");
            my.send2mytc.val("no");
            my.actionField.val("C");
            my.addAdditionalHiddenFields();

        } else if (my.selectedButton == "mail") {

            my.multichannelField.val("ud");
            my.communicationsEventName.val("DCRS");
            my.communicationsRqstApp.val("DCRS");
            my.actionField.val("S");
            my.addAdditionalHiddenFields();
        } else if (my.selectedButton == "eDeliver") {

            my.communicationsEventName.val("CCP_RS_STD_ECONFIRMATION");
            my.communicationsRqstApp.val("DCRS");
            my.actionField.val("EMAIL");
        } else if (my.selectedButton == "SendtoMyTC" || my.selectedButton == "Send to MyTC") {

            my.actionField.val("IWC");
        } else if (my.selectedButton === 'bundleAddAnother') {
           // Add form to the transaction bundle
            my.bundleField.val('Y');
            my.actionField.val("bundleaddanother");
        } else if (my.selectedButton === 'bundleDuplicate') {
          // duplicate form and add to the transaction bundle
            my.bundleField.val('Y');
            my.actionField.val("bundleduplicate");
        } else if (my.selectedButton === 'bundleDeliverOnline') {
          //  add to the transaction bundle
            my.bundleField.val('Y');
            my.actionField.val("bundledeliveronline");
        } else if (my.selectedButton === 'saveAddAnother') {
          // Save form from the bundle
            my.bundleField.val('Y');
            my.actionField.val("savebundleaddanother");
        } else if (my.selectedButton === 'saveDuplicate') {
          // Save form, create duplicate
            my.bundleField.val('Y');
            my.actionField.val("savebundleduplicate");
        } else if (my.selectedButton === 'saveDeliverOnline') {
          // Save form, create duplicate
            my.bundleField.val('Y');
            my.actionField.val("savebundledeliveronline");
        }
        if (my.selectedButton != "cancel") {
            my.form.attr("action", my.selectedButtonAction);
        }

        // Reset the values for Input, Checkbox, radio and Select if it's hidden to avoid field mapping in PDF
        my.form.find('.lblFieldPair.closed').each(function(){
            var this$ = $(this);
            this$.find(":input:not([type=hidden])").each(function(){
              var field$ = $(this),
              fieldType = field$.attr('type');

              if(fieldType === 'radio' || fieldType === 'checkbox') {
                field$.prop('checked', false);
              }else {

                // For Input and Select elements
                field$.val('');
              }
            });
        });

        // Set the Query Parameter before posting the form
        var $pin = $('input[name="PIN"]'),
          queryParameter = '';
        $orchestrationID = $('input[name="OrchestrationID"]'),
        $formID = $('input[name="FormID"]');
        queryParameter += '?pin='+($pin.val() ? $pin.val() : '');
        queryParameter += '&formid='+($formID.val() ? $formID.val() : '');
        if($orchestrationID.length && $orchestrationID.val()) {
          queryParameter += '&orchestrationid=' +$orchestrationID.val();
        }

        // Set bundle Action parameter for Transaction bundled Forms
        if (my.selectedButton === 'bundleDuplicate' || my.selectedButton === 'bundleDeliverOnline') {
          queryParameter += '&bundleaction=add';
        } else if (my.selectedButton === 'saveAddAnother'
               || my.selectedButton === 'saveDeliverOnline') {
            // add formRowNumber to the action URL queryParameter
            var formRowNumber = _webUrl.getParameterByName('formRowNumber', window.location.href);
            queryParameter += '&formRowNumber='+ formRowNumber + '&bundleaction=edit';
        } else if (my.selectedButton === 'saveDuplicate') {
            // Redirect user to the form page with bundleaction = add
            var formRowNumber = _webUrl.getParameterByName('formRowNumber', window.location.href);
            queryParameter += '&formRowNumber='+ formRowNumber + '&bundleaction=add';
        }

        my.form.attr('action', my.form.attr('action' ) + queryParameter);

        my.resetHiddenFieldValues();

        my.form.submit();
      }
    },
    /* Reset the hidden fields */
    resetHiddenFieldValues: function() {
      var my = this;
      $('.secContainer.closed').find('input,select').each(function(){
        var $this = $(this),
          srcType = $this.attr('type');
        if(srcType) {
          if(srcType === 'radio' || srcType === 'checkbox') {
            // Radio field or Checkbox field
            $this.prop('checked', false);
          }else {
            // Text field
            $this.val('');
          }
        }else{
          // Select field
          $this.val('');
        }
      });
    },

    /**
     * Add additional hidden fields for bundle Actions
     */
    addAdditionalHiddenFields: function() {
      var my = this;
      var formRowNumber = _webUrl.getParameterByName('formRowNumber', window.location.href);
      var bundleAction = _webUrl.getParameterByName('bundleaction', window.location.href);
      if (formRowNumber && formRowNumber!== null) {
        my.formRowNumber.val(formRowNumber);
      }

      if (bundleAction && bundleAction!== null) {
        my.bundleAction.val(bundleAction);
      }
    }
  };

  return VALIDATION_ACTIONS;
});
