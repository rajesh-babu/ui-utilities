/**
 * Set default values for all fields
 */
define(['jquery','Constants','errorMsgUtilities'],function($,constants,_errorMsgUtilities) {

  var PHONE_VALIDATION = {
    // Defaults
    defaults: {
      phone1Length:       3,
      phone2Length:       7,
      phone3Length:       4,
      phone1ClassName:    'phoneField1',
      phone2ClassName:    'phoneField2',
      phone3ClassName:    'phoneField3'
    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    phoneOnLoad: function() {
      var my = this;
      // Method will be called on load to set maxlength for phone fields
      $('.'+my.defaults.phone1ClassName).each(function(){
        var $p1 = $(this),
          $p2 = $p1.siblings('.'+my.defaults.phone2ClassName),
          $p3 = $p1.siblings('.'+my.defaults.phone3ClassName);

        $p1.prop('maxlength',my.defaults.phone1Length);
        $p2.prop('maxlength',my.defaults.phone2Length);
        $p3.prop('maxlength',my.defaults.phone3Length);

      });
    },

    phoneValidation: function(field, validationMy) {
      var my = this,
        $p1 = field,
        $p2 = $p1.siblings('.'+my.defaults.phone2ClassName),
        $p3 = $p1.siblings('.'+my.defaults.phone3ClassName);
        $errMsg = '';

      // Phone Required Validation
      if(field.attr(constants.dataRequiredAttr)) {
        if(!$p1.val() || !$p2.val()) {
          validationMy.addHighlight(field);
          $errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.requiredErrMsg);
        }
      }

      if(($p1.val().length > 0 || $p2.val().length > 0 || $p3.val().length > 0) && $errMsg == '') {

        if(($p1.val() && !$p1.val().match(/^[0-9]*$/))
        || ($p2.val() && !$p2.val().match(/^[0-9]*$/))
        || ($p3.val() && !$p3.val().match(/^[0-9]*$/))) { // Number Validation
          validationMy.addHighlight(field);
          $errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.numbervalidationErrMsg);
        } else if(($p1.val() || $p2.val()) && !$p3.val()) { // Length Validation
          if($p1.val().length + $p2.val().length != (my.defaults.phone1Length + my.defaults.phone2Length) ) {
            validationMy.addHighlight(field);
            $errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.lengthValidationErrMsg, (my.defaults.phone1Length + my.defaults.phone2Length));
          }
        } else if($p1.val() || $p2.val() || $p3.val()) { // Length Validation
          if($p1.val().length + $p2.val().length + $p3.val().length != (my.defaults.phone1Length + my.defaults.phone2Length + my.defaults.phone3Length) ) {
            validationMy.addHighlight(field);
            $errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.lengthValidationErrMsg, (my.defaults.phone1Length + my.defaults.phone2Length + my.defaults.phone3Length));
          }
        }

      }

      if($errMsg == '') { // Passing Validation
        validationMy.removeHighlight(field);
      }

      return $errMsg;
    }

  };

  return PHONE_VALIDATION;
});
