/**
 * Error message Utilities
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define([
  'jquery',
  'Constants'
], function(
  $,
  constants
) {

  var ERR_MSG_UTILITIES = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    /*
     * Public API - Get the error messsage and return it based on table or regular fields
     */
    generateErrorMsg: function(field, prefixErrorMsg, charLength, pos) {
      console.log();
      var indexArr = field.attr('name').split('__'),
        index = (indexArr.length > 1) ? parseInt(indexArr[1]) : -1,
        fieldName = '';

      if (field.attr(constants.dataErrAttr)) {
        fieldName = field.attr(constants.dataErrAttr);
      } else {
        fieldName = field.attr('name');
      }

      var $errorMsgList = $('.alertModule').find('ul');

      // For fields inside the table error messages
      if (index !== -1) {

        // Below if is to avoid duplicate error messsage for radio boxes.
        if ($errorMsgList.text().indexOf(field.attr("data-column-name") + ' for Row ' + index) === -1) {
          return '<li>' + prefixErrorMsg + field.attr('data-column-name') + ' for Row ' + index + '.</li>';
        }
      } else {
        if (charLength) {
          prefixErrorMsg = prefixErrorMsg.replace("{{l}}", charLength);
        }
        return '<li>' + prefixErrorMsg + fieldName + ((pos)?' - in field number '+pos:'') + '.</li>';
      }
    },

    /*
     * Public API - Get the error messsage and append it based on table or regular fields
     */
    appendErrorMsg: function(field, $errorMsgList, prefixErrorMsg, length, type) {
      var indexArr = field.attr('name').split('__'),
        index = (indexArr.length > 1) ? parseInt(indexArr[1]) : -1,
        fieldName = '';

      if (field.attr(constants.dataErrAttr)) {
        fieldName = field.attr(constants.dataErrAttr);
      } else {
        fieldName = field.attr('name');
      }

      // For fields inside the table error messages
      if (index !== -1) {

        // If 'length' & 'minmaxvalu' paramter means, it should be min and max value validation
        if (length && type === 'maxminvalue'){
          // Below if is to avoid duplicate error messsage for radio boxes.
          if ($errorMsgList.text().indexOf(field.attr("data-column-name") + ' for Row ' + index) === -1) {
            $errorMsgList.append('<li>' + field.attr("data-column-name") + ' for Row' + index + prefixErrorMsg + length + '.</li>');
          }
        } else if (length && type === 'maxminselection'){
          // Below if is to avoid duplicate error messsage for radio boxes.
          if ($errorMsgList.text().indexOf(field.attr("data-column-name") + ' for Row ' + index) === -1) {
            $errorMsgList.append('<li>' + field.attr("data-column-name") + ' for Row' + index + prefixErrorMsg + length + ' for ' + fieldName + '.</li>');
          }
        } else if (length) {
          // Below if is to avoid duplicate error messsage for radio boxes.
          if ($errorMsgList.text().indexOf(field.attr("data-column-name") + ' for Row ' + index) === -1) {
            $errorMsgList.append('<li>' + prefixErrorMsg + length + ' characters for ' + field.attr("data-column-name") + ' for Row' + index + '.</li>');
          }
        } else  {
          // Below if is to avoid duplicate error messsage for radio boxes.
          if ($errorMsgList.text().indexOf(field.attr("data-column-name") + ' for Row ' + index) === -1) {
            $errorMsgList.append('<li>' + prefixErrorMsg + field.attr('data-column-name') + ' for Row ' + index + '.</li>');
          }
        }

      } else {
        // If 'length' & 'minmaxvalu' paramter means, it should be min and max value validation
        if (length && type === 'maxminvalue') {
          $errorMsgList.append('<li>' + fieldName + prefixErrorMsg + length + '.</li>');
        } else if (length && type === 'maxminselection') {
          $errorMsgList.append('<li>' + prefixErrorMsg + length + ' for ' + fieldName + '.</li>');
        }  else if (length) {  // If 'length' paramter means, it should be min and max length validation
          $errorMsgList.append('<li>' + prefixErrorMsg + length + ' characters for ' + fieldName + '.</li>');
        } else {
          $errorMsgList.append('<li>' + prefixErrorMsg + fieldName + '.</li>');
        }
      }
    }
  };

  // Public APIs
  return ERR_MSG_UTILITIES;
});
