/**
 * Set default values for all fields
 *
 */
define(['jquery','Constants','errorMsgUtilities'],function($,constants, _errorMsgUtilities) {

  var ATTRIBUTE_VALIDATION = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },

    // Attribute validation based on data-validation attribute. Mostly used for textboxes
    attrValidation: function(field, type, validationMy) {
      var my = this,
      tempMsg = '';

      switch(type) {
      case 'nonumbervalidation':
        tempMsg = my.nonumbervalidation(field,validationMy);
        break;

      case 'alphaapostrophe':
        tempMsg = my.alphaapostrophe(field,validationMy);
        break;

      case 'alphahyphen':
        tempMsg = my.alphahyphen(field,validationMy);
        break;

      case 'alphanumeric':
        tempMsg = my.alphanumeric(field,validationMy);
        break;

      case 'alphasplexp':
        tempMsg = my.alphasplexp(field,validationMy);
        break;

      case 'alphaaposperiod':
        tempMsg = my.alphaaposperiod(field,validationMy);
        break;

      case 'alphahyphenspa':
        tempMsg = my.alphahyphenspa(field,validationMy);
        break;

      case 'alphanumericapostrophe':
        tempMsg = my.alphanumericapostrophe(field,validationMy);
        break;

      case 'alphanumerichyphen':
        tempMsg = my.alphanumerichyphen(field,validationMy);
        break;

      case 'alphanumericsplexp':
        tempMsg = my.alphanumericsplexp(field,validationMy);
        break;

      case 'currencyvalidation':
        tempMsg = my.currencyvalidation(field,validationMy);
        break;

      case 'decimalvalidation':
        tempMsg = my.decimalvalidation(field,validationMy);
        break;

      case 'emailvalidation':
        tempMsg = my.emailvalidation(field,validationMy);
        break;

      case 'numbervalidation':
        tempMsg = my.numbervalidation(field,validationMy);
        break;

      default:
        break;
      }
      return tempMsg;

    },

    // Only alphabets validation
    nonumbervalidation: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[ a-zA-Z]+$/)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.nonumbervalidationErrMsg);
      }
      return errMsg;
    },

    // Only alphabets and apostrophe validation
    alphaapostrophe: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z\']+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphaapostropheErrMsg);
      }
      return errMsg;
    },

    // Only alphabets and hyphen validation
    alphahyphen: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z\-]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphahyphenErrMsg);
      }
      return errMsg;
    },

    // Only numbers and alphabets validation
    alphanumeric: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[ a-z0-9]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphanumericErrMsg);
      }
      return errMsg;
    },

    // Only alphabets and special characters except ! % ( ) + = ˜ ` “ ? validation
    alphasplexp: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (!field.val().match(/[0-9\(\!%\)\+\=\?`~"]+/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphasplexpErrMsg);
      }
      return errMsg;
    },

    // Only alphabets, apostrophe and period validation
    alphaaposperiod: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z \'\.]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphaaposperiodErrMsg);
      }
      return errMsg;
    },

    // Only alphabets, hyphen and space validation
    alphahyphenspa: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z \-]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphahyphenspaErrMsg);
      }
      return errMsg;
    },

    // Only alphabets, digits and apostrophe validation
    alphanumericapostrophe: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z0-9\']+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphanumericapostropheErrMsg);
      }
      return errMsg;
    },

    // Only alphabets, digits and hyphen validation
    alphanumerichyphen: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[a-z0-9\-]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphanumerichyphenErrMsg);
      }
      return errMsg;
    },

    // Only alphabets, digits and special characters except ! % ( ) + = ˜ ` “ ? validation
    alphanumericsplexp: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (!field.val().match(/[/(/!/%/)/+/=/~/'\"]+$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.alphanumericsplexpErrMsg);
      }
      return errMsg;
    },

    // Currency validation
    currencyvalidation: function(field,validationMy) {
      var my = this,
        errMsg = '';
       if ((!field.val().match(/^\d+(\.\d{1,2})$/)) && (!field.val().match(/^\$\d+(\.\d{1,2})$/)) && (!field.val().match(/^(\d+)$/)) && (!field.val().match(/^(\$\d+)$/)) && (!field.val().match(/^((\d+)(,(\d{3}))+)$/)) && (!field.val().match(/^\$((\d+)(,(\d{3}))+)$/)) && (!field.val().match(/^\((\d+)\)$/)) && (!field.val().match(/^\(\$(\d+)\)$/)) && (!field.val().match(/^\(((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\(\$((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\((((\d+),(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\(((\d+)(\.\d{1,2}))\)$/)) && (!field.val().match(/^\(\$(((\d+)(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^((\d+)(,(\d{3}))+)(\.\d{1,2})$/)) && (!field.val().match(/^\$((\d+)(,(\d{3}))+)(\.\d{1,2})$/)) && (!field.val().match(/^\(\$((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\(((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\-\d+(\.\d{1,2})$/)) && (!field.val().match(/^\-\$\d+(\.\d{1,2})$/)) && (!field.val().match(/^\-(\d+)$/)) && (!field.val().match(/^\-(\$\d+)$/)) && (!field.val().match(/^\-((\d+)(,(\d{3}))+)$/)) && (!field.val().match(/^\-\$((\d+)(,(\d{3}))+)$/)) && (!field.val().match(/^\-\((\d+)\)$/)) && (!field.val().match(/^\(\-(\d+)\)$/)) && (!field.val().match(/^\-\(\$(\d+)\)$/)) && (!field.val().match(/^\(\-\$(\d+)\)$/)) && (!field.val().match(/^\-\(((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\(\-((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\-\(\$((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\(\-\$((\d+)(,(\d{3}))+)\)$/)) && (!field.val().match(/^\-\((((\d+),(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\(\-(((\d+),(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\-\(((\d+)(\.\d{1,2}))\)$/)) && (!field.val().match(/^\(\-((\d+)(\.\d{1,2}))\)$/)) && (!field.val().match(/^\-\(\$(((\d+)(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\(\-\$(((\d+)(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\-((\d+)(,(\d{3}))+)(\.\d{1,2})$/)) && (!field.val().match(/^\-\$((\d+)(,(\d{3}))+)(\.\d{1,2})$/)) && (!field.val().match(/^\(\-\$((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\-\(\$((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\-\(((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/)) && (!field.val().match(/^\(\-((\d+)(,(\d{3}))+)(\.\d{1,2})\)$/))) {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.currencyvalidationErrMsg);
      } else {
        validationMy.removeHighlight(field);
      }
      return errMsg;
    },

    // Decimal validation
    decimalvalidation: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^\d+(\.\d{1,2})?$/)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.decimalvalidationErrMsg);
      }
      return errMsg;
    },

    // Decimal validation
    emailvalidation: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if(field.val().match(/^((([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+(\.([a-z]|\d|[!#\$%&'\*\+\-\/=\?\^_`{\|}~]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])+)*)|((\x22)((((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(([\x01-\x08\x0b\x0c\x0e-\x1f\x7f]|\x21|[\x23-\x5b]|[\x5d-\x7e]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(\\([\x01-\x09\x0b\x0c\x0d-\x7f]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))))*(((\x20|\x09)*(\x0d\x0a))?(\x20|\x09)+)?(\x22)))@((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))$/i)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.validErrMsg);
      }
      return errMsg;
    },

    // Only numbers validation
    numbervalidation: function(field,validationMy) {
      var my = this,
        errMsg = '';
      if (field.val().match(/^[0-9]*$/)) {
        validationMy.removeHighlight(field);
      } else {
        validationMy.addHighlight(field);
        errMsg = _errorMsgUtilities.generateErrorMsg(field, constants.numbervalidationErrMsg);
      }
      return errMsg;
    }

  };

  return ATTRIBUTE_VALIDATION;
});
