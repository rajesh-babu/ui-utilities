/**
 * Drop down Actions
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define(['jquery','Constants','conditionsActions', 'dropDownUsingJSON'],function($, constants, _conditionsActions, _dropDownUsingJSON) {

  var CONDITIONS_DROPDOWNS = {
    // Defaults
    defaults: {

    },

    // Initialize
    init: function(elem, options, i) {
      var my = this;
      my.options = $.extend({}, my.defaults, options);
    },
    /*
     * Public API - Listener for Drop downs
     */
     handleDropDowns: function(conditions) {
      var my = this;
      $('select').change(function(e) {
        my._doDropdownActions(conditions, $(this) );
      });
    },
    /*
     * Action for Drop downs
     */
     _doDropdownActions: function(conditions, srcEle$) {
       var namePostfixArr = srcEle$.attr('name').split('__');
       var namePostfix = (namePostfixArr.length >1) ? ('__'+namePostfixArr[1]) : '';
       var conditionMet=false;
       for(var i=0;i<conditions.length;i++) {
         if(conditions[i]['condIf'] === srcEle$.attr('name') ) {

           // if STATE is equal to - conditions value and selected value should be same
           // if STATE is NOT equal to - conditions value and selected value should NOT be same
           conditionMet=false;
           if(conditions[i][constants.state] === constants.equals) {
             if(conditions[i].value === srcEle$.val()){
               conditionMet=true;
             }
           } else if(conditions[i][constants.state] !== constants.equals) {
             if(conditions[i].value !== srcEle$.val()){
               conditionMet=true;
             }
           }

           for(var j=0;j<conditions[i]['condDo'].length;j++) {
             var op = conditions[i]['condDo'][j];
             for(var k=0;k<op[constants.dofield].length;k++) {
               var tarEle$;
               if(op[constants.dofield][k].type === 'pagefield') {
                 tarEle$ = $('.ref-id-' + op[constants.dofield][k].refId);
               } else if(op[constants.dofield][k].type === 'secContainer') {
                 if($('.one_third').find('.' + op[constants.dofield][k].name+namePostfix).length > 0) {
                   tarEle$ = $('.one_third').find('.' + op[constants.dofield][k].name+namePostfix);
                 }
               } else {
                 tarEle$ = $('.' + op[constants.dofield][k].name+namePostfix);
               }

                 if(tarEle$.length > 0){

                 switch(op[constants.dostate]) {
                   case constants.enable:
                   case constants.disable:
                     if(conditionMet) {
                       _conditionsActions.enableDisableFields(conditions[i][constants.state], op[constants.dostate], tarEle$);
                     }
                     break;
                   case constants.show:
                   case constants.hide:
                     if(conditionMet) {
                       _conditionsActions.showHideFields(conditions[i][constants.state], op[constants.dostate], tarEle$,op[constants.dofield][k].type);
                     }
                     if( op.hasOwnProperty('targetRegex') && conditions[i].hasOwnProperty('sourceRegex')) {

                       // For Drop down fields
                       if(op[constants.dofield][k].type === 'selectfield') {
                         _conditionsActions.hideDropDownOption(conditions[i].sourceRegex, op['targetRegex'], srcEle$, tarEle$);
                       }
                     }
                     break;
                   case constants.require:
                   case constants.unrequire:
                     if(conditionMet) {
                       _conditionsActions.requireUnrequireFields(conditions[i][constants.state], op[constants.dostate], tarEle$);
                     }
                     break;
                   case constants.set: // set
                    if( op.hasOwnProperty('targetRegex') && conditions[i].hasOwnProperty('sourceRegex')) {

                      // For Drop down fields
                      if(op[constants.dofield][k].type === 'selectfield') {
                        _dropDownUsingJSON.setDropDownOptions(conditions[i].sourceRegex, op['targetRegex'], srcEle$, tarEle$);
                      }

                      // For Text fields
                      if(op[constants.dofield][k].type === 'textfield') {
                        _dropDownUsingJSON.setText(conditions[i].sourceRegex, op['targetRegex'], srcEle$, tarEle$);
                      }
                   }
                   break;
                 }
               }
             }
           }
         }
       }
      }
  };
  return CONDITIONS_DROPDOWNS;
});
