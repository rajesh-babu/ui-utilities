/**
 * Conditions Main
 * @contrib Rajesh Thoghuluva
 * @version 1.0.0
 *
 */
define([
    'jquery',
    'Constants',
    'conditionsCheckboxRadio',
    'conditionsDropdowns',
    'conditionsTextbox'
     ],function(
       $,
       constants,
       _conditionsCheckboxRadio,
       _conditionsDropdowns,
       _conditionsTextbox
      ) {

    var CONDITIONS_MAIN = {
      // Defaults
      defaults: {

      },

      // Initialize
      init: function(elem, options, i) {
        var my = this;
        my.options = $.extend({}, my.defaults, options);
      },

      /*
       * Public API - Process the conditions for all types of fields
       */
       processConditions: function(conditions) {
         // Handler for Check boxes and radio buttons
         _conditionsCheckboxRadio.handleCheckandRadio(conditions);

         // Handlers for Drop downs
         _conditionsDropdowns.handleDropDowns(conditions);

         //Handlers for Text boxes
         _conditionsTextbox.handleTextbox(conditions);
       }
    };

   // Public APIs
  return CONDITIONS_MAIN;
});
